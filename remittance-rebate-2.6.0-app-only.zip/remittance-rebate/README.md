# Remittance Rebate Calculator — web edition 2.6

Consolidation · Cleansing · Enrichment — Powered by BP&P

A browser application that runs on the office VM. Users upload the month's
files, the server does the processing, and the final workbook is downloaded
from the browser. Nothing is installed on users' PCs.

## 1. Install (offline, about 2 minutes)

Requirements: RHEL 9 (x86_64) with its standard Python 3.9. No internet access
is needed — every library is in the `wheels/` folder.

```bash
tar -xzf remittance-rebate-2.1.0.tar.gz -C /data
cd /data/remittance-rebate
./setup.sh          # creates venv/, installs the wheels, asks for the administrator
./selftest.sh       # optional: full run on synthetic data, prints PASSED
./start.sh          # starts the server on port 3400
```

Open `http://<vm-name>:3400/` in Chrome or Edge and sign in.

If the page opens on the VM but not from another PC, open the port (as root):

```bash
firewall-cmd --permanent --add-port=3400/tcp && firewall-cmd --reload
```

| Script | Purpose |
|---|---|
| `./start.sh` / `./stop.sh` / `./status.sh` | run the server in the background |
| `./manage.sh adduser NAME` | add an administrator from the command line (`--user` for a standard user; also `passwd`, `deluser`, `list`). Day to day, use the **Users** screen instead. |
| `./selftest.sh [ROWS]` | end-to-end check on synthetic data; `./selftest.sh 500000` is a speed trial |
| `remittance-rebate.service` | optional systemd unit so the app starts with the VM |

## 2. Users

The account created during setup is the **administrator**. Administrators see a
**Users** button (top right) to add users, set a new password, change a role or
remove a user. Standard users can do everything in a run but cannot manage
users; everyone can change their own password under **Account**.

If the server is started with no account at all, the first person to open the
page is asked to create the administrator — so create it during setup, before
sharing the address.

## 3. Monthly use

1. **Files** — *New run*, enter the USD rate, upload the four channel extracts
   and the reference files. **Extracts in several parts:** add every file of a
   channel to its box, and keep multi-sheet workbooks as they are — every sheet
   with the same headings is combined (the log lists each part and its row
   count; a sheet with other headings is skipped and named in the log). ITRS files must keep their name
   (`ITRS Data Nov, 2025.xlsx`). Several ITRS / RDA-HBL / commercial workbooks
   can be added to the same box.
2. **Process** — consolidates, cleanses, enriches and applies the business
   rules. The screen shows the live log and the time each stage took.
3. **Review**
   - *Transactions to review*: by default only transactions that can still be
     claimed are listed. Those already excluded (No Claim entity, Mode CM, below
     US$200, RDA) stay in TOTAL and on their tabs but need no completion. Switch
     to *All transactions* to list everything.
   - *Query file*: download, complete in Excel, upload. Each sheet lists the
     transactions with one outstanding value (amber column). Two more amber
     columns on every sheet — **Change Mode To** and **Cancel? (Y)** — and the
     sheets **Change of Mode** and **Mark Cancelled** (by Row ID or URN) cover
     any other transaction. Invalid entries are listed with the reason and are
     not applied. The file can be uploaded more than once.
   - *Find a transaction*: the same actions on screen, by URN or Row ID,
     including *Restore to TOTAL* for a cancelled transaction.
   - *Name review*: names the cleansing rules changed in a way worth checking
     (emptied by the rules, a word cut or removed, joined words, joint names,
     suspicious results, replaced from LINK TITLE), and
     **spelling variants** — two spellings on the same account, CNIC or Remitter
     ID (shown as evidence, with a filter for each), or names that sound alike
     and appear with the same R.E and the same counterpart (MUHAMMAD / MOHAMMAD ASLAM sending to the same
     person). Accept a suggestion, keep the rule result, or type the right name;
     for variants choose *Same person* or *Different*. The same lists are in the
     query file (sheets *Name Review* and *Spelling Variants*). Decisions are
     stored in `data/names.json` and applied automatically in every later run,
     so each name is reviewed once. Merging spellings lets the name-based keys
     (KEY 1 and KEY 4) catch repeats; the ID-based keys are not affected by
     spelling.
   - Every list shows the LINK TITLE and offers *Keep rule result*, *Revert to
     original*, *Use LINK TITLE* (beneficiaries) or a typed name. Joint names
     (X AND Y) are not treated as a problem.
   - *Send to query file*: tick names (or send a whole list) that need checking
     in the system - for example garbage names. The query file then has a
     **Names To Check** sheet with one row per transaction (URN, account, CNIC,
     LINK TITLE ...) and an amber *Correct Name* column; corrections apply to
     those transactions only.
   - *Check names with AI* (when the model server is reachable) asks Qwen for a
     clean version of each name under review and an opinion on each variant
     pair. An AI-cleaned name is only offered if it was made by removing junk or
     splitting joined words — the app rejects any answer that changes a spelling
     or adds a word. Answers are cached in `data/cache/ai_names.json`.
   - *Commercial customer types*: tick the `cust_type` values that are commercial.
   - *Commercial name near matches*: approve or reject names that resemble a
     listed commercial name.
4. **Report** — *Generate final report*, review the control checks, download.
   It can be regenerated at any time after further changes.

Work is saved continuously. After a restart the last run comes back with every
manual change re-applied.

## 4. What changed since the desktop version (UAT feedback)

| # | Feedback | What the application does now |
|---|---|---|
| 1 | "Change of Mode" in the query file | Mode can be amended in the query file or on screen. CNIC back-fill, the account-number rule, the DL1534 lookup and the derived columns are re-run for that transaction under its new mode. |
| 2 | Cancelled status in the query file (URN 2026126050980614) | A transaction can be marked cancelled in the query file or on screen; it moves to **Cancelled** with a *Cancel Reason*. Separately, refund references of 16+ digits that Excel had rounded (…614 stored as …610) are now matched on the first 15 digits + amount and reported in the log. |
| 3 | Beneficiary commercial by `cust_type` | DL1534 `cust_type` is used (column **Cust Type**); `acct_type` is no longer read. |
| 4 | Separate tab for MAX / five split | **SPLIT** holds the 1-per-day excess (EQ-1..3); **MAX 5 SPLIT** holds the 5-per-month excess (EQ-4..6). |
| 5, 6 | Remitter / beneficiary commercial not excluded | Fixed — see the note below. **Reme Comm** and **Bene Comm** always appear in the report (a single "Null" row when empty), as do all other extraction tabs. |
| 7 | Internal Audit validation | **Control Summary** tab (21 checks, recomputed independently from the finished tabs) and **Audit Trail** tab (input files with SHA-256, every manual change with user and time, decisions, timings). |
| 9 | Data split over two sheets | Every sheet of a channel workbook with the same headings is read and combined, and several files can be uploaded per channel. |

**Why commercial names were not being excluded (items 5 and 6).** Two causes:

1. A defect in the last desktop patch: the function that loads the commercial
   repository returned before reading any file, so the name lists were always
   empty. That is corrected.
2. Names in the repository were compared only against the *cleansed*
   transaction name. Each repository name is now matched as written and after
   the same cleansing, against both the cleansed and the original transaction
   name (case, punctuation and spacing ignored). Names that differ only by a
   legal suffix are offered as near matches for a decision rather than applied
   silently.

## 5. Speed

- Nothing is written to Excel between the stages; the dataset stays in memory
  and is snapshotted to disk in a binary format.
- The final workbook is written by a purpose-built writer that produces the
  sheet XML in bulk and spreads the work over several CPU cores. If it ever
  fails, the application falls back to a single process and then to the
  standard library writer automatically (the log says which one was used).
- Name cleansing runs on several cores for large files.
- The *Time taken* table on the Process and Report screens shows the seconds
  per stage for the real data, so the gain can be measured directly.

`"workers"` in `app/config.json` sets the number of CPU cores used
(0 = automatic: half the cores, at most 8).

## 6. AI assistance (optional)

`app/config.json` points to the vLLM server (`"llm_url": "http://127.0.0.1:8001/v1"`;
the model name is read from the server). When it is reachable, two buttons appear:

- *Ask AI for an opinion* on commercial near matches (yes / no / unsure with a reason);
- *Explain warnings (AI)* on the activity log.

The model is advisory only. It never reads or changes the dataset, no figure
depends on it, and the application works the same when it is switched off.
Data sent to it stays on the VM.

## 7. Things to know

- **Python 3.9 only.** The bundled libraries are built for RHEL 9's Python 3.9.
- **One run is processed at a time**, which suits 1–2 users. A second user sees
  the same run and its progress.
- **Process again discards manual changes** made in Review (the screen warns).
  *Generate again* does not.
- **Plain HTTP.** Suitable inside the bank network. To use HTTPS, put the
  certificate and key paths in `tls_cert` / `tls_key` in `app/config.json`.
- **Data location.** Everything is under `/data/remittance-rebate/data/`
  (`runs/<date-time>/inputs`, `outputs`, the journal and logs). It contains
  customer data — the folder is created readable by the service account only.
  Delete old runs from the browser (*Delete*) once the month is closed.
- **Rebate amount.** The application prepares the claim tabs; it does not
  calculate the rebate itself.
- **Control checks** are generic reconciliations. Internal Audit's own list of
  checks should be compared with section C01–C21 of the Control Summary and any
  missing check added.

## 8. Troubleshooting

| Symptom | Check |
|---|---|
| `setup.sh` says Python 3.9 not found | `ls /usr/bin/python3*` — the package needs 3.9 |
| Server does not start | `tail -n 30 data/server.log`; port 3400 already in use? |
| A step stops with "unexpected error" | the message is in the activity log; full detail in `data/server-errors.log` |
| A column is reported as "not found" | the header in that source file changed; the log names the expected header |
| Forgotten password | `./manage.sh passwd NAME` |
