#!/usr/bin/env python3
"""
Remittance Rebate Calculator - web server.

Standard library only (no web framework), so the offline install needs
nothing beyond the data libraries. Serves the single-page UI and a small
JSON API; long work runs on one background thread with progress polling.

    python server.py            (normally started by ../start.sh)
"""
import hashlib
import hmac
import json
import os
import secrets
import ssl
import sys
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import names_review  # noqa: E402

DEFAULTS = {"host": "0.0.0.0", "port": 3400, "workers": 0, "data_dir": "../data",
            "llm_url": "http://127.0.0.1:8001/v1", "llm_model": "", "session_hours": 12,
            "max_upload_mb": 4096, "tls_cert": "", "tls_key": ""}
COOKIE = "rrc_session"
PBKDF2_ROUNDS = 200000


def load_settings():
    cfg = dict(DEFAULTS)
    path = os.path.join(HERE, "config.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    cfg["data_dir"] = os.path.abspath(os.path.join(HERE, cfg["data_dir"]))
    if not int(cfg.get("workers") or 0):
        cfg["workers"] = min(8, max(1, (os.cpu_count() or 2) // 2))
    return cfg


# ── users ───────────────────────────────────────────────────────
def hash_password(password, salt=None, role="admin"):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt),
                                 PBKDF2_ROUNDS).hex()
    return {"salt": salt, "hash": digest, "rounds": PBKDF2_ROUNDS, "role": role}


def role_of(cfg, user):
    """'admin' or 'user'. Accounts created before roles existed are admins."""
    rec = load_users(cfg).get(user) or {}
    return rec.get("role") or "admin"


def valid_user_name(name):
    return bool(name) and len(name) <= 40 and name.replace(".", "").replace("_", "").replace("-", "").isalnum()


def password_problem(pw):
    if len(pw) < 10:
        return "The password must be at least 10 characters."
    return ""


def users_path(cfg):
    return os.path.join(cfg["data_dir"], "users.json")


def load_users(cfg):
    try:
        with open(users_path(cfg), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save_users(cfg, users):
    os.makedirs(cfg["data_dir"], exist_ok=True)
    tmp = users_path(cfg) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(users, fh, indent=1)
    import pipeline
    pipeline.replace_file(tmp, users_path(cfg))
    try:
        os.chmod(users_path(cfg), 0o600)
    except OSError:
        pass


def check_password(cfg, user, password):
    rec = load_users(cfg).get(user)
    if not rec:
        hash_password(password)                       # same cost either way
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(rec["salt"]),
                                 int(rec.get("rounds", PBKDF2_ROUNDS))).hex()
    return hmac.compare_digest(digest, rec["hash"])


# ── application state ───────────────────────────────────────────
class App(object):
    def __init__(self, cfg):
        import pipeline
        self.pipeline = pipeline
        self.cfg = cfg
        self.runs_dir = os.path.join(cfg["data_dir"], "runs")
        os.makedirs(self.runs_dir, exist_ok=True)
        self.lock = threading.RLock()
        self.run = None
        self.rev = 0
        self.job = {"running": False, "kind": "", "label": "", "i": 0, "n": 1, "error": "",
                    "started": 0, "finished": 0}
        self.sessions = {}
        self.fails = {}
        self._summary = (None, None)
        self.ai = {"checked": 0, "status": {"available": False, "model": "", "detail": ""}}
        self.ai_opinions = {}

    def list_runs(self):
        out = []
        for d in sorted(os.listdir(self.runs_dir), reverse=True):
            p = os.path.join(self.runs_dir, d, "meta.json")
            try:
                if self.run is not None and self.run.run_id == d:
                    m = self.run.meta          # never open the file being rewritten
                else:
                    with open(p, encoding="utf-8") as fh:
                        m = json.load(fh)
                out.append({k: m.get(k) for k in ("id", "name", "status", "created_at",
                                                  "created_by", "period")})
            except (OSError, ValueError):
                continue
        return out

    def open_run(self, run_id):
        root = os.path.join(self.runs_dir, os.path.basename(run_id))
        if not os.path.exists(os.path.join(root, "meta.json")):
            raise self.pipeline.RunError("That run no longer exists.")
        self.run = self.pipeline.Run.load(root, self.cfg)
        self.rev += 1
        self.ai_opinions = {}

    def busy(self):
        if self.job["running"]:
            raise self.pipeline.RunError("Please wait - '%s' is still in progress." % self.job["label"])

    def need_run(self):
        if self.run is None:
            raise self.pipeline.RunError("Create or open a run first.")
        return self.run

    def start_job(self, kind, label, fn, on_fail_status):
        with self.lock:
            self.busy()
            run = self.need_run()
            self.job = {"running": True, "kind": kind, "label": label, "i": 0, "n": 1,
                        "error": "", "started": time.time(), "finished": 0}

        def progress(lbl, i, n):
            self.job.update(label=lbl, i=i, n=max(n, 1))

        def work():
            try:
                fn(progress)
            except self.pipeline.RunError as e:
                self.job["error"] = str(e)
                run.say(str(e), "error")
                run.meta["status"] = on_fail_status
                run.save_meta()
            except Exception as e:
                detail = traceback.format_exc()
                try:
                    with open(os.path.join(self.cfg["data_dir"], "server-errors.log"), "a") as fh:
                        fh.write("\n%s %s\n%s" % (time.strftime("%Y-%m-%d %H:%M:%S"), kind, detail))
                except OSError:
                    pass
                last = [l for l in detail.strip().splitlines() if l.strip()][-1]
                self.job["error"] = "The step stopped on an unexpected error: %s" % last
                run.say(self.job["error"], "error")
                where = [l.strip() for l in detail.splitlines() if 'File "' in l][-1:]
                if where:
                    run.say("at " + where[0], "error")
                run.meta["status"] = on_fail_status
                run.save_meta()
            finally:
                self.job.update(running=False, finished=time.time())
                self.rev += 1

        threading.Thread(target=work, name="job-" + kind, daemon=True).start()

    def summary(self):
        run = self.run
        if run is None or run.total is None or self.job["running"]:
            return None
        if self._summary[0] == (run.run_id, self.rev):
            return self._summary[1]
        eng = self.pipeline.engine
        canc = run.extra.get(eng.CANCELLED_SHEET_NAME)
        s = {
            "rows": {"TOTAL": len(run.total),
                     "ORRE": len(run.extra.get(eng.ORRE_SHEET_NAME, [])),
                     "Cancelled": 0 if canc is None else len(canc),
                     "RDA-Other-Unmatch": len(run.extra.get(eng.RDA_OTHER_UNMATCH_SHEET, []))},
            "consolidated": run.stats.get("consolidated_rows"),
            "channels": run.stats.get("channels"),
            "query": [{"column": c, "outstanding": n, "mode": self.pipeline.QUERY_COLUMNS[c] or ""}
                      for c, n in run.query_counts().items()],
            "query_scope": run.query_scope(),
            "names": names_review.summary(run, run.data_dir),
            "excluded": int(run.excluded_mask().sum()),
            "modes": run.known_modes(),
            "mode_counts": {k: int(v) for k, v in run._mode().value_counts().items()},
            "cust_types": run.cust_types(),
            "suggestions": run.suggestion_list(),
            "journal_count": len(run.journal),
            "journal": run.journal[-25:][::-1],
            "checks": run.checks if run.meta.get("status") == "generated" else [],
            "sheets": run.sheet_names(),
            "editable": list(self.pipeline.QUERY_COLUMNS),
        }
        if canc is not None and len(canc) and eng.CANCEL_REASON_COL in canc.columns:
            s["cancel_reasons"] = {str(k): int(v) for k, v in canc[eng.CANCEL_REASON_COL].map(
                lambda v: "Marked by reviewer" if str(v).startswith("Marked by reviewer") else str(v)
            ).value_counts().items()}
        self._summary = ((run.run_id, self.rev), s)
        return s

    def ai_status(self):
        if time.time() - self.ai["checked"] > 60:
            import ai_assist
            self.ai = {"checked": time.time(), "status": ai_assist.status(self.cfg)}
        return self.ai["status"]

    def state(self, user, since):
        run = self.run
        out = {"user": user, "role": role_of(self.cfg, user),
               "version": self.pipeline.VERSION, "runs": self.list_runs(),
               "job": dict(self.job, elapsed=round(
                   (self.job["finished"] or time.time()) - self.job["started"], 1)
                   if self.job["started"] else 0),
               "ai": self.ai_status(), "rev": self.rev, "run": None, "log": [], "log_next": 0,
               "workers": self.cfg["workers"]}
        if run is not None:
            blocking, notes = run.readiness()
            m = run.meta
            out["run"] = {"id": m["id"], "name": m["name"], "status": m.get("status"),
                          "stale": bool(m.get("stale")), "usd_rate": m.get("usd_rate"),
                          "period": m.get("period"), "created_by": m.get("created_by"),
                          "created_at": m.get("created_at"), "inputs": run.inputs(),
                          "blocking": blocking, "notes": notes, "timings": m.get("timings", []),
                          "outputs": m.get("outputs", []), "summary": self.summary(),
                          "ai_opinions": self.ai_opinions}
            since = max(0, min(since, len(run.log)))
            if len(run.log) - since > 600:
                since = len(run.log) - 600
            out["log"] = run.log[since:]
            out["log_next"] = len(run.log)
        return out


APP = None


class _Counted(object):
    """Request body reader that knows how much is still unread, so a
    rejected upload can be drained and the connection stays usable."""

    def __init__(self, stream, length):
        self.stream, self.left = stream, max(0, length)

    def read(self, n):
        block = self.stream.read(min(n, self.left)) if self.left > 0 else b""
        self.left -= len(block)
        return block

    def drain(self):
        while self.left > 0:
            if not self.read(1 << 20):
                break


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "RRC"
    sys_version = ""

    def log_message(self, fmt, *args):
        pass

    # ── plumbing ────────────────────────────────────────────────
    def _headers(self, code, ctype, length, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                         "script-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                         "frame-ancestors 'none'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()

    def _json(self, obj, code=200, extra=None):
        body = json.dumps(obj, default=str).encode("utf-8")
        self._headers(code, "application/json; charset=utf-8", len(body), extra)
        self.wfile.write(body)

    def _error(self, msg, code=400):
        self._json({"error": msg}, code)

    def _body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 5 * 1024 * 1024:
            raise APP.pipeline.RunError("Request too large.")
        raw = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(raw.decode("utf-8") or "{}")
        except ValueError:
            raise APP.pipeline.RunError("Malformed request.")

    def _drain(self):
        n = int(self.headers.get("Content-Length") or 0)
        while n > 0:
            chunk = self.rfile.read(min(1 << 20, n))
            if not chunk:
                break
            n -= len(chunk)

    def _user(self):
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            k, _, v = part.strip().partition("=")
            if k == COOKIE:
                sess = APP.sessions.get(v)
                if sess and sess[1] > time.time():
                    return sess[0]
        return None

    def _file(self, path, ctype, download=None):
        size = os.path.getsize(path)
        extra = {}
        if download:
            extra["Content-Disposition"] = "attachment; filename*=UTF-8''" + urllib.parse.quote(download)
        self._headers(200, ctype, size, extra)
        with open(path, "rb") as fh:
            while True:
                block = fh.read(1 << 20)
                if not block:
                    break
                self.wfile.write(block)

    # ── routing ─────────────────────────────────────────────────
    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")

    def _route(self, method):
        url = urllib.parse.urlsplit(self.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
        path = url.path
        try:
            if method == "GET" and path in ("/", "/index.html"):
                return self._file(os.path.join(HERE, "static", "index.html"),
                                  "text/html; charset=utf-8")
            if method == "GET" and path == "/favicon.ico":
                return self._headers(204, "image/x-icon", 0)
            if not path.startswith("/api/"):
                return self._error("Not found", 404)
            if method == "POST" and self.headers.get("X-Requested-With") != "rrc":
                self._drain()
                return self._error("Forbidden", 403)
            name = path[5:].replace("/", "_").replace("-", "_")
            if name == "login" and method == "POST":
                return self.api_login()
            if name == "setup" and method == "POST":
                return self.api_setup()
            user = self._user()
            if user and user not in load_users(APP.cfg):
                user = None                              # account was removed
            if not user:
                if method == "POST":
                    self._drain()
                return self._json({"error": "Please sign in.",
                                   "setup": not load_users(APP.cfg)}, 401)
            fn = getattr(self, "%s_%s" % (method.lower(), name), None)
            if fn is None:
                if method == "POST":
                    self._drain()
                return self._error("Not found", 404)
            res = fn(user, q)
            if res is not None:
                self._json(res)
        except APP.pipeline.RunError as e:
            self._error(str(e), 409)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                with open(os.path.join(APP.cfg["data_dir"], "server-errors.log"), "a") as fh:
                    fh.write("\n%s %s %s\n%s" % (time.strftime("%Y-%m-%d %H:%M:%S"), method,
                                                  path, traceback.format_exc()))
            except OSError:
                pass
            try:
                self._error("Unexpected error: %s: %s" % (type(e).__name__, e), 500)
            except Exception:
                pass

    # ── session ─────────────────────────────────────────────────
    def api_login(self):
        d = self._body_json()
        user, pw = str(d.get("user", "")).strip().lower(), str(d.get("password", ""))
        f = APP.fails.get(user, [0, 0])
        if f[0] >= 5 and time.time() - f[1] < 300:
            return self._error("Too many attempts. Try again in a few minutes.", 429)
        if not user or not check_password(APP.cfg, user, pw):
            APP.fails[user] = [f[0] + 1 if time.time() - f[1] < 300 else 1, time.time()]
            return self._error("User name or password is not correct.", 401)
        APP.fails.pop(user, None)
        token = secrets.token_urlsafe(32)
        hours = float(APP.cfg.get("session_hours") or 12)
        APP.sessions[token] = (user, time.time() + hours * 3600)
        for k in [k for k, v in APP.sessions.items() if v[1] < time.time()]:
            APP.sessions.pop(k, None)
        cookie = "%s=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=%d" % (
            COOKIE, token, int(hours * 3600))
        if APP.cfg.get("tls_cert"):
            cookie += "; Secure"
        self._json({"user": user}, extra={"Set-Cookie": cookie})

    def _start_session(self, user):
        token = secrets.token_urlsafe(32)
        hours = float(APP.cfg.get("session_hours") or 12)
        APP.sessions[token] = (user, time.time() + hours * 3600)
        cookie = "%s=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=%d" % (
            COOKIE, token, int(hours * 3600))
        if APP.cfg.get("tls_cert"):
            cookie += "; Secure"
        self._json({"user": user}, extra={"Set-Cookie": cookie})

    def api_setup(self):
        """First start only: create the administrator. Refused as soon as
        any account exists."""
        d = self._body_json()
        with APP.lock:
            if load_users(APP.cfg):
                return self._error("Setup has already been completed.", 403)
            user, pw = str(d.get("user", "")).strip().lower(), str(d.get("password", ""))
            if not valid_user_name(user):
                return self._error("User names may contain letters, digits, dot, dash and underscore only.")
            if password_problem(pw):
                return self._error(password_problem(pw))
            save_users(APP.cfg, {user: hash_password(pw, role="admin")})
        self._start_session(user)

    # ── user administration ─────────────────────────────────────
    def _admin(self, user):
        if role_of(APP.cfg, user) != "admin":
            raise APP.pipeline.RunError("Only an administrator can manage users.")

    def get_users(self, user, q):
        self._admin(user)
        users = load_users(APP.cfg)
        return {"users": [{"name": n, "role": r.get("role") or "admin",
                           "created_by": r.get("created_by", ""), "created_at": r.get("created_at", "")}
                          for n, r in sorted(users.items())]}

    def post_users_save(self, user, q):
        """Create a user, or change an existing user's role / password."""
        d = self._body_json()
        self._admin(user)
        name = str(d.get("name", "")).strip().lower()
        role = "admin" if d.get("role") == "admin" else "user"
        pw = str(d.get("password") or "")
        with APP.lock:
            users = load_users(APP.cfg)
            if not valid_user_name(name):
                raise APP.pipeline.RunError("User names may contain letters, digits, dot, dash and underscore only.")
            new = name not in users
            if new and not pw:
                raise APP.pipeline.RunError("Enter a password for the new user.")
            if pw and password_problem(pw):
                raise APP.pipeline.RunError(password_problem(pw))
            if not new and role != "admin" and (users[name].get("role") or "admin") == "admin" \
                    and sum((r.get("role") or "admin") == "admin" for r in users.values()) <= 1:
                raise APP.pipeline.RunError("At least one administrator is required.")
            rec = dict(users.get(name) or {})
            if pw:
                rec.update(hash_password(pw, role=role))
            rec["role"] = role
            if new:
                rec.update(created_by=user, created_at=time.strftime("%Y-%m-%d %H:%M:%S"))
            users[name] = rec
            save_users(APP.cfg, users)
            if pw and not new:                           # sign that user out everywhere
                for k in [k for k, v in APP.sessions.items() if v[0] == name and name != user]:
                    APP.sessions.pop(k, None)
        return {"ok": True, "created": new}

    def post_users_delete(self, user, q):
        d = self._body_json()
        self._admin(user)
        name = str(d.get("name", "")).strip().lower()
        with APP.lock:
            users = load_users(APP.cfg)
            if name == user:
                raise APP.pipeline.RunError("You cannot delete your own account.")
            if name not in users:
                raise APP.pipeline.RunError("No such user.")
            users.pop(name)
            if not any((r.get("role") or "admin") == "admin" for r in users.values()):
                raise APP.pipeline.RunError("At least one administrator is required.")
            save_users(APP.cfg, users)
            for k in [k for k, v in APP.sessions.items() if v[0] == name]:
                APP.sessions.pop(k, None)
        return {"ok": True}

    def post_password(self, user, q):
        """Change your own password."""
        d = self._body_json()
        old, new = str(d.get("old", "")), str(d.get("new", ""))
        if not check_password(APP.cfg, user, old):
            raise APP.pipeline.RunError("The current password is not correct.")
        if password_problem(new):
            raise APP.pipeline.RunError(password_problem(new))
        with APP.lock:
            users = load_users(APP.cfg)
            rec = users[user]
            rec.update(hash_password(new, role=rec.get("role") or "admin"))
            save_users(APP.cfg, users)
        return {"ok": True}

    def post_logout(self, user, q):
        self._drain()
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            k, _, v = part.strip().partition("=")
            if k == COOKIE:
                APP.sessions.pop(v, None)
        self._json({"ok": True}, extra={"Set-Cookie": COOKIE + "=; Path=/; Max-Age=0"})

    def get_state(self, user, q):
        return APP.state(user, int(q.get("since") or 0))

    # ── runs ────────────────────────────────────────────────────
    def post_run_new(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            APP.run = APP.pipeline.Run.create(APP.runs_dir, d.get("name"), user, APP.cfg)
            APP.rev += 1
            APP.ai_opinions = {}
            APP.run.say("Run created by %s" % user, "info")
        return {"ok": True}

    def post_run_open(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            APP.open_run(str(d.get("id", "")))
        return {"ok": True}

    def post_run_delete(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            rid = os.path.basename(str(d.get("id", "")))
            if APP.run is not None and APP.run.run_id == rid:
                APP.run.delete()
                APP.run = None
            else:
                root = os.path.join(APP.runs_dir, rid)
                if os.path.exists(os.path.join(root, "meta.json")):
                    APP.pipeline.Run(root).delete()
            APP.rev += 1
        return {"ok": True}

    def post_config(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            run = APP.need_run()
            if "usd_rate" in d:
                try:
                    rate = float(str(d["usd_rate"]).replace(",", ""))
                    if not 1 < rate < 100000:
                        raise ValueError
                except ValueError:
                    raise APP.pipeline.RunError("The USD rate must be a number, e.g. 280.4673.")
                if run.meta.get("usd_rate") != rate and run.total is not None:
                    run.say("USD rate changed to %s by %s - press Process again to apply it."
                            % (rate, user), "warn")
                run.meta["usd_rate"] = rate
            if d.get("name"):
                run.meta["name"] = str(d["name"])[:80]
            if d.get("query_scope") in ("eligible", "all"):
                run.meta["query_scope"] = d["query_scope"]
            run.save_meta()
            APP.rev += 1
        return {"ok": True}

    def post_upload(self, user, q):
        body = _Counted(self.rfile, int(self.headers.get("Content-Length") or 0))
        try:
            with APP.lock:
                APP.busy()
                run = APP.need_run()
                if body.left > int(APP.cfg["max_upload_mb"]) * 1024 * 1024:
                    raise APP.pipeline.RunError("The file is larger than the upload limit.")
                if body.left <= 0:
                    raise APP.pipeline.RunError("The file is empty.")
                slot = q.get("slot", "")
                name = run.add_file(slot, q.get("name", "file"), body, body.left, user)
                run.say("%s uploaded by %s: %s" % (APP.pipeline.SLOTS[slot][0], user, name))
                if run.total is not None:
                    run.say("Input files changed after processing - press Process again to "
                            "apply them.", "warn")
                APP.rev += 1
        finally:
            body.drain()
        return {"ok": True, "name": name}

    def post_upload_remove(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            APP.need_run().remove_file(str(d.get("slot")), str(d.get("name")))
            APP.rev += 1
        return {"ok": True}

    # ── phases ──────────────────────────────────────────────────
    def post_process(self, user, q):
        self._drain()
        run = APP.need_run()
        blocking, _ = run.readiness()
        if blocking:
            raise APP.pipeline.RunError(" ".join(blocking))
        run.say("Processing started by %s" % user, "info")
        APP.start_job("process", "Starting", lambda progress: run.process(progress), "new")
        return {"ok": True}

    def post_generate(self, user, q):
        self._drain()
        run = APP.need_run()
        run._need()
        run.say("Report generation started by %s" % user, "info")
        APP.start_job("generate", "Starting", lambda progress: run.generate(progress), "processed")
        return {"ok": True}

    # ── review ──────────────────────────────────────────────────
    def get_query_file(self, user, q):
        with APP.lock:
            APP.busy()
            run = APP.need_run()
            name = "Query_File_%s.xlsx" % run.run_id
            path = run.p("outputs", name)
            run.build_query_workbook(path)
            run.say("Query file downloaded by %s" % user)
        self._file(path, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", name)

    def post_query_upload(self, user, q):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > 1024 * 1024 * 1024:
            self._drain()
            raise APP.pipeline.RunError("The file is empty or too large.")
        with APP.lock:
            run = APP.need_run()
            path = run.p("outputs", "query_upload_%d.xlsx" % int(time.time()))
            left = n
            with open(path, "wb") as fh:
                while left > 0:
                    block = self.rfile.read(min(1 << 20, left))
                    if not block:
                        break
                    fh.write(block)
                    left -= len(block)
            APP.busy()
            rep = run.apply_query_workbook(path, user)
            APP.rev += 1
        return rep

    def get_find(self, user, q):
        with APP.lock:
            APP.busy()
            return {"rows": APP.need_run().find(q.get("q", ""))}

    def post_edit(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            rep = APP.need_run().edit(str(d.get("row_id", "")), d.get("changes") or {}, user)
            APP.rev += 1
        return rep

    def post_cust_types(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            APP.need_run().set_cust_types(d.get("types") or [], user)
            APP.rev += 1
        return {"ok": True}

    def post_decide(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            run = APP.need_run()
            for item in d.get("items") or []:
                run.decide(str(item.get("side")), str(item.get("key")),
                           str(item.get("decision") or ""), user)
            APP.rev += 1
        return {"ok": True}

    # ── name review ─────────────────────────────────────────────
    def get_names(self, user, q):
        with APP.lock:
            APP.busy()
            run = APP.need_run()
            run._need()
            return names_review.page(run, run.data_dir, q.get("cat", "cut"),
                                     int(q.get("offset") or 0), min(int(q.get("limit") or 50), 200),
                                     q.get("q", ""))

    def post_names_decide(self, user, q):
        d = self._body_json()
        with APP.lock:
            APP.busy()
            rep = APP.need_run().name_decide(d.get("decisions") or [], user)
            APP.rev += 1
        return rep

    def post_ai_names_check(self, user, q):
        self._drain()
        run = APP.need_run()
        run._need()
        status = run.meta.get("status")

        def work(progress):
            try:
                n, p = names_review.ai_check(run, run.data_dir, APP.cfg, progress)
            except RuntimeError as e:
                raise APP.pipeline.RunError(str(e))
            run.say("AI name check: %d name(s) and %d spelling pair(s) answered" % (n, p), "ok")
        APP.start_job("ai_names", "Asking the model about names", work, status)
        return {"ok": True}

    # ── reports ─────────────────────────────────────────────────
    def get_download(self, user, q):
        run = APP.need_run()
        name = os.path.basename(q.get("file", ""))
        if name not in [o["file"] for o in run.meta.get("outputs", [])]:
            raise APP.pipeline.RunError("That report is no longer available.")
        run.say("Report %s downloaded by %s" % (name, user))
        self._file(run.p("outputs", name),
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", name)

    def get_rows(self, user, q):
        with APP.lock:
            APP.busy()
            return APP.need_run().page(q.get("sheet", ""), int(q.get("offset") or 0),
                                       min(int(q.get("limit") or 100), 500), q.get("q", ""))

    # ── AI assistance (advisory) ────────────────────────────────
    def post_ai_names(self, user, q):
        self._drain()
        import ai_assist
        run = APP.need_run()
        pend = [s for s in run.suggestion_list()][:100]
        if not pend:
            return {"opinions": {}}
        try:
            res = ai_assist.review_names(APP.cfg, pend)
        except RuntimeError as e:
            raise APP.pipeline.RunError(str(e))
        APP.ai_opinions = {s["side"] + "|" + s["key"]: r for s, r in zip(pend, res)}
        return {"opinions": APP.ai_opinions}

    def post_ai_explain(self, user, q):
        self._drain()
        import ai_assist
        run = APP.need_run()
        lines = [e["m"] for e in run.log if e["l"] in ("warn", "error")]
        try:
            return {"text": ai_assist.explain_log(APP.cfg, lines)}
        except RuntimeError as e:
            raise APP.pipeline.RunError(str(e))


def main():
    global APP
    cfg = load_settings()
    APP = App(cfg)
    if not load_users(cfg):
        print("No users exist yet - the first person to open the page creates the "
              "administrator account.", flush=True)
    runs = APP.list_runs()
    if runs:
        try:
            print("Restoring run %s ..." % runs[0]["id"], flush=True)
            APP.open_run(runs[0]["id"])
        except Exception as e:
            print("Could not restore the last run (%s); starting without one." % e)
            APP.run = None
    httpd = ThreadingHTTPServer((cfg["host"], int(cfg["port"])), Handler)
    httpd.daemon_threads = True
    scheme = "http"
    if cfg.get("tls_cert") and cfg.get("tls_key"):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cfg["tls_cert"], cfg["tls_key"])
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        scheme = "https"
    print("Remittance Rebate Calculator %s listening on %s://%s:%s  (%d worker processes)"
          % (APP.pipeline.VERSION, scheme, cfg["host"], cfg["port"], cfg["workers"]), flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
