"""
Name review: what the cleansing rules did to each distinct name, possible
spelling variants of the same person, and the reviewer's decisions.

Decisions are kept in data/names.json and apply to every run from then
on (the engine applies them during cleansing), so a name is reviewed
once, not every month:

  overrides  original name -> name to use        ("use this name")
  variants   cleansed name -> canonical spelling ("same person as")
  rejected   variant pairs judged NOT the same person

AI suggestions (vLLM) are advisory and checked: an AI-cleaned name is
only offered if it was made by deleting junk or splitting joined words
(engine.ai_name_valid) - it can never change a spelling.
"""
import collections
import datetime
import difflib
import json
import os
import re
import threading

import pandas as pd

import engine

_s = engine._s
NAME_COLS = ["Remitter Name", "Beneficiary Name"]
SIDE = {"Remitter Name": "Remitter", "Beneficiary Name": "Beneficiary"}
COL_OF = {v: k for k, v in SIDE.items()}

CATEGORIES = [
    ("cut", "Word cut or changed", "A word in the result is not in the original - most likely a rule mistake"),
    ("removed", "Words removed", "A real word was removed (digits, titles and tags are not counted)"),
    ("joined", "Joined words", "Two names written without a space"),
    ("flagged", "Flagged by the rules", "Joint name, too short, or very long word"),
    ("suspicious", "Suspicious result", "Single word, 3 letters or fewer, or digits"),
    ("link", "Replaced from LINK TITLE", "Beneficiary name taken from the account title"),
    ("minor", "Minor clean-up", "Only digits, titles, tags or punctuation removed"),
    ("reviewed", "Reviewed", "A decision is recorded for this name"),
]
CAT_LABEL = {k: v for k, v, _d in CATEGORIES}
MINOR_WORDS = {"MR", "MRS", "MS", "MISS", "DR", "SO", "DO", "WO", "CO", "S", "O", "D", "W", "C",
               "BIN", "BINT", "BNT", "IBN", "UMM", "NO", "NAME", "LAST", "FIRST", "CUSTOMER",
               "AC", "ACCOUNT", "ASAAN", "NA", "N", "A", "AA", "NAA", "PH", "MYSELF", "MY",
               "OLD", "SAVING", "SAVINGS", "REMITTANCE", "MIDDLE", "SURNAME", "SINGLE", "JAN",
               "JI", "G", "SONOF", "WIFEOF", "DAUGHTEROF", "SON", "WIFE", "DAUGHTER", "OF"}
AI_NAME_LIMIT = 3000
AI_PAIR_LIMIT = 1000
QUERY_CAP = 20000
_lock = threading.Lock()


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _words(v):
    return re.sub(r"[^A-Z0-9]+", " ", _s(v).upper().replace("&", " AND ")).split()


def clean_input(v):
    """A name typed by a reviewer, in the form the data uses."""
    v = re.sub(r"\s+", " ", _s(v).upper()).strip()
    if not v:
        return None, "empty"
    if not re.fullmatch(r"[A-Z0-9 .'\-/]+", v):
        return None, "letters, digits, spaces and . ' - / only"
    if len(v) > 120:
        return None, "too long"
    return v, None


# ── the shared decision file ─────────────────────────────────────
def path(data_dir):
    return os.path.join(data_dir, "names.json")


def load(data_dir):
    try:
        with open(path(data_dir), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        d = {}
    for k in ("overrides", "variants", "rejected"):
        d.setdefault(k, {})
    return d


def save(data_dir, d):
    import pipeline
    os.makedirs(data_dir, exist_ok=True)
    tmp = path(data_dir) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, indent=1, ensure_ascii=False)
    pipeline.replace_file(tmp, path(data_dir))


def push(d):
    engine.NAME_OVERRIDES = {k: v["name"] for k, v in d["overrides"].items() if v.get("name")}
    engine.NAME_VARIANTS = {k: v["to"] for k, v in d["variants"].items() if v.get("to")}


def ai_cache_path(data_dir):
    return os.path.join(data_dir, "cache", "ai_names.json")


def load_ai(data_dir):
    try:
        with open(ai_cache_path(data_dir), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        d = {}
    d.setdefault("clean", {})
    d.setdefault("pairs", {})
    return d


def save_ai(data_dir, d):
    import pipeline
    os.makedirs(os.path.dirname(ai_cache_path(data_dir)), exist_ok=True)
    tmp = ai_cache_path(data_dir) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False)
    pipeline.replace_file(tmp, ai_cache_path(data_dir))


# ── analysis ─────────────────────────────────────────────────────
def _vocabulary(total):
    """How often each word occurs in the cleansed names of this run."""
    vc = collections.Counter()
    for col in NAME_COLS:
        if col in total.columns:
            for name, n in total[col].pipe(engine._sv).value_counts().items():
                for w in name.split():
                    vc[w] += int(n)
    return vc


def split_joined(name, vocab, min_freq=30):
    """'TAHIR MEHMOODMUHAMMAD BUTT' -> 'TAHIR MEHMOOD MUHAMMAD BUTT' when
    both halves are common words in this month's names and the joined
    word itself is rare. None when nothing is split."""
    out, changed = [], False
    for w in _s(name).split():
        best = None
        if len(w) >= 8 and vocab.get(w, 0) < 5 and w.isalpha():
            for i in range(3, len(w) - 2):
                a, b = w[:i], w[i:]
                fa, fb = vocab.get(a, 0), vocab.get(b, 0)
                if fa >= min_freq and fb >= min_freq:
                    score = min(fa, fb)
                    if best is None or score > best[0]:
                        best = (score, a + " " + b)
        if best:
            out.append(best[1])
            changed = True
        else:
            out.append(w)
    return " ".join(out) if changed else None


def _category(orig, rule, cur, flag, reviewed, joined):
    if reviewed:
        return "reviewed"
    o, r = _words(orig), _words(rule)
    if not r:
        return "suspicious"
    if o != r:
        if not set(r) <= set(o):
            return "link" if not set(r) & set(o) else "cut"
        gone = [w for w in o if w not in set(r)]
        if any(not (w.isdigit() or w in MINOR_WORDS) for w in gone):
            return "removed"
    if joined:
        return "joined"
    if flag:
        return "flagged"
    if any(ch.isdigit() for ch in rule) or len(r) == 1 or len("".join(r)) <= 3:
        return "suspicious"
    return "minor" if o != r else None


def items(run, data_dir):
    """Distinct names with their rule result and review category."""
    key = (id(run.total), len(run.total), run.names_rev)
    cache = getattr(run, "_names_cache", None)
    if cache and cache[0] == key:
        return cache[1]
    dec = load(data_dir)
    ai = load_ai(data_dir)["clean"]
    vocab = _vocabulary(run.total)
    t = run.total
    rows = []
    for col in NAME_COLS:
        oc = engine.COMM_ORIG_PREFIX + col
        if col not in t.columns or oc not in t.columns:
            continue
        g = pd.DataFrame({
            "o": t[oc].pipe(engine._sv),
            "r": (t["_rule " + col] if "_rule " + col in t.columns else t[col]).pipe(engine._sv),
            "c": t[col].pipe(engine._sv),
            "f": (t["_flag " + col] if "_flag " + col in t.columns else
                  pd.Series("", index=t.index)).pipe(engine._sv)})
        g = g[g["o"].ne("") | g["c"].ne("")]
        g = g.groupby(["o", "r", "c", "f"], sort=False).size().reset_index(name="n")
        for o, r, c, f, n in g.itertuples(index=False, name=None):
            k = engine.name_key(o)
            reviewed = k in dec["overrides"] or (r != c and r in dec["variants"])
            joined = split_joined(r, vocab) if not reviewed else None
            cat = _category(o, r, c, f, reviewed, joined)
            if cat is None:
                continue
            a = ai.get(k)
            sugg, by = (joined, "word split") if joined else (None, "")
            ai_note = ""
            if a and a.get("rule") == r:
                if a.get("status") == "differs":
                    sugg, by = a["name"], "AI"
                ai_note = {"agrees": "AI agrees", "differs": "AI suggests a change",
                           "rejected": "AI answer rejected (it changed the spelling)"}.get(
                    a.get("status"), "")
            rows.append({"side": SIDE[col], "key": k, "original": o, "rule": r, "current": c,
                         "flag": f, "rows": int(n), "cat": cat, "suggestion": sugg or "",
                         "by": by, "ai": ai_note,
                         "decision": (dec["overrides"].get(k) or {}).get("name", "")})
    rows.sort(key=lambda x: -x["rows"])
    run._names_cache = (key, rows)
    return rows


def _alike(a, b):
    """Same words apart from spacing, or the same number of words with
    every word spelled nearly the same (MUHAMMAD/MOHAMMAD yes,
    ASLAM/SALEEM no)."""
    if a.replace(" ", "") == b.replace(" ", ""):
        return True
    wa, wb = a.split(), b.split()
    if len(wa) != len(wb):
        return False
    for x, y in zip(wa, wb):
        if x != y and difflib.SequenceMatcher(None, x, y).ratio() < 0.75:
            return False
    return True


def variants(run, data_dir):
    """Possible spelling variants of the same person: names that sound
    alike AND appear with the same R.E and the same counterpart (the
    other side's name). The more frequent spelling is proposed."""
    key = (id(run.total), len(run.total), run.names_rev)
    cache = getattr(run, "_variants_cache", None)
    if cache and cache[0] == key:
        return cache[1]
    dec = load(data_dir)
    ai = load_ai(data_dir)["pairs"]
    t = run.total
    re_name = t["R.E Name"].pipe(engine._sv) if "R.E Name" in t.columns else ""
    freq = collections.Counter()
    for col in NAME_COLS:
        freq.update({k: int(v) for k, v in t[col].pipe(engine._sv).value_counts().items()})
    words = _vocabulary(t)
    pairs = {}
    for col, other in (("Remitter Name", "Beneficiary Name"), ("Beneficiary Name", "Remitter Name")):
        if col not in t.columns or other not in t.columns:
            continue
        n = t[col].pipe(engine._sv)
        o = t[other].pipe(engine._sv)
        d = pd.DataFrame({"n": n, "c": re_name + "|" + o})[n.ne("") & o.ne("")].drop_duplicates()
        d["s"] = d["n"].pipe(engine._mu, engine.name_skeleton)
        d = d[d["s"].str.len() >= 3]
        d = d[d.groupby(["c", "s"])["n"].transform("nunique") >= 2]
        for (_c, _s2), names in d.groupby(["c", "s"])["n"]:
            names = sorted(set(names), key=lambda x: (-freq[x], -sum(words.get(w, 0)
                                                                     for w in x.split()), x))
            canon = names[0]
            for v in names[1:]:
                if not _alike(canon, v):
                    continue
                pk = v + "|" + canon
                if pk in dec["rejected"] or v in dec["variants"]:
                    continue
                p = pairs.setdefault(pk, {"side": SIDE[col], "name": v, "canonical": canon,
                                          "rows": freq[v], "canonical_rows": freq[canon],
                                          "contexts": 0})
                p["contexts"] += 1
    out = sorted(pairs.values(), key=lambda p: (-p["contexts"], -p["rows"]))
    for p in out:
        a = ai.get(p["name"] + "|" + p["canonical"])
        p["ai"] = (a or {}).get("same", "")
        p["ai_reason"] = (a or {}).get("reason", "")
    run._variants_cache = (key, out)
    return out


def summary(run, data_dir):
    it = items(run, data_dir)
    counts = collections.Counter(x["cat"] for x in it)
    rows = collections.Counter()
    for x in it:
        rows[x["cat"]] += x["rows"]
    var = variants(run, data_dir)
    dec = load(data_dir)
    return {"categories": [{"id": k, "label": v, "hint": h, "names": counts.get(k, 0),
                            "rows": rows.get(k, 0)} for k, v, h in CATEGORIES],
            "variants": len(var), "variant_rows": sum(p["rows"] for p in var),
            "dictionary": {"overrides": len(dec["overrides"]), "variants": len(dec["variants"])},
            "ai_pending": sum(1 for x in it if x["cat"] not in ("reviewed", "minor") and not x["ai"])}


def page(run, data_dir, cat, offset, limit, q=""):
    q = _s(q).upper()
    if cat == "variants":
        rows = variants(run, data_dir)
        if q:
            rows = [p for p in rows if q in p["name"] or q in p["canonical"]]
    else:
        rows = [x for x in items(run, data_dir) if x["cat"] == cat]
        if q:
            rows = [x for x in rows if q in x["original"].upper() or q in x["current"]]
    return {"cat": cat, "total": len(rows), "rows": rows[offset:offset + limit]}


# ── applying decisions to the open run ──────────────────────────
def recompute(run, mask):
    """Re-derive the name columns of the masked rows from the original
    name, the rule result and the current decisions."""
    n = 0
    for col in NAME_COLS:
        oc, rc = engine.COMM_ORIG_PREFIX + col, "_rule " + col
        if col not in run.total.columns or oc not in run.total.columns:
            continue
        m = mask if not isinstance(mask, dict) else mask[col]
        if not m.any():
            continue
        rule = run.total.loc[m, rc] if rc in run.total.columns else run.total.loc[m, col]
        new = engine.apply_name_dictionary(run.total.loc[m, oc], rule)
        n += int(new.pipe(engine._sv).ne(run.total.loc[m, col].pipe(engine._sv)).sum())
        run.total.loc[m, col] = new
        run.total.loc[m, "_flag " + col] = engine._flag_names(new)
    return n


def affected(run, keys=(), names=()):
    keys, names = set(keys), set(names)
    masks = {}
    for col in NAME_COLS:
        oc, rc = engine.COMM_ORIG_PREFIX + col, "_rule " + col
        m = pd.Series(False, index=run.total.index)
        if keys and oc in run.total.columns:
            m |= run.total[oc].pipe(engine._mu, engine.name_key).isin(keys)
        if names:
            m |= run.total[col].pipe(engine._sv).isin(names)
            if rc in run.total.columns:
                m |= run.total[rc].pipe(engine._sv).isin(names)
        masks[col] = m
    return masks


def decide(run, data_dir, decisions, user, source):
    """decisions: list of
         {"kind": "name", "key": k, "name": "..."}         use this name
         {"kind": "name", "key": k, "name": None}          undo
         {"kind": "variant", "name": v, "to": c}           same person
         {"kind": "variant", "name": v, "to": None}        undo
         {"kind": "reject", "name": v, "to": c}            not the same person
    Returns (applied journal entries, rejected [(decision, reason)])."""
    with _lock:
        d = load(data_dir)
        keys, names, entries, bad = set(), set(), [], []
        stamp = _now()
        for x in decisions:
            kind = x.get("kind")
            if kind == "name":
                k = engine.name_key(x.get("key"))
                if not k:
                    bad.append((x, "no original name"))
                    continue
                if x.get("name") in (None, ""):
                    if d["overrides"].pop(k, None) is None:
                        continue
                    new = None
                else:
                    new, why = clean_input(x["name"])
                    if why:
                        bad.append((x, why))
                        continue
                    if (d["overrides"].get(k) or {}).get("name") == new:
                        continue
                    d["overrides"][k] = {"name": new, "by": user, "at": stamp, "source": source}
                keys.add(k)
                entries.append({"action": "names", "kind": "name", "key": k, "new": new,
                                "column": "Name", "old": x.get("rule", ""), "row_id": "",
                                "urn": "", "rows": 0})
            elif kind in ("variant", "reject"):
                v, c = _s(x.get("name")).upper(), _s(x.get("to")).upper()
                if not v:
                    continue
                if kind == "reject":
                    d["rejected"][v + "|" + c] = {"by": user, "at": stamp}
                    entries.append({"action": "names", "kind": "reject", "key": v, "new": c,
                                    "column": "Spelling", "old": v, "row_id": "", "urn": "",
                                    "rows": 0})
                    continue
                if not c:
                    if d["variants"].pop(v, None) is None:
                        continue
                    names.add(v)
                else:
                    c = (d["variants"].get(c) or {}).get("to") or c       # no chains
                    if c == v:
                        continue
                    d["variants"][v] = {"to": c, "by": user, "at": stamp, "source": source}
                    for other, rec in d["variants"].items():
                        if rec.get("to") == v:
                            rec["to"] = c
                    names.update({v, c})
                entries.append({"action": "names", "kind": "variant", "key": v, "new": c or None,
                                "column": "Spelling", "old": v, "row_id": "", "urn": "",
                                "rows": 0})
        save(data_dir, d)
        push(d)
    n = recompute(run, affected(run, keys, names)) if (keys or names) else 0
    if entries:
        entries[-1]["rows"] = n
    run.names_rev += 1
    return entries, bad


def replay(run, entries):
    """After a restart: re-apply name decisions recorded in the journal."""
    keys = {e["key"] for e in entries if e.get("kind") == "name"}
    names = set()
    for e in entries:
        if e.get("kind") == "variant":
            names.add(e["key"])
            if e.get("new"):
                names.add(e["new"])
    if keys or names:
        recompute(run, affected(run, keys, names))
    run.names_rev += 1


# ── AI check ─────────────────────────────────────────────────────
NAME_PROMPT = (
    "You clean person names from Pakistani remittance records. For each line you get the "
    "ORIGINAL text and the result of the bank's cleaning rules. Return the correct clean "
    "name: upper case; remove only junk (digits, phone or account numbers, bank or account "
    "words, 'S/O', 'D/O', 'W/O', titles like MR/MRS/DR, placeholder text like NO LAST NAME); "
    "split words that were joined without a space (MEHMOODMUHAMMAD -> MEHMOOD MUHAMMAD); keep "
    "every real name word, including ABU, SYED, MALIK, BIBI, KHAN; keep joint names with AND. "
    "NEVER change the spelling of a word and never add a word. If the rule result is already "
    "right, return it unchanged. Answer ONLY with a JSON array, same order: "
    '{"n": <number>, "name": "<clean name>"}')

PAIR_PROMPT = (
    "Each line has two spellings of a name seen on remittances from the same sender to the "
    "same receiver. Say whether they are the SAME person written differently (typo, spacing, "
    "common spelling variant such as MUHAMMAD / MOHAMMAD) or DIFFERENT people (a different "
    "name, e.g. FAISAL vs FAZAL, or a different family name). Answer ONLY with a JSON array, "
    'same order: {"n": <number>, "same": "yes" | "no" | "unsure", "reason": "<max 10 words>"}')


def _parse(text):
    m = re.search(r"\[.*\]", text, flags=re.S)
    try:
        return {int(i.get("n", 0)): i for i in json.loads(m.group(0) if m else text)}
    except Exception:
        return {}


def ai_check(run, data_dir, settings, progress=lambda label, i, n: None):
    """Ask the model about the names still to review and the spelling
    variants. Results are cached across runs (data/cache/ai_names.json)."""
    import concurrent.futures as cf
    import ai_assist
    st = ai_assist.status(settings)
    if not st["available"]:
        raise RuntimeError(st["detail"])
    cache = load_ai(data_dir)
    todo, seen = [], set()
    for x in items(run, data_dir):
        if x["cat"] in ("reviewed", "minor") or x["key"] in seen:
            continue
        a = cache["clean"].get(x["key"])
        if a and a.get("rule") == x["rule"]:
            continue
        seen.add(x["key"])
        todo.append(x)
        if len(todo) >= AI_NAME_LIMIT:
            break
    pairs = [p for p in variants(run, data_dir)
             if (p["name"] + "|" + p["canonical"]) not in cache["pairs"]][:AI_PAIR_LIMIT]
    blocks = [("names", todo[i:i + 25]) for i in range(0, len(todo), 25)]
    blocks += [("pairs", pairs[i:i + 25]) for i in range(0, len(pairs), 25)]
    if not blocks:
        return 0, 0

    def ask(block):
        kind, part = block
        if kind == "names":
            prompt = "\n".join('%d. ORIGINAL: "%s"  RULE RESULT: "%s"' % (i + 1, x["original"], x["rule"])
                               for i, x in enumerate(part))
            return kind, part, _parse(ai_assist.chat(settings, NAME_PROMPT, prompt,
                                                     max_tokens=40 * len(part) + 100))
        prompt = "\n".join('%d. "%s"  |  "%s"' % (i + 1, p["name"], p["canonical"])
                           for i, p in enumerate(part))
        return kind, part, _parse(ai_assist.chat(settings, PAIR_PROMPT, prompt,
                                                 max_tokens=40 * len(part) + 100))

    done_n = done_p = errors = 0
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(ask, b) for b in blocks]
        for i, f in enumerate(cf.as_completed(futs)):
            progress("Asking the model about names (%d of %d batches)" % (i + 1, len(blocks)),
                     i, len(blocks))
            try:
                kind, part, got = f.result()
            except Exception:
                errors += 1
                continue
            for j, x in enumerate(part):
                item = got.get(j + 1) or {}
                if kind == "names":
                    name = re.sub(r"\s+", " ", _s(item.get("name")).upper()).strip()
                    if not name:
                        continue
                    status = ("agrees" if name == x["rule"] else
                              "differs" if engine.ai_name_valid(x["original"], name) else "rejected")
                    cache["clean"][x["key"]] = {"rule": x["rule"], "name": name, "status": status}
                    done_n += 1
                else:
                    same = _s(item.get("same")).lower()
                    cache["pairs"][x["name"] + "|" + x["canonical"]] = {
                        "same": same if same in ("yes", "no", "unsure") else "unsure",
                        "reason": _s(item.get("reason"))[:120]}
                    done_p += 1
            if (i + 1) % 20 == 0:
                save_ai(data_dir, cache)
    save_ai(data_dir, cache)
    run.names_rev += 1
    if errors and not (done_n or done_p):
        raise RuntimeError("The model did not answer any request.")
    return done_n, done_p


# ── query file sheets ───────────────────────────────────────────
SHEET_NAMES = "Name Review"
SHEET_VARIANTS = "Spelling Variants"
NAME_HEAD = ["Side", "Original", "Rule Result", "Suggestion", "Suggested By", "Category",
             "Transactions", "Accept Suggestion (Y)", "Use Name"]
VAR_HEAD = ["Side", "Name", "Same Person As", "Transactions", "Seen Together", "AI Opinion",
            "Same Person? (Y/N)"]


def write_sheets(run, data_dir, wb, fmt):
    """Add the two name sheets to the query workbook (xlsxwriter)."""
    rows = [x for x in items(run, data_dir) if x["cat"] not in ("reviewed", "minor")][:QUERY_CAP]
    ws = wb.add_worksheet(SHEET_NAMES)
    ws.freeze_panes(1, 3)
    ws.set_row(0, 30)
    for j, h in enumerate(NAME_HEAD):
        amber = j >= 7
        ws.write_string(0, j, h, fmt["head_in"] if amber else fmt["head"])
        ws.set_column(j, j, 38 if j in (1, 2, 3) else 16 if amber else 13, fmt["cell_in"] if amber else None)
    for i, x in enumerate(rows, start=1):
        vals = [x["side"], x["original"], x["rule"], x["suggestion"], x["by"] or x["ai"],
                CAT_LABEL[x["cat"]]]
        for j, v in enumerate(vals):
            if v:
                ws.write_string(i, j, v)
        ws.write_number(i, 6, x["rows"])
    if rows:
        ws.autofilter(0, 0, len(rows), len(NAME_HEAD) - 1)
        ws.data_validation(1, 7, len(rows), 7, {"validate": "list", "source": ["Y"]})
    var = variants(run, data_dir)[:QUERY_CAP]
    ws = wb.add_worksheet(SHEET_VARIANTS)
    ws.freeze_panes(1, 3)
    ws.set_row(0, 30)
    for j, h in enumerate(VAR_HEAD):
        amber = j == 6
        ws.write_string(0, j, h, fmt["head_in"] if amber else fmt["head"])
        ws.set_column(j, j, 34 if j in (1, 2) else 18 if amber else 13, fmt["cell_in"] if amber else None)
    for i, p in enumerate(var, start=1):
        for j, v in enumerate([p["side"], p["name"], p["canonical"]]):
            ws.write_string(i, j, v)
        ws.write_number(i, 3, p["rows"])
        ws.write_number(i, 4, p["contexts"])
        if p["ai"]:
            ws.write_string(i, 5, p["ai"] + (" - " + p["ai_reason"] if p["ai_reason"] else ""))
    if var:
        ws.autofilter(0, 0, len(var), len(VAR_HEAD) - 1)
        ws.data_validation(1, 6, len(var), 6, {"validate": "list", "source": ["Y", "N"]})
    return {SHEET_NAMES: len(rows), SHEET_VARIANTS: len(var)}


def read_sheets(book):
    """Decisions found in an uploaded query workbook (calamine frames,
    header=None). Returns (decisions, rejected rows)."""
    out, bad = [], []
    for sheet, head in ((SHEET_NAMES, NAME_HEAD), (SHEET_VARIANTS, VAR_HEAD)):
        raw = book.get(sheet)
        if raw is None or len(raw) < 2:
            continue
        hdr = [_s(v) for v in raw.iloc[0].tolist()]
        col = {h: hdr.index(h) for h in head if h in hdr}
        if len(col) < len(head):
            bad.append({"sheet": sheet, "row_id": "", "column": "", "value": "",
                        "reason": "headings were changed - sheet ignored"})
            continue
        for r in raw.iloc[1:].itertuples(index=False, name=None):
            g = lambda h: _s(r[col[h]]) if col[h] < len(r) else ""
            if sheet == SHEET_NAMES:
                use, acc = g("Use Name"), g("Accept Suggestion (Y)").upper()
                if not use and acc not in ("Y", "YES"):
                    if acc:
                        bad.append({"sheet": sheet, "row_id": "", "column": "Accept Suggestion (Y)",
                                    "value": acc, "reason": "type Y to accept"})
                    continue
                name = use or g("Suggestion")
                if not name:
                    bad.append({"sheet": sheet, "row_id": "", "column": "Accept Suggestion (Y)",
                                "value": g("Original"), "reason": "there is no suggestion to accept"})
                    continue
                out.append({"kind": "name", "key": g("Original"), "name": name, "rule": g("Rule Result")})
            else:
                yn = g("Same Person? (Y/N)").upper()
                if yn in ("Y", "YES"):
                    out.append({"kind": "variant", "name": g("Name"), "to": g("Same Person As")})
                elif yn in ("N", "NO"):
                    out.append({"kind": "reject", "name": g("Name"), "to": g("Same Person As")})
                elif yn:
                    bad.append({"sheet": sheet, "row_id": "", "column": "Same Person? (Y/N)",
                                "value": yn, "reason": "type Y or N"})
    return out, bad
