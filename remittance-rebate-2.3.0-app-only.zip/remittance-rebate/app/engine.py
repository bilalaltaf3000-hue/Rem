"""
Remittance Rebate Calculator - processing engine
(HBL PRI - Data Consolidation & Cleansing
==========================================
Step 1: Merges 4 source files (RH, FM, GRS, RIMPIM) into one consolidated file.
Step 2: Cleanses the consolidated data (names, IDs, purposes, dates).

SETUP:
    pip install pandas python-calamine openpyxl

USAGE:
    1. Place your 4 source files in the same folder as this script
    2. Update the file paths below
    3. Run:  python run_consolidation.py
    4. Outputs: consolidated_output.xlsx + cleansed_output.xlsx

In the web application this module is driven by pipeline.py; it is not
run as a script.)
"""

import pandas as pd
import os
import re
import time
import sys


# ╔══════════════════════════════════════════════════════════════════╗
# ║  PATCH CONFIG                                                    ║
# ╚══════════════════════════════════════════════════════════════════╝

# Date ordering PER SOURCE. Established by counting how often the first vs
# second component exceeded 12 across 496,611 rows:
#
#     Channel    rows      first>12   second>12   -> verdict
#     FM            713         713           0      day-first
#     GRS       320,408     320,408           0      day-first
#     RH        174,661           0      89,619      month-first
#     RIM PIM       829         829           0      day-first
#
# No channel showed both, so each is internally consistent.
#
# If a source ever changes its export format, the "could not parse" count
# printed by cleanse() will jump - that is the signal to revisit this map.
CHANNEL_DAYFIRST = {
    "RH":      False,   # month-first
    "FM":      False,    # day-first
    "GRS":     False,    # day-first
    "RIM PIM": False,    # day-first
}

# Used for rows whose Channel is missing or not in the map above.
DEFAULT_DAYFIRST = False

DATE_COLUMNS = ["Upload Date", "Open Date", "Value Date", "Payment Date"]

# ── Number presentation ─────────────────────────────────────────────
# Excel number formats. The cell keeps a real number - only how it is
# displayed changes - so SUM, sorting and filtering all still work.
NUMBER_FORMATS = {
    "Amount": "#,##0.00",
    "FCY Amount": "#,##0.00",
    "USD Eqv.": "#,##0.00",
    # Four decimals: 280.4673 shown as 280.47 reads like a rounding error.
    "USD Rate": "#,##0.0000",
}

# Columns that must be numeric for the formats above to take effect.
NUMBER_COLUMNS = list(NUMBER_FORMATS)

# Output sheet presentation, matching the blanks workbook.
OUTPUT_HEADER_COLOR = "#00857D"
OUTPUT_HEADER_HEIGHT = 30
OUTPUT_MAX_WIDTH = 46


# ── Business rules config (PART 4) ──────────────────────────────────
# Exposed here rather than buried in the function, so the future GUI can
# set them at runtime instead of editing code.

ORRE_TAG = "ORRE"                    # what to look for in R.E
ORRE_MATCH_MODE = "contains"         # "contains" or "startswith"
ORRE_MATCH_CASE_SENSITIVE = False

ORRE_HBL_VALUE = "ORRE HBL"          # R.E when Bene Bank IS HBL
ORRE_OTHER_VALUE = "ORRE 3rd Bank"   # R.E when Bene Bank is NOT HBL
ORRE_HBL_BANK = "HBL"                # compared case-insensitively, trimmed

ORRE_SHEET_NAME = "ORRE"             # worksheet for the removed rows

# A blank URN does not end with a digit. True = send those to the ORRE tab
# (literal reading). Set False to leave them in the main sheet untouched.
ORRE_BLANK_URN_TO_TAB = True

# ── Cancelled rule ──────────────────────────────────────────────────
REFUNDS_FILE = "refunds.xlsx"
REFUND_REF_COL = "Reference No."     # exact header in refunds.xlsx
REFUND_AMT_COL = "Amount"

CANCELLED_SHEET_NAME = "Cancelled"

# Decimal places used to build the amount key on BOTH sides. The refund
# file contains values like 10002.44, so 2 is required - 0 would match
# 10002.44 against 10002.00.
AMOUNT_KEY_DECIMALS = 2

# Set False to key on URN alone (more forgiving, but a reused URN would
# then pull the wrong row).
REFUND_KEY_INCLUDES_AMOUNT = True

# Long, unambiguous tokens: matched anywhere (catches REFUNDED,
# CANCELLATION). Short tokens are handled separately below.
CANCEL_KEYWORDS = [
    "refund", "refnd", "refund", "refud", "refnud", "reufnd",
    "cancel", "cancle", "cancal", "cacel", "canel", "cancell",
    "reversal", "reversed",
]

# Ambiguous abbreviations: whole-word only, so they cannot fire from
# inside an unrelated string.
CANCEL_KEYWORDS_WORD = ["cncl", "cnl", "rfnd", "cnclld", "canc", "rfd"]

# ORRE first, then Cancelled on what remains (no row in two tabs).
# Set to ["cancelled", "orre"] to reverse.
RULE_ORDER = ["orre", "cancelled"]

# ── USD conversion ──────────────────────────────────────────────────
# SET THIS EACH MONTH. Example: USD_RATE = 280.4673
# Leave as None to skip the step entirely (nothing is written) rather than
# filling the column with a stale or wrong rate.
USD_RATE = None

USD_RATE_COL = "USD Rate"
USD_EQV_COL = "USD Eqv."
USD_EQV_DECIMALS = 2

# ── RDA classification ──────────────────────────────────────────────
RDA_OTHER_FILE = "RDA-Other.xlsx"
RDA_HBL_FOLDER = "RDA-HBL"           # folder of .xlsx files

RDA_COL = "RDA / NON RDA"
RDA_COMMENT_COL = "RDA Comment"      # inserted right after RDA_COL

RDA_VALUE_3RD = "3RD BANK RDA"
RDA_VALUE_HBL = "RDA HBL"
RDA_VALUE_NON = "Non RDA"

RDA_OTHER_UNMATCH_SHEET = "RDA-Other-Unmatch"

# Header text to find in the RDA-HBL files. Matched case-insensitively
# with all whitespace removed, so "Transaction Reference Number" and
# "transaction  reference number" both hit.
RDA_HBL_REF_COL = "transaction reference number"

# Some sheets put headers on row 1, some on row 2. Rows scanned looking
# for the header before giving up on a sheet.
RDA_HBL_HEADER_SCAN_ROWS = 8

# Account No patterns needing manual review: (starts_with, ends_with).
# The RDA Comment is written as "0786+44" etc.
RDA_REVIEW_PATTERNS = [
    ("0786", "99"), ("0786", "44"),
    ("5000", "99"), ("5000", "44"),
]

# Only flag when RDA / NON RDA is one of these (case-insensitive).
RDA_REVIEW_WHEN = ["Non RDA", "3RD BANK RDA"]

# ── CNIC validation / backfill ──────────────────────────────────────
CNIC_COL = "CNIC NO."

# A valid CNIC: exactly 13 digits, numeric only, no leading zero.
CNIC_LENGTH = 13

# Backfill A - Mode == "OC"
CNIC_OC_FILE = "7122.xlsx"
CNIC_OC_MODE = "OC"
CNIC_OC_SOURCE_COL = "Nar 2 - CNIC"
CNIC_OC_KEY_COL = "URN"              # key column inside 7122.xlsx

# Backfill B - Channel == "FM". Re-reads the FM source because
# "Naration line 3" is not in FM_MAPPING and never reached the
# consolidated file. Joins main URN -> fm.xlsx "Reference".
CNIC_FM_CHANNEL = "FM"
CNIC_FM_KEY_COL = "Reference"
CNIC_FM_SOURCE_COL = "Naration line 3"

# ── Account No / CNIC ───────────────────────────────────────────────
ACCOUNT_CNIC_COL = "Account No / CNIC"
ACCOUNT_CNIC_MODE = "OC"             # this Mode uses the CNIC form
ACCOUNT_CNIC_PREFIX = "CNIC - "
ACCOUNT_ACCT_PREFIX = "A/C - "

# True  = an OC row with a blank CNIC falls back to "A/C - " + Account No
# False = it is left blank (no dangling "CNIC - " text)
ACCOUNT_CNIC_FALLBACK = False

# ── Account No length rule + CNIC-A/C lookup (Mode == AC) ───────────
AC_MODE = "AC"

# Valid Account No lengths. A 24-length value is truncated to its
# rightmost 14; anything not in this set is blanked.
AC_VALID_LENGTHS = (14, 24)
AC_KEEP_RIGHT = 14

# Length is measured after stripping spaces and hyphens only. A PK
# prefix is NOT stripped - it counts toward the 24.
AC_STRIP_FOR_LENGTH = r"[\s\u00a0-]"

# Lookup: main "Account No" -> DL1534 "ext_acct_num", fetch "cnic"
AC_CNIC_FILE = "DL1534.xlsx"
AC_CNIC_KEY_COL = "ext_acct_num"
AC_CNIC_SOURCE_COL = "cnic"

# New column, inserted immediately after Account No
AC_CNIC_COL = "CNIC-A/C"

# A value starting with this is a passport: foreign nationals have no
# CNIC, so it is kept verbatim rather than failing the 13-digit test.
AC_PASSPORT_PREFIX = "P"

# Account type, read from DL1534 beside cnic.
# UAT: commercial tagging uses the CUSTOMER type, not the account type.
AC_ACCT_TYPE_COL = "cust_type"        # column name inside DL1534
ACCT_TYPE_COL = "Cust Type"           # column added to our sheet

# ── TOTAL / SBP Claim split ─────────────────────────────────────────
TOTAL_SHEET = "TOTAL"
SBP_SHEET = "SBP Claim"

SBP_NO_CLAIM_VALUE = "NO CLAIM"       # matched case-insensitively
SBP_CM_MODE = "CM"
SBP_USD_THRESHOLD = 200.0             # strictly less than
SBP_NON_RDA_VALUE = "Non RDA"         # everything else moves to RDA

SBP_UK_URN_PREFIX = "G1"
SBP_UK_RE_NAME = "HABIB BANK LIMITED LONDON"

# Tab names, in extraction order.
SBP_TAB_NO_CLAIM = "No Claim"
SBP_TAB_CM = "CM"
SBP_TAB_BELOW_200 = "Below US$200"
SBP_TAB_BENE_COMM = "Bene Comm"
SBP_TAB_REME_COMM = "Reme Comm"
SBP_TAB_UK_PENSION = "HBL UK WORKER PENSION"
SBP_TAB_RDA = "RDA"

# Which acct_type values mean a commercial beneficiary. Set from the GUI;
# empty means the AC branch of the Bene Comm rule matches nothing.
COMMERCIAL_ACCT_TYPES = []

# Folder of commercial-name workbooks. Each has two sheets: Remi Com
# (remitters) and Bene Com (beneficiaries).
COMMERCIAL_FOLDER = ""
COMM_REMI_SHEET = "Remi Com"
COMM_BENE_SHEET = "Bene Com"

# The workbooks are not consistent: the 2026 files say "REMI COM", the
# 2025 files say "REME COM". Accepted spellings, then a prefix fallback
# for anything not listed. All matched ignoring case and whitespace.
COMM_REMI_ALIASES = ["Remi Com", "Reme Com", "Rem Com", "Remitter Com",
                     "Remmi Com", "Remitters"]
COMM_BENE_ALIASES = ["Bene Com", "Beneficiary Com", "Ben Com",
                     "Benee Com", "Beneficiaries"]
COMM_REMI_PREFIXES = ["REMI", "REME", "REM"]
COMM_BENE_PREFIXES = ["BENE", "BEN"]
COMM_REMI_COL = "Remitter Name"
COMM_BENE_COL = "Beneficiary Name"

# Modes excluded from the name-based Bene Comm lookup. AC is handled by
# acct_type; OC is never commercial.
SBP_BENE_NAME_EXCLUDE_MODES = ("AC", "OC")

# ── Equations ───────────────────────────────────────────────────────
# equation column -> (key column, how many rows per key may stay)
# KEY-1/2/3 contain Open Date, so their group is a DAY   -> 1 allowed.
# KEY-4/5/6 omit it, so their group is the MONTH         -> 5 allowed.
# Key column names. Defined HERE, above EQUATIONS, because module level
# executes top to bottom and EQUATIONS refers to them. The column header
# is the formula itself, so the sheet needs no legend. "Bene ID" is
# Account No / CNIC, which carries its own "A/C - " or "CNIC - " tag.
KEY_1 = "R.E Name + Open Date + Rem Name + Bene Name"
KEY_2 = "R.E Name + Open Date + Remitter ID + Bene ID"
KEY_3 = "R.E Name + Open Date + Remitter ID + CNIC A/C"
KEY_4 = "R.E Name + Rem Name + Bene Name"
KEY_5 = "R.E Name + Remitter ID + Bene ID"
KEY_6 = "R.E Name + Remitter ID + CNIC A/C"

EQUATIONS = [
    ("EQ-1", KEY_1, 1),
    ("EQ-2", KEY_2, 1),
    ("EQ-3", KEY_3, 1),
    ("EQ-4", KEY_4, 5),
    ("EQ-5", KEY_5, 5),
    ("EQ-6", KEY_6, 5),
]

SPLIT_SHEET = "SPLIT"
SPLIT_REASON_COL = "Split Reason"

# Which rows survive a limit. "date"   = earliest Open Date, then original
# order (the default).            "amount" = largest Amount first.
EQ_ORDER_BY = "date"

# Marker text. TRUE means duplicate/over-limit and moves, matching the
# Excel =A2=A1 convention.
EQ_TRUE = "TRUE"
EQ_FALSE = "FALSE"

# Skip writing consolidated_output_*.xlsx. The cleansed/final files are
# unaffected. On a large run this alone saves several minutes.
WRITE_INTERMEDIATE = True


# ── Patched shared helpers ──────────────────────────────────────────

def _s(val):
    """str() that maps blanks/NaN/NaT to '' instead of the string 'nan'."""
    if val is None or val is pd.NaT:
        return ""
    try:
        if pd.isna(val):
            return ""
    except (TypeError, ValueError):
        pass
    s = str(val).strip()
    return "" if s in ("nan", "None", "NaT", "<NA>") else s


def _as_text_number(x):
    """Normalise a numeric-looking cell to a plain digit string.

    Never routes through float(), which is 53-bit and silently corrupts any
    value longer than ~15 digits (9000123456789012 -> 9000123456789010).
    """
    if x is None or x is pd.NaT:
        return None
    try:
        if pd.isna(x):
            return None
    except (TypeError, ValueError):
        pass
    s = str(x).strip()
    if s in ("", "nan", "None", "NaT"):
        return None
    if re.fullmatch(r"-?\d+\.0+", s):      # Excel's trailing ".0"
        s = s.split(".")[0]
    return s


_BLANK_TEXT = frozenset(("", "nan", "None", "NaT", "<NA>"))


def _sv(series):
    """_s() over a whole Series (same result, far fewer Python calls)."""
    out = []
    add = out.append
    for v in series.tolist():
        if type(v) is str:
            v = v.strip()
            add("" if v in _BLANK_TEXT else v)
        elif v is None:
            add("")
        else:
            add(_s(v))
    return pd.Series(out, index=series.index, dtype=object)


def _ev(series):
    """_is_empty() over a whole Series."""
    out = []
    add = out.append
    for v in series.tolist():
        if type(v) is str:
            add(v.strip() in ("", "nan", "None"))
        else:
            add(_is_empty(v))
    return pd.Series(out, index=series.index, dtype=bool)


def _mu(series, fn):
    """series.map(fn), calling fn once per distinct value."""
    codes, uniques = pd.factorize(series, use_na_sentinel=True)
    res = [fn(u) for u in uniques] + [fn(None)]
    arr = pd.Series(res, dtype=object).to_numpy()
    return pd.Series(arr[codes], index=series.index, dtype=object)


ROW_ID_COL = "Row ID"
ROW_ID_PREFIX = "R"
ROW_ID_WIDTH = 6


def assign_row_ids(df, force=False):
    """Give every row a stable unique ID.

    Assigned once at merge time, before any rule can split or reorder.
    Text, not numeric, so Excel cannot strip the leading zeros.
    """
    if ROW_ID_COL in df.columns and not force:
        existing = df[ROW_ID_COL].pipe(_sv)
        if existing.ne("").all() and not existing.duplicated().any():
            return df                       # already valid, keep as-is

    width = max(ROW_ID_WIDTH, len(str(len(df))))
    df[ROW_ID_COL] = [f"{ROW_ID_PREFIX}{i:0{width}d}"
                      for i in range(1, len(df) + 1)]

    cols = [c for c in df.columns if c != ROW_ID_COL]
    df = df[[ROW_ID_COL] + cols]
    return df


def _fix_text_columns(df, cols=("RH Reference", "Account No")):
    """Keep long IDs as exact text. Replaces the old float() round-trip."""
    for col in cols:
        if col in df.columns:
            df[col] = df[col].map(_as_text_number)
    return df


def _save_excel(df, path, extra_sheets=None, sheet_name="Sheet1"):
    """Write a large frame. Uses xlsxwriter (faster than openpyxl) but
    WITHOUT constant_memory, which silently drops cells.

    extra_sheets: optional {worksheet_name: DataFrame} written as additional
    tabs in the same workbook. Empty/None frames are skipped.

    datetime_format/date_format pin the DISPLAY format of any real datetime
    columns to DD/MM/YYYY. Without them Excel renders dates using the
    reader's regional settings. No effect on string columns.
    """
    def _apply_formats(xl, frame, sheet):
        """Header styling, frozen panes, autofilter, widths and number
        formats - the same treatment the blanks workbook gets.

        xlsxwriter only; openpyxl falls back to plain output rather than
        failing, so a missing xlsxwriter degrades rather than breaks.
        """
        if xl.engine != "xlsxwriter":
            return
        ws = xl.sheets.get(sheet)
        if ws is None:
            return

        head = xl.book.add_format({
            "bold": True, "bg_color": OUTPUT_HEADER_COLOR,
            "font_color": "white", "border": 1, "text_wrap": True,
            "valign": "vcenter", "align": "left"})

        fmts = {}
        for j, col in enumerate(frame.columns):
            ws.write(0, j, str(col), head)

            spec = NUMBER_FORMATS.get(col)
            if spec:
                if spec not in fmts:
                    fmts[spec] = xl.book.add_format({"num_format": spec})
                ws.set_column(j, j, 15, fmts[spec])
            else:
                # Long key columns need room; everything else is sized
                # from its header with sane bounds.
                width = max(12, min(OUTPUT_MAX_WIDTH, len(str(col)) + 3))
                ws.set_column(j, j, width)

        ws.set_row(0, OUTPUT_HEADER_HEIGHT)
        ws.freeze_panes(1, 0)
        if len(frame):
            ws.autofilter(0, 0, len(frame), max(len(frame.columns) - 1, 0))

    def _write(engine):
        kw = {"engine": engine}
        if engine == "xlsxwriter":
            kw["datetime_format"] = "DD/MM/YYYY"
            kw["date_format"] = "DD/MM/YYYY"
        with pd.ExcelWriter(path, **kw) as xl:
            df.to_excel(xl, index=False, sheet_name=sheet_name)
            _apply_formats(xl, df, sheet_name)
            for name, extra in (extra_sheets or {}).items():
                if extra is None or len(extra) == 0:
                    continue
                # Excel worksheet names: 31 chars max, no : \ / ? * [ ]
                safe = re.sub(r"[:\\/?*\[\]]", "_", str(name))[:31]
                extra.to_excel(xl, index=False, sheet_name=safe)
                _apply_formats(xl, extra, safe)

    try:
        _write("xlsxwriter")
    except Exception as e:
        print(f"    (xlsxwriter unavailable: {e}; falling back to openpyxl)")
        _write("openpyxl")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  SET YOUR FILE PATHS HERE                                       ║
# ╚══════════════════════════════════════════════════════════════════╝

RH_FILE     = "rh.txt"
FM_FILE     = "fm.xlsx"
GRS_FILE    = "grs.xlsx"
RIMPIM_FILE = "rimpim.xlsx"

OUTPUT_MERGED   = "consolidated_output_9sep.xlsx"
OUTPUT_CLEANSED = "cleansed_output_9sep.xlsx"

# Set to None if a source is not available, e.g.: FM_FILE = None


# ════════════════════════════════════════════════════════════════════
#  COLUMN DEFINITIONS
# ════════════════════════════════════════════════════════════════════

CONSOLIDATED_COLUMNS = [
    "Row ID",
    "R.E", "R.E Name", "Country", "URN", "Country of Origin",
    "Claim Country", "Claim / No Claim", "Bene Bank", "Remitter Name",
    "RH Reference", "IBAN No", "Upload Date", "Curr.", "FCY Amount",
    "USD Eqv.", "USD Rate", "Amount", "Beneficiary Name", "Contact No",
    "Account No", "CNIC-A/C", "Cust Type", "Open Date", "Sr", "Mode",
    "Status",
    "Branch Code",
    "Payorder No", "URN.1", "Remitter ID", "Value Date", "Payment Date",
    "User ID", "User Branch", "Purpose of Remittances", "Comments",
    "Remitter ID_2", "Remitter ID_3", "Remitter ID_4",
    "Purpose of Remittance", "CNIC NO.", "LINK TITLE", "LINK IBAN",
    "Channel", "RDA / NON RDA", "RDA Comment", "Account No / CNIC",
    "R.E Name + Open Date + Rem Name + Bene Name",
    "R.E Name + Open Date + Remitter ID + Bene ID",
    "R.E Name + Open Date + Remitter ID + CNIC A/C",
    "R.E Name + Rem Name + Bene Name",
    "R.E Name + Remitter ID + Bene ID",
    "R.E Name + Remitter ID + CNIC A/C",
    "EQ-1", "EQ-2", "EQ-3", "EQ-4", "EQ-5", "EQ-6",
]

RH_HEADERS = [
    "R.E", "Bene Bank", "Remitter Name", "RH Reference", "IBAN No",
    "Upload Date", "Amount", "Beneficiary Name", "Contact No", "Account No",
    "Open Date", "Sr", "Mode", "Status", "Branch Code",
    "Payorder No", "URN", "Remitter ID", "Value Date", "Payment Date",
    "User ID", "User Branch", "Purpose of Remittances", "Comments",
    "Remitter ID_2", "Remitter ID_3", "Remitter ID_4",
    "Purpose of Remittance", "CNIC NO.", "LINK TITLE", "LINK IBAN",
    "Channel",
]

FM_MAPPING = {
    "R.E": "Remitting Entity", "URN": "Reference", "Bene Bank": "_CONST:HBL",
    "Remitter Name": "Naration line 2", "IBAN No": "IBAN #",
    "Upload Date": "Posting Date", "Curr.": "CCY",
    "FCY Amount": "Real Amount", "Amount": "Real Amount",
    "Beneficiary Name": "A/c Short Name", "Account No": "External #",
    "Open Date": "Value Date", "Mode": "Mode", "Branch Code": "Branch Code",
    "Remitter ID": "Naration line 1", "Value Date": "Value Date",
    "Payment Date": "Posting Date", "Purpose of Remittances": "Transaction Description",
}

GRS_MAPPING = {
    "R.E": "SWIFTID", "URN": "UNIQUEREFERENCENO", "Bene Bank": "BANKCODE",
    "Remitter Name": "SENDERNAME", "RH Reference": "RDID", "IBAN No": "TOACCT",
    "Upload Date": "UPLOAD DATE", "Curr.": "_CONST:PKR",
    "FCY Amount": "REMITTANCEAMOUNT", "Amount": "REMITTANCEAMOUNT",
    "Beneficiary Name": "BENEFICIARYNAME", "Contact No": "BENEFICIARYMOBILENO",
    "Account No": "TOACCT", "Open Date": "OPEN DATE", "Mode": "TRANSACTION_TYPE",
    "Status": "STATUS", "Remitter ID": "MEMBERSHIP", "Payment Date": "PAYMENT DATE",
    "Purpose of Remittances": "REMITTANCEPURPOSE",
}

RIMPIM_MAPPING = {
    "R.E": "orderinginstitution 52a", "URN": "external reference",
    "Bene Bank": "_CONST:HBL", "Remitter Name": "ordering customer 1",
    "RH Reference": "payment ref", "IBAN No": "iban",
    "Upload Date": "lodded date", "Curr.": "received curr",
    "FCY Amount": "net received amount", "Amount": "net pay amount",
    "Beneficiary Name": "cust name", "Account No": "external beneficiery account",
    "Open Date": "OPEN DATE-2", "Mode": "_CONST:AC", "Status": "_CONST:PCD",
    "Remitter ID": "ordering customer ac", "Value Date": "value date",
    "Payment Date": "lodded date", "Purpose of Remittances": "detail of payment 4",
    "CNIC NO.": "beneficiary cnic",
}


# ════════════════════════════════════════════════════════════════════
#  PART 1: CONSOLIDATION
# ════════════════════════════════════════════════════════════════════

def _read_rh_one(filepath):
    print(f"  Reading RH: {os.path.basename(filepath)} ...")
    start = time.time()
    df = pd.read_csv(
        filepath, sep="\t", header=None, dtype=str,
        na_values=["", "NA", "N/A"], keep_default_na=False,
        on_bad_lines="skip", quoting=3, encoding="utf-8",
        encoding_errors="replace",
    )
    if df.iloc[:, 0].str.strip().eq("").all() or df.iloc[:, 0].isna().all():
        df = df.iloc[:, 1:].reset_index(drop=True)
    n = min(len(RH_HEADERS), len(df.columns))
    df = df.iloc[:, :n]
    df.columns = RH_HEADERS[:n]
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as fh:
            raw_lines = sum(1 for _ in fh)
        if raw_lines > len(df):
            print(f"    WARNING: {raw_lines - len(df):,} malformed line(s) "
                  f"skipped by on_bad_lines='skip'")
    except Exception:
        pass
    print(f"    -> {len(df):,} rows in {time.time() - start:.1f}s")
    return df


def _source_files(path, exts):
    """A channel source may be one file or a folder of parts."""
    if os.path.isdir(path):
        return [os.path.join(path, f) for f in sorted(os.listdir(path))
                if f.lower().endswith(exts) and not f.startswith(("~$", "."))]
    return [path]


def read_rh(filepath):
    parts = [_read_rh_one(p) for p in _source_files(filepath, (".txt", ".tsv", ".csv"))]
    if len(parts) > 1:
        print(f"    RH: {len(parts)} files combined -> "
              f"{sum(len(p) for p in parts):,} rows")
    return pd.concat(parts, ignore_index=True) if len(parts) != 1 else parts[0]


def _read_excel_one(filepath, source_name):
    """Read one workbook. Every worksheet that carries the same headings
    as the first data sheet is treated as a further part of the same
    extract (Excel's row limit forces large extracts onto 2+ sheets)."""
    fname = os.path.basename(filepath)
    print(f"  Reading {source_name}: {fname} ...")
    start = time.time()
    try:
        book = pd.read_excel(filepath, engine="calamine", dtype=str, sheet_name=None)
    except Exception:
        print(f"    calamine not available, using openpyxl...")
        book = pd.read_excel(filepath, engine="openpyxl", dtype=str, sheet_name=None)

    ref, ref_keys, parts = None, {}, []
    for sheet, sh in book.items():
        if sh is None or not len(sh.columns) or not len(sh):
            continue
        if ref is None:
            ref = sh
            ref_keys = {_norm_header(c): c for c in sh.columns}
            parts.append(sh)
            first = sheet
            continue
        keys = {_norm_header(c) for c in sh.columns}
        overlap = len(keys & set(ref_keys)) / max(1, len(ref_keys))
        if overlap >= 0.6:
            parts.append(sh.rename(columns={c: ref_keys[_norm_header(c)]
                                            for c in sh.columns
                                            if _norm_header(c) in ref_keys}))
            print(f"    + sheet '{sheet}': {len(sh):,} more row(s) "
                  f"(same headings as '{first}')")
        elif overlap == 0 and len(sh.columns) == len(ref.columns):
            # A continuation sheet pasted WITHOUT its heading row: what
            # pandas took for headings is really the first transaction.
            top = [None if str(c).startswith("Unnamed:") else
                   re.sub(r"\.\d+$", "", str(c)) for c in sh.columns]
            body = sh.copy()
            body.columns = ref.columns
            parts.append(pd.concat([pd.DataFrame([top], columns=ref.columns), body],
                                   ignore_index=True))
            print(f"    WARNING: sheet '{sheet}' has no heading row - read as "
                  f"{len(sh) + 1:,} more row(s) in the same column order as "
                  f"'{first}'. Please confirm the row count.")
        else:
            print(f"    note: sheet '{sheet}' skipped - its headings differ "
                  f"from '{first}' ({len(sh):,} row(s) not read)")
    if ref is None:
        df = pd.DataFrame()
    elif len(parts) == 1:
        df = parts[0]
    else:
        df = pd.concat(parts, ignore_index=True, sort=False)
    print(f"    -> {len(df):,} rows, {len(df.columns)} cols"
          f"{'' if len(parts) < 2 else ' from ' + str(len(parts)) + ' sheets'}"
          f" in {time.time() - start:.1f}s")
    return df


def read_excel_fast(filepath, source_name):
    files = _source_files(filepath, (".xlsx", ".xlsm", ".xls"))
    parts = [_read_excel_one(p, source_name) for p in files]
    if len(parts) == 1:
        return parts[0]
    keys = {_norm_header(c): c for c in parts[0].columns}
    parts = [parts[0]] + [p.rename(columns={c: keys[_norm_header(c)] for c in p.columns
                                            if _norm_header(c) in keys})
                          for p in parts[1:]]
    print(f"    {source_name}: {len(parts)} files combined -> "
          f"{sum(len(p) for p in parts):,} rows")
    return pd.concat(parts, ignore_index=True, sort=False)


def _resolve_column(ref, source_df, _cache={}):
    """Find `ref` among the source columns, tolerating case and spacing.

    Exports rename columns between months - GRS shipped "OPEN DATE" and
    then "Open Date". An exact match silently nulled the whole column, so
    matching now ignores case and whitespace. An exact match still wins
    where a source has two similarly named columns.
    """
    if ref in source_df.columns:
        return ref
    key = id(source_df)
    if key not in _cache:
        _cache.clear()          # only ever one source frame in flight
        _cache[key] = {re.sub(r"\s+", "", str(c)).lower(): c
                       for c in source_df.columns}
    return _cache[key].get(re.sub(r"\s+", "", str(ref)).lower())


def apply_mapping(source_df, mapping, channel):
    result = pd.DataFrame(index=source_df.index)
    unresolved = []
    for col in CONSOLIDATED_COLUMNS:
        if col in mapping:
            ref = mapping[col]
            if ref.startswith("_CONST:"):
                result[col] = ref.replace("_CONST:", "")
                continue
            actual = _resolve_column(ref, source_df)
            if actual is None:
                result[col] = None
                unresolved.append((col, ref))
            else:
                result[col] = source_df[actual].values
                if actual != ref:
                    print(f"    note: '{ref}' matched column '{actual}' "
                          f"(spelling differs)")
        else:
            result[col] = None

    # Reported, not silent. A renamed column shows up here instead of as
    # missing data discovered weeks later.
    if unresolved:
        print(f"    WARNING: {len(unresolved)} mapped column(s) not found "
              f"in the {channel} source - left blank:")
        for col, ref in unresolved:
            print(f"      {col:24} expected source column '{ref}'")

    result["Channel"] = channel
    return result


def map_rh(df):
    result = pd.DataFrame(index=df.index)
    for col in CONSOLIDATED_COLUMNS:
        result[col] = df[col].values if col in df.columns else None
    result["Curr."] = "PKR"
    result["FCY Amount"] = result["Amount"]
    result["Channel"] = "RH"
    return result


# ── Match keys ──────────────────────────────────────────────────────
# Separator is " | ": Account No / CNIC already contains " - " inside
# itself, so a dash separator would make the key unsplittable.
KEY_SEPARATOR = " | "

# name -> (components, mode_filter_or_None)
# "Bene ID" is Account No / CNIC (it carries its own A/C - / CNIC - tag).
# KEY_1..KEY_6 are defined in the config block above, beside EQUATIONS.
KEY_DEFINITIONS = {
    KEY_1: (["R.E Name", "Open Date", "Remitter Name",
             "Beneficiary Name"], None),
    KEY_2: (["R.E Name", "Open Date", "Remitter ID",
             "Account No / CNIC"], None),
    KEY_3: (["R.E Name", "Open Date", "Remitter ID", "CNIC-A/C"], "AC"),
    KEY_4: (["R.E Name", "Remitter Name", "Beneficiary Name"], None),
    KEY_5: (["R.E Name", "Remitter ID", "Account No / CNIC"], None),
    KEY_6: (["R.E Name", "Remitter ID", "CNIC-A/C"], "AC"),
}


def build_match_keys(df, quiet=False):
    """Build KEY-1 .. KEY-6.

    A key is blank unless EVERY component has a value - a key with a
    missing part fails to match silently, or matches the wrong row.

    Called during the run AND again after corrections are merged, since
    several components are themselves filled in by hand.
    """
    for name, (parts, mode_only) in KEY_DEFINITIONS.items():
        missing = [c for c in parts if c not in df.columns]
        if missing:
            if not quiet:
                print(f"           {name}: missing {missing} - left blank")
            df[name] = None
            continue

        cols = [df[c].pipe(_sv) for c in parts]

        ok = cols[0].ne("")
        for c in cols[1:]:
            ok = ok & c.ne("")

        if mode_only:
            if "Mode" in df.columns:
                ok = ok & (df["Mode"].pipe(_sv).str.upper().str.strip()
                           .eq(mode_only.upper()))
            else:
                ok = pd.Series(False, index=df.index)

        joined = cols[0]
        for c in cols[1:]:
            joined = joined + KEY_SEPARATOR + c

        out = pd.Series([None] * len(df), index=df.index, dtype=object)
        out[ok] = joined[ok]
        df[name] = out

        if not quiet:
            scope = f"  [Mode {mode_only}]" if mode_only else ""
            # The column names are long now; number them in the log.
            _n = list(KEY_DEFINITIONS).index(name) + 1
            print(f"           KEY-{_n}: {int(ok.sum()):,} built, "
                  f"{int((~ok).sum()):,} blank{scope}   ({name})")
    return df


def generate_derived_columns(df):
    def _blank(idx):
        return pd.Series([None] * len(idx), index=idx, dtype=object)

    acct = df["Account No"]
    acct_s = acct.astype(str).str.strip()

    # Mode == OC  ->  "CNIC - " + CNIC NO.
    # otherwise   ->  "A/C - "  + Account No
    # A blank source value yields a BLANK cell, never a dangling prefix.
    acct_ok = acct.notna() & acct_s.ne("") & acct_s.ne("nan")

    if "Mode" in df.columns:
        is_oc = (df["Mode"].astype(str).str.strip().str.upper()
                 .eq(ACCOUNT_CNIC_MODE.upper()))
    else:
        is_oc = pd.Series(False, index=df.index)

    if CNIC_COL in df.columns:
        cnic_s = df[CNIC_COL].astype(str).str.strip()
        cnic_ok = df[CNIC_COL].notna() & cnic_s.ne("") & cnic_s.ne("nan")
    else:
        cnic_s = pd.Series("", index=df.index)
        cnic_ok = pd.Series(False, index=df.index)

    out = _blank(df.index)

    use_cnic = is_oc & cnic_ok
    out[use_cnic] = ACCOUNT_CNIC_PREFIX + cnic_s[use_cnic]

    if ACCOUNT_CNIC_FALLBACK:
        use_acct = (~use_cnic) & acct_ok
    else:
        use_acct = (~is_oc) & acct_ok
    out[use_acct] = ACCOUNT_ACCT_PREFIX + acct_s[use_acct]

    df[ACCOUNT_CNIC_COL] = out

    # "Rem Name + Bene Name" and "Remitter ID + Bene ID" are replaced by
    # KEY-1 / KEY-4 and KEY-2 / KEY-5, which use Account No / CNIC as the
    # Bene ID rather than hardcoding the A/C form.
    for _old in ("Rem Name + Bene Name", "Remitter ID + Bene ID",
                 "EQ-1", "EQ-2"):
        if _old in df.columns:
            df.drop(columns=[_old], inplace=True)

    return df


def consolidate(rh_path=None, fm_path=None, grs_path=None, rimpim_path=None, output_path=None):
    total_start = time.time()
    frames = []

    print("\n" + "=" * 60)
    print("  HBL PRI - Step 1: Data Consolidation")
    print("=" * 60 + "\n")

    if rh_path and os.path.exists(rh_path):
        frames.append(map_rh(read_rh(rh_path)))
        print(f"    RH mapped: {len(frames[-1]):,} rows\n")
    if fm_path and os.path.exists(fm_path):
        frames.append(apply_mapping(read_excel_fast(fm_path, "FM"), FM_MAPPING, "FM"))
        print(f"    FM mapped: {len(frames[-1]):,} rows\n")
    if grs_path and os.path.exists(grs_path):
        frames.append(apply_mapping(read_excel_fast(grs_path, "GRS"), GRS_MAPPING, "GRS"))
        print(f"    GRS mapped: {len(frames[-1]):,} rows\n")
    if rimpim_path and os.path.exists(rimpim_path):
        frames.append(apply_mapping(read_excel_fast(rimpim_path, "RIMPIM"), RIMPIM_MAPPING, "RIM PIM"))
        print(f"    RIMPIM mapped: {len(frames[-1]):,} rows\n")

    if not frames:
        raise ValueError("No channel source files were provided.")

    print("  Merging...")
    df = pd.concat(frames, ignore_index=True).reindex(columns=CONSOLIDATED_COLUMNS)

    # Before ANY rule can split or reorder rows.
    df = assign_row_ids(df, force=True)
    print(f"  Assigned {ROW_ID_COL}: {df[ROW_ID_COL].iloc[0]} .. "
          f"{df[ROW_ID_COL].iloc[-1]}")

    print("  Structural derivations...")

    # Account No: strip PK IBAN prefix
    acct = df["Account No"].astype(str).str.strip()
    pk = acct.str.startswith("PK") & (acct.str.len() > 10)
    df.loc[pk, "Account No"] = acct[pk].str[10:]

    # RH: Account No from IBAN No
    rh = df["Channel"] == "RH"
    if rh.any():
        iban = df.loc[rh, "IBAN No"].astype(str).str.strip()
        pk2 = iban.str.startswith("PK") & (iban.str.len() > 10)
        df.loc[rh & pk2.reindex(df.index, fill_value=False), "Account No"] = iban[pk2].str[10:]

    # GRS & RIMPIM: Branch Code = Account No[:4]
    for ch in ["GRS", "RIM PIM"]:
        m = df["Channel"] == ch
        if m.any():
            av = df.loc[m, "Account No"].astype(str).str.strip()
            v = av.str.len() >= 4
            df.loc[m & v.reindex(df.index, fill_value=False), "Branch Code"] = av[v].str[:4]

    # RH: Remitter ID fallback
    rh = df["Channel"] == "RH"
    if rh.any():
        rid = df.loc[rh, "Remitter ID"].astype(str).str.strip()
        empty = rh & (rid.isin(["", "nan", "None"]) | df["Remitter ID"].isna())
        for fb in ["Remitter ID_2", "Remitter ID_3"]:
            if fb in df.columns and empty.any():
                vals = df.loc[empty, fb].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
                ok = ~vals.isin(["", "nan", "None"]) & vals.notna()
                df.loc[empty & ok.reindex(df.index, fill_value=False), "Remitter ID"] = vals[ok]
                empty = empty & ~ok.reindex(df.index, fill_value=False)
# RH: if Mode is "IB", Payment Date = Upload Date
    rh_ib = (df["Channel"] == "RH") & (df["Mode"].astype(str).str.strip() == "IB")
    if rh_ib.any():
        df.loc[rh_ib, "Payment Date"] = df.loc[rh_ib, "Upload Date"]
    df["URN.1"] = df["URN"]
    df = generate_derived_columns(df)

    elapsed = time.time() - total_start
    print(f"\n  MERGE COMPLETE - {len(df):,} rows in {elapsed:.1f}s")
    for ch, c in df["Channel"].value_counts().items():
        print(f"    {ch:10s} -> {c:,}")

# Prevent scientific notation for long numeric columns
    df = _fix_text_columns(df)

    if output_path and WRITE_INTERMEDIATE:
        print(f"\n  Saving: {output_path} ...")
        _save_excel(df, output_path)
        print(f"  Saved.")
    elif output_path:
        print(f"\n  Skipping intermediate save (WRITE_INTERMEDIATE = False).")

    return df


# ════════════════════════════════════════════════════════════════════
#  PART 2: CLEANSING
# ════════════════════════════════════════════════════════════════════

BANK_NAMES = {
    "SCB", "HBL", "UBL", "MCB", "ABL", "NBP", "BAFL", "JSBL", "BAHL",
    "MEBL", "SNBL", "SILK", "FAYSAL", "MEEZAN", "ASKARI", "SONERI",
    "HABIB", "ALLIED", "SUMMIT", "SAMBA", "ALFALAH", "FINCA", "NRSP",
    "JAZZCASH", "EASYPAISA", "SADAPAY", "NAYAPAY", "MOBILINK",
    "BANKISLAMI", "STANDARD", "CHARTERED", "DUBAI", "ISLAMIC",
    "RAKBANK", "MASHREQ", "EMIRATES", "ENBD", "FAB", "ADCB",
    "ALRAJHI", "ALJAZIRA", "ALINMA", "RIYAD", "SABB", "SNB",
}

RELATIONSHIP_TAGS = [
    r"\bS\s*/?\s*O\b", r"\bD\s*/?\s*O\b", r"\bW\s*/?\s*O\b", r"\bC\s*/?\s*O\b",
    r"\bBY\s+BY\b", r"\bBNT\b", r"\bBIN\b", r"\bIBN\b", r"\bUMM\b",
    r"\bABU\b", r"\bAMMI\b", r"\bABBU\b", r"\bBHAI\b", r"\bBABA\b", r"\bAPPA\b",
    r"\bSON\s+OF\b", r"\bDAUGHTER\s+OF\b", r"\bWIFE\s+OF\b",
    r"\bMR\.?\b", r"\bMRS\.?\b", r"\bMS\.?\b", r"\bDR\.?\b", r"\bPH\b",
]


def _is_empty(val):
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return True
    return str(val).strip() in ("", "nan", "None")


_NAME_CACHE = {}


def _process_map(fn, items, workers):
    """map() over worker processes. Raises (instead of hanging) if a
    worker cannot start or dies, so callers can fall back to serial."""
    import concurrent.futures as cf
    import multiprocessing as mp
    with cf.ProcessPoolExecutor(max_workers=workers,
                                mp_context=mp.get_context("spawn")) as ex:
        return list(ex.map(fn, items))


NAME_WORKERS = 1            # set by the web app from config (CPU count)
NAME_PARALLEL_MIN = 20000   # distinct names below this are cleaned in-process


def _clean_name_chunk(values):
    return [_clean_single_name(v) for v in values]


def _clean_names_series(series):
    """Apply _clean_single_name over a Series, cleaning each distinct
    value only once. Large sets are spread over worker processes; the
    result is identical either way."""
    vals = series.astype(object)
    todo = [v for v in pd.unique(vals.dropna()) if v not in _NAME_CACHE]
    done = False
    if NAME_WORKERS > 1 and len(todo) >= NAME_PARALLEL_MIN:
        try:
            size = max(2000, len(todo) // (NAME_WORKERS * 4) + 1)
            chunks = [todo[i:i + size] for i in range(0, len(todo), size)]
            for chunk, res in zip(chunks, _process_map(_clean_name_chunk, chunks,
                                                       NAME_WORKERS)):
                _NAME_CACHE.update(zip(chunk, res))
            done = True
            print(f"           {len(todo):,} distinct name(s) cleaned on "
                  f"{NAME_WORKERS} worker(s)")
        except Exception as e:      # never let parallelism break a run
            print(f"           (parallel name cleaning unavailable: {e}; "
                  f"continuing in-process)")
    if not done:
        for v in todo:
            if v not in _NAME_CACHE:
                _NAME_CACHE[v] = _clean_single_name(v)
    return vals.map(lambda v: _NAME_CACHE.get(v) if v is not None else v)


def _clean_single_name(name):
    if not name or not isinstance(name, str) or str(name).strip() in ("nan", "None", ""):
        return name

    original = str(name).strip()
    name = original.upper()

    # ── Leading junk ────────────────────────────────────────────
    name = re.sub(r"^\d+\s*/\s*", "", name)       # "1/MOHSAN" → "MOHSAN"
    name = re.sub(r"^\d+\s+", "", name)            # "1 MUHAMMAD" → "MUHAMMAD"
    name = re.sub(r"^\d+(?=[A-Z])", "", name)      # "1MUHAMMAD" → "MUHAMMAD"
    name = re.sub(r"^/\s*", "", name)              # "/AMJAD KHAN" → "AMJAD KHAN"
    name = re.sub(r"^\.\s*", "", name)             # ". ANWAR ALI" → "ANWAR ALI"

    # ── Trailing junk ───────────────────────────────────────────
    name = re.sub(r"\s*,\s*$", "", name)           # trailing comma
    name = re.sub(r"\s*_+\s*$", "", name)          # trailing underscore
    name = re.sub(r"\+\d*\s*\w*\s*$", "", name)          # trailing plus
    name = re.sub(r"\s*\.\s*$", "", name)          # trailing dot

    # ── Parenthetical suffixes ──────────────────────────────────
    name = re.sub(r"\(.*?\)", "", name)            # "(ASAAN AC)"
    name = re.sub(r"\(.*$", "", name)              # unclosed "(ASAAN"

    # ── Account / bank labels ───────────────────────────────────
    name = re.sub(r"\bASAAN\s*(?:ACCOUNT|AC)?\b", "", name)
    name = re.sub(r"\bPHOT(?:O)?\s*(?:ACCOUNT|AC)?\b", "", name)
    name = re.sub(r"\bAC\s*NO\.?\s*\d*", "", name)
    name = re.sub(r"\bACCOUNT\s*NO\.?\s*\d*", "", name)
    name = re.sub(r"\bCENTRAL\s+BANK\b.*$", "", name)
    # ── Junk words / labels ─────────────────────────────────────
    name = re.sub(r"\bTUTOR\b", "", name)
    name = re.sub(r"\bLAST\s*TERM\b", "", name)

    # ── Placeholder text ────────────────────────────────────────
    name = re.sub(r"\bNOT\s+AVAILABLE\b", "", name)
    name = re.sub(r"\bNOT\s+APPLICABLE\b", "", name)
    name = re.sub(r"\bN/A\b", "", name)

    # # ── NO LAST NAME (all misspellings/variants)
    # name = re.sub(r"\bNO\s*LAST\s*NAME\b", "", name)
    # name = re.sub(r"\bNO\s*LASTE?\s*N?AME?\b", "", name)
    # name = re.sub(r"\bNOL\s*LAST\s*NAME\b", "", name)
    # name = re.sub(r"\bNO\s*LAST\b", "", name)
    # name = re.sub(r"\bNOLAST\b", "", name)
    # name = re.sub(r"\bN\s+LAST\s+NAME\b", "", name)

# ── All "NO NAME" / "NO LAST NAME" variants & misspellings ──
    #    Covers: NO LAST NAME, NO LASTNME, NO LSAT NAME, NO ALST NAME,
    #    NO LASNT NAME, NO LAT NAME, NO LATE NAME, NO LATS NAME,
    #    NO LEST NAME, NOT LST NAME, NO LST NAME, NOALSTNAME, etc.
    name = re.sub(
        r"\bNO[LT]?\s*(?:LAST|LSAT|LASNT|ALST|LST|LAT|LATE|LATS|LEST|LASTE?)\s*(?:NAME|NME|NEME)?\b",
        "", name, flags=re.IGNORECASE
    )
    name = re.sub(r"\bNOT\s+LST\s+NAME\b", "", name, flags=re.IGNORECASE)

    # NO NAME / NONAME / NI NAME
    name = re.sub(r"\bNO\s*NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNI\s+NAME\b", "", name, flags=re.IGNORECASE)

    # NO MIDDLE NAME / NOMIDDLENAME / NO MIDLE NAME
    name = re.sub(r"\bNO\s*(?:MIDDLE|MIDLE|MID)\s*NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNOMIDDLENAME\b", "", name, flags=re.IGNORECASE)

    # NO SURNAME / NO SECOND NAME / WITHOUT SURENAME / SONAME
    name = re.sub(r"\bNO\s*SURNAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s+SURNAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s+SECOND\s+NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bWITHOUT\s+SURENAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bSONAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bFIRST\s+NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s*(?:SURENAME|SARNAME|SURNAM|SURNME)\b", "", name, flags=re.IGNORECASE)
    # ── Relationship terms with JAN ─────────────────────────────
    name = re.sub(r"\bAME\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bAMMI\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bABU\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bBHAI\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bBABA\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bAPPA\s*JAN\b", "", name, flags=re.IGNORECASE)

    # SINGLENAME / SINGLE NAME / SINGLENAMECUSTOMER
    name = re.sub(r"\bSINGLE\s*NAME\s*(?:CUSTOMER)?\b", "", name, flags=re.IGNORECASE)

    # ACCOUNTNAME
    name = re.sub(r"\bACCOUNT\s*NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"ACCOUNTNAME", " ", name, flags=re.IGNORECASE)  # concatenated: ACCOUNTNAMEAMNABIBI

    # FATHER NAME / HUSBAND NAME / HUSBAMD NAME + everything after
    name = re.sub(r"\b(?:FATHER|HUSBAND|HUSBAMD)\s+NAME\b.*$", "", name, flags=re.IGNORECASE)

    # CUSTOMER (standalone junk)
    name = re.sub(r"\bCUSTOMER\b", "", name, flags=re.IGNORECASE)

    # MYSELF / RECEIVE (standalone junk)
    name = re.sub(r"\bMYSELF\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bRECEIVE\b", "", name, flags=re.IGNORECASE)

    # Standalone NAME (but NOT NAMEER, NAMEERA, etc.)
    name = re.sub(r"\bNAME\b(?!ER|ERA)", "", name, flags=re.IGNORECASE)

    # ── Embedded document references ────────────────────────────
    name = re.sub(r"\bDOB\b[\w\s.]*$", "", name)
    name = re.sub(r"\bCNIC\b[\w\s]*$", "", name)
    name = re.sub(r"\bNICOP\b[\w\s]*$", "", name)
    name = re.sub(r"\bPASSPORT\b[\w\s]*$", "", name)
    name = re.sub(r"\bNATION\.\w+", "", name)

    # ── Phone numbers ───────────────────────────────────────────
    name = re.sub(r"\b\d[\d\s-]{6,}\d\b", "", name)
    name = re.sub(r"\bPH\s*\d+", "", name)





# # ── Bank names (standalone, concatenated, misspelled) ───────
#     # Remove known bank names with optional concatenation
#     bank_names_pattern = (
#         r"MEEZAN|MEZAN|MEZN|MEZANBANK|MEEZANBANK"
#         r"|ALLIED|ALLID|ALID|ALIED|ALLIEDBANK|ALLIDBANK|ALIEDB"
#         r"|ASKARI|ASKRI|ASKRIBANK"
#         r"|FAYSAL|FASYAL|FAS\s*YAL"
#         r"|HABIB\s*BANK|HABIBBANK|BANK\s*AL\s*HABIB|BANKALHABIB|AL\s*HABIB"
#         r"|AL\s*BARAKA|ALBARKA"
#         r"|JS\s*BANK|JSBANK"
#         r"|MCB\s*BANK|MCBBANK"
#         r"|UBL\s*BANK|UBLBANK"
#         r"|NBP|NATIONAL\s*BANK"
#         r"|MUSLIM\s*COMMERCIAL\s*BANK|COMARCIALBANK|COMMERCIALBANK"
#         r"|UNITED\s*BANK|UNTIDBANK|UNITEDBANK"
#         r"|SUMMIT\s*BANK|SONERI\s*BANK|SILK\s*BANK"
#         r"|BANK\s*ISLAMI|BANKISLAMI|ISLAMC\s*BANKING"
#         r"|BANK\s*AL\s*FALAH|BANKALFALAH|AL\s*FALAH"
#         r"|APNA\s*BANK|BURBANK"
#         r"|SCB|HBL|MCB|ABL|BAFL|JSBL|BAHL|MEBL|SNBL"
#         r"|JAZZCASH|EASYPAISA|SADAPAY|NAYAPAY|MOBILINK"
#         r"|\bRAKBANK\b|\bMASHREQ\b|\bEMIRATES\b|\bENBD\b|\bFAB\b|\bADCB\b"
#         r"|\bALRAJHI\b|\bALJAZIRA\b|\bALINMA\b|\bRIYAD\b|\bSABB\b|\bSNB\b"
#         r"|MZN\s*BANK|MBANK"
#     )
#     # Remove bank names (even when concatenated with other text)
#     name = re.sub(bank_names_pattern, " ", name, flags=re.IGNORECASE)

#     # Remove standalone BANK and related words
#     name = re.sub(r"\bBANK(?:ING|LIMITED|LTD|S)?\b", "", name, flags=re.IGNORECASE)
#     name = re.sub(r"\bNET\s*BANKING\b", "", name, flags=re.IGNORECASE)
#     name = re.sub(r"\bHEAD\s*OFFICE\b", "", name, flags=re.IGNORECASE)
#     name = re.sub(r"\bLIMITED\b", "", name, flags=re.IGNORECASE)
#     name = re.sub(r"\bLTD\b", "", name, flags=re.IGNORECASE)
#     name = re.sub(r"\bRDA\b", "", name, flags=re.IGNORECASE)

#     # Remove branch/location info that follows bank names
#     name = re.sub(r"\bBRANCH\b.*$", "", name, flags=re.IGNORECASE)

# ── Bank name removal (handles start, middle, end, concatenated) ──
    #    Strategy: protect real names → replace BANK/BNAK with space → cleanup
    
    # Protect real names containing BANK substring
    _protect = {"MEHRBANKHAN": "__PROTECT1__", "BANKAR": "__PROTECT2__", "NUBLA": "__PROTECT3__"}
    for real, placeholder in _protect.items():
        name = name.replace(real, placeholder)

    # Remove known full bank names first (MEEZAN, ALLIED, etc.)
    bank_names_pattern = (
        r"MEEZAN|MEZAN|MEZN"
        r"|\bALLIED\b|\bALLID\b|\bALID\b|\bALIED\b"
        r"|ASKARI|ASKRI"
        r"|FAYSAL|FASYAL|FAS\s*YAL"
        r"|AL\s*HABIB|AL\s*HABIT|ALHABIT"
        r"|AL\s*BARAKA|ALBARKA"
        r"|JS\s*BANK|JSBANK"
        r"|MUSLIM\s*COMMERCIAL|COMARCIAL|COMMERCIAL"
        r"|\bUNITED\b|\bUNTID\b"
        r"|\bSUMMIT\b|\bSONERI\b|\bSILK\b"
        r"|AL\s*FALAH|ALFALAH"
        r"|\bAPNA\b|\bBURBANK\b"
        r"|\bSCB\b|\bHBL\b|\bMCB\b|\bABL\b|\bNBP\b|\bBAFL\b|\bJSBL\b|\bBAHL\b|\bMEBL\b|\bSNBL\b"
        r"|JAZZCASH|EASYPAISA|SADAPAY|NAYAPAY|MOBILINK"
        r"|\bRAKBANK\b|\bMASHREQ\b|\bEMIRATES\b|\bENBD\b|\bFAB\b|\bADCB\b"
        r"|\bALRAJHI\b|\bALJAZIRA\b|\bALINMA\b|\bRIYAD\b|\bSABB\b|\bSNB\b"
        r"|\bMZN\b|\bNATIONAL\b"
    )
    name = re.sub(bank_names_pattern, " ", name, flags=re.IGNORECASE)

    # Replace BANK/BNAK (and suffixes) with space — keeps surrounding text
    name = re.sub(r"BANK(?:ING|LIMITED|LIMTED|LTD|L)?", " ", name, flags=re.IGNORECASE)
    name = re.sub(r"BNAK", " ", name, flags=re.IGNORECASE)

    # Cleanup junk words left after bank removal
    name = re.sub(r"\bHEAD\s*OFFICE\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLIMITED\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLIMTED\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLTD\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNET\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bRDA\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bBRANCH\b.*$", "", name, flags=re.IGNORECASE)

    # Restore protected names
    for real, placeholder in _protect.items():
        name = name.replace(placeholder, real)

    # ── Relationship / honorific tags ───────────────────────────
    name = re.sub(r"\bS[\-/\.]?\s*O\b", "", name)         # S/O, S-O, S.O
    name = re.sub(r"\bD[\-/\.]?\s*O\b", "", name)         # D/O
    name = re.sub(r"\bW[\-/\.]?\s*O\b", "", name)         # W/O
    name = re.sub(r"\bC[\-/\.]?\s*O\b", "", name)         # C/O
    name = re.sub(r"\bA/O\b", "", name)                    # A/O
    name = re.sub(r"\bU/O\b", "", name)                    # U/O
    name = re.sub(r"\bT/A\b", "", name)                    # T/A (trading as)
    name = re.sub(r"\bM\.D\.?\b", "", name)                # M.D.
    name = re.sub(r"\bP\.A\.?\b", "", name)                # P.A.
    name = re.sub(r"\bET/OU\b", "", name)                  # ET/OU
    name = re.sub(r"\bBY\s+BY\b", "", name)
    name = re.sub(r"\bBNT\b", "", name)
    name = re.sub(r"\bBIN\b", "", name)
    name = re.sub(r"\bIBN\b", "", name)
    name = re.sub(r"\bUMM\b", "", name)
    name = re.sub(r"\bABU\b(?!\s+(?!(?:JI|G|JAN)\b)[A-Z])", "", name)
    name = re.sub(r"\bAMMI\b", "", name)
    name = re.sub(r"\bABBU\b", "", name)
    name = re.sub(r"\bBHAI\b", "", name)
    name = re.sub(r"\bBABA\b", "", name)
    name = re.sub(r"\bAPPA\b", "", name)
    name = re.sub(r"\bFARZAND\b", "", name)
    name = re.sub(r"\bSONOF\b", "", name)
    name = re.sub(r"\bDAUGHTEROF\b", "", name)
    name = re.sub(r"\bWIFEOF\b", "", name)
    name = re.sub(r"\bSON\s+OF\b", "", name)
    name = re.sub(r"\bDAUGHTER\s+OF\b", "", name)
    name = re.sub(r"\bWIFE\s+OF\b", "", name)
    name = re.sub(r"\bMR\.?\s", " ", name)
    name = re.sub(r"\bMRS\.?\s", " ", name)
    name = re.sub(r"\bMS\.?\s", " ", name)
    name = re.sub(r"\bDR\.?\s", " ", name)

# ── Trailing AA / NA junk ───────────────────────────────────
    name = re.sub(r"\s+AA$", "", name)                     # "ABDUL AA" → "ABDUL"
    name = re.sub(r"(?<=\s)NA$", "", name)                 # "AAMIR NA" → "AAMIR"

    # ── Branch / location / org labels ──────────────────────────
    name = re.sub(r"\bBRANCH\b.*$", "", name)              # "BOHAR BAZAR BRANCH" → "BOHAR BAZAR" (and everything after)
    name = re.sub(r"\bREMITTANCE\s*(?:ACCOUNT)?\b", "", name)
    name = re.sub(r"\bPUBLIC\s*SCHOOL\b", "", name)

    # ── SP NAMET → S/O typo fix (then S/O regex above handles it)
    name = re.sub(r"\bSP\s+NAMET\b", "", name)

    # ── Trailing digit junk on words ────────────────────────────
    name = re.sub(r"(\b[A-Z]+)\d{3,}\b", r"\1", name)    # "MAHA1992" → "MAHA"

    # ── Standalone digit sequences (4+) ─────────────────────────
    name = re.sub(r"\b\d{4,}\b", "", name)

    # ── Ampersand ───────────────────────────────────────────────
    name = name.replace("&", " AND ")

# ── Deduplicate repeated names in same cell ─────────────────
    #    "SALMANASHRAF SALMANASHRAF" → "SALMANASHRAF"
    #    "MUHAMMAD REHAN MUHAMMAD REHAN" → "MUHAMMAD REHAN"
    words = name.split()
    if len(words) >= 2:
        # Try splitting in half
        mid = len(words) // 2
        if words[:mid] == words[mid:mid*2]:
            name = " ".join(words[:mid])
        # Also try: full string repeated (concatenated like RAFIULLAHKHANRAFIULLAHKHAN)
        else:
            # Only fold an EXACT even-length repeat. The old version
            # used name[half:half*2].lstrip() on odd-length strings,
            # which split inside a word - the cause of FAISAL -> FAIS.
            half = len(name) // 2
            if (half > 2 and len(name) % 2 == 0
                    and name[:half] == name[half:]):
                name = name[:half].strip()

    # ── Collapse spaces and strip ───────────────────────────────
    name = re.sub(r"\s+", " ", name).strip()

    # ── Leading junk ────────────────────────────────────────────
    name = re.sub(r"^\d+\s*/\s*", "", name)
    name = re.sub(r"^\d+\s+", "", name)
    name = re.sub(r"^\d+(?=[A-Z])", "", name)
    name = re.sub(r"^/\s*", "", name)
    name = re.sub(r"^\.\s*", "", name)

    # ── Trailing junk ───────────────────────────────────────────
    name = re.sub(r"\s*,\s*$", "", name)
    name = re.sub(r"\s*_+\s*$", "", name)
    name = re.sub(r"\+\d*\s*\w*\s*$", "", name)
    name = re.sub(r"\s*\.\s*$", "", name)

    # ── Excel errors ────────────────────────────────────────────
    name = re.sub(r"#NAME\?", "", name)

    # ── Parenthetical suffixes ──────────────────────────────────
    name = re.sub(r"\(.*?\)", "", name)
    name = re.sub(r"\(.*$", "", name)

    # ── Account / bank labels ───────────────────────────────────
    name = re.sub(r"\bASAAN\s*(?:ACCOUNT|AC)?\b", "", name)
    name = re.sub(r"\bPHOT(?:O)?\s*(?:ACCOUNT|AC)?\b", "", name)
    name = re.sub(r"\bAC\s*NO\.?\s*\d*", "", name)
    name = re.sub(r"\bACCOUNT\s*NO\.?\s*\d*", "", name)
    name = re.sub(r"\bCENTRAL\s+BANK\b.*$", "", name)
    name = re.sub(r"\bACCOUNT\s*NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"ACCOUNTNAME", " ", name, flags=re.IGNORECASE)
    name = re.sub(r"\bACCOUNT\b", "", name, flags=re.IGNORECASE)

    # ── Placeholder text ────────────────────────────────────────
    name = re.sub(r"\bNOT\s+AVAILABLE\b", "", name)
    name = re.sub(r"\bNOT\s+APPLICABLE\b", "", name)
    name = re.sub(r"\bN/A\b", "", name)

    # ── All NO NAME / NO LAST NAME variants ─────────────────────
    name = re.sub(
        r"\bNO[LT]?\s*(?:LAST|LSAT|LASNT|ALST|LST|LAT|LATE|LATS|LEST|LASTE?)\s*(?:NAME|NME|NEME)?\b",
        "", name, flags=re.IGNORECASE
    )
    name = re.sub(r"\bNOT\s+LST\s+NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s*NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNI\s+NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s*(?:MIDDLE|MIDLE|MID)\s*NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNOMIDDLENAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s*(?:SURNAME|SURENAME|SARNAME|SURNAM|SURNME)\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNO\s+SECOND\s+NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bWITHOUT\s+SURENAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bSONAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bFIRST\s+NAME\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bSINGLE\s*NAME\s*(?:CUSTOMER)?\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\b(?:FATHER|HUSBAND|HUSBAMD)\s+NAME\b.*$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bCUSTOMER\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bMYSELF\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bRECEIVE\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNAME\b(?!ER|ERA)", "", name, flags=re.IGNORECASE)

    # ── Embedded document references ────────────────────────────
    name = re.sub(r"\bDOB\w*", "", name)
    name = re.sub(r"\bCNIC\b[\w\s]*$", "", name)
    name = re.sub(r"\bNICOP\b[\w\s]*$", "", name)
    name = re.sub(r"\bPASSPORT\b[\w\s]*$", "", name)
    name = re.sub(r"\bNATION\.\w+", "", name)

    # ── Phone numbers ───────────────────────────────────────────
    name = re.sub(r"\b\d[\d\s-]{6,}\d\b", "", name)
    name = re.sub(r"\bPH\s*\d+", "", name)

    # ── Bank name removal ───────────────────────────────────────
    _protect = {"MEHRBANKHAN": "__MEHRBAN_KHAN__", "BANKAR": "__BANKAR__"}
    for real, placeholder in _protect.items():
        name = name.replace(real, placeholder)

    bank_names_pattern = (
        r"MEEZAN|MEZAN|MEZN"
        r"|\bALLIED\b|\bALLID\b|\bALID\b|\bALIED\b"
        r"|ASKARI|ASKRI"
        r"|FAYSAL|FASYAL|FAS\s*YAL"
        r"|AL\s*HABIB|AL\s*HABIT|ALHABIT"
        r"|AL\s*BARAKA|ALBARKA"
        r"|JS\s*BANK|JSBANK"
        r"|MUSLIM\s*COMMERCIAL|COMARCIAL|COMMERCIAL"
        r"|\bUNITED\b|\bUNTID\b"
        r"|\bSUMMIT\b|\bSONERI\b|\bSILK\b"
        r"|AL\s*FALAH|ALFALAH"
        r"|\bAPNA\b|\bBURBANK\b"
        r"|\bSCB\b|\bHBL\b|\bUBL\b|\bMCB\b|\bABL\b|\bNBP\b|\bBAFL\b|\bJSBL\b|\bBAHL\b|\bMEBL\b|\bSNBL\b"
        r"|JAZZCASH|EASYPAISA|SADAPAY|NAYAPAY|MOBILINK"
        r"|\bRAKBANK\b|\bMASHREQ\b|\bEMIRATES\b|\bENBD\b|\bFAB\b|\bADCB\b"
        r"|\bALRAJHI\b|\bALJAZIRA\b|\bALINMA\b|\bRIYAD\b|\bSABB\b|\bSNB\b"
        r"|\bMZN\b|\bNATIONAL\b"
    )
    name = re.sub(bank_names_pattern, " ", name, flags=re.IGNORECASE)
    name = re.sub(r"BANK(?:ING|LIMITED|LIMTED|LTD|L)?", " ", name, flags=re.IGNORECASE)
    name = re.sub(r"BNAK", " ", name, flags=re.IGNORECASE)
    name = re.sub(r"\bHEAD\s*OFFICE\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLIMITED\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLIMTED\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bLTD\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bNET\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bRDA\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bBRANCH\b.*$", "", name, flags=re.IGNORECASE)

    for real, placeholder in _protect.items():
        name = name.replace(placeholder, real)

    # ── Relationship / honorific tags ───────────────────────────
    name = re.sub(r"\bS[\-/\.]?\s*O\b", "", name)
    name = re.sub(r"\bD[\-/\.]?\s*O\b", "", name)
    name = re.sub(r"\bW[\-/\.]?\s*O\b", "", name)
    name = re.sub(r"\bC[\-/\.]?\s*O\b", "", name)
    name = re.sub(r"\bA/O\b", "", name)
    name = re.sub(r"\bU/O\b", "", name)
    name = re.sub(r"\bT/A\b", "", name)
    name = re.sub(r"\bM\.D\.?\b", "", name)
    name = re.sub(r"\bP\.A\.?\b", "", name)
    name = re.sub(r"\bET/OU\b", "", name)
    name = re.sub(r"\bBY\s+BY\b", "", name)
    name = re.sub(r"\bBNT\b", "", name)
    name = re.sub(r"\bBIN\b", "", name)
    name = re.sub(r"\bIBN\b", "", name)
    name = re.sub(r"\bUMM\b", "", name)
    name = re.sub(r"\bABU\b(?!\s+(?!(?:JI|G|JAN)\b)[A-Z])", "", name)
    name = re.sub(r"\bAMMI\b", "", name)
    name = re.sub(r"\bABBU\b", "", name)
    name = re.sub(r"\bBHAI\b", "", name)
    name = re.sub(r"\bBHAI\b", "", name)
    name = re.sub(r"^BHAI(?=[A-Z]{4,})", "", name)     # BHAIFARAZ → FARAZ
    name = re.sub(r"\bBABA\b", "", name)
    name = re.sub(r"\bAPPA\b", "", name)
    name = re.sub(r"\bFARZAND\b", "", name)
    name = re.sub(r"\bSONOF\b", "", name)
    name = re.sub(r"\bDAUGHTEROF\b", "", name)
    name = re.sub(r"\bWIFEOF\b", "", name)
    name = re.sub(r"\bSON\s+OF\b", "", name)
    name = re.sub(r"\bDAUGHTER\s+OF\b", "", name)
    name = re.sub(r"\bWIFE\s+OF\b", "", name)
    name = re.sub(r"\bMR\.?\s", " ", name)
    name = re.sub(r"\bMRS\.?\s", " ", name)
    name = re.sub(r"\bMS\.?\s", " ", name)
    name = re.sub(r"\bDR\.?\s", " ", name)
    name = re.sub(r"\bSP\s+NAMET\b", "", name)

    # ── Relationship terms with JAN ─────────────────────────────
    name = re.sub(r"AME\s*JAN\b", " ", name, flags=re.IGNORECASE)
    name = re.sub(r"\bAMMI\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bABU\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bBHAI\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bBABA\s*JAN\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bAPPA\s*JAN\b", "", name, flags=re.IGNORECASE)
    # ── Concatenated relationship prefixes ──────────────────────
    # 4+ letters must follow: BHAIFARAZ -> FARAZ still works, but BABAR
    # no longer loses BABA and collapses to "R" (1,823 rows).
    name = re.sub(r"^(?:BHAI|AMMI|ABBU|BABA)(?=[A-Z]{4,})", "", name, flags=re.IGNORECASE)

    # ── Trailing AA / NAA junk ──────────────────────────────────
    name = re.sub(r"\s+AA$", "", name)
    name = re.sub(r"(?<=\s)NA$", "", name)
    name = re.sub(r"\s+NAA$", "", name)

    # ── Standalone junk words ───────────────────────────────────
    name = re.sub(r"\bTUTOR\b", "", name)
    name = re.sub(r"\bLAST\s*TERM\b", "", name)
    name = re.sub(r"\bSAVING[S]?\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bGATHER\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bPUBLIC\s*SCHOOL\b", "", name)
    name = re.sub(r"\bREMITTANCE\s*(?:ACCOUNT)?\b", "", name)
    name = re.sub(r"\bOLD\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bMY\b", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\bN\s+LAST\b", "", name, flags=re.IGNORECASE)  # "SIRAJ N LAST"

    # ── Standalone KH ───────────────────────────────────────────
    # REMOVED: destroyed KHALID once ALID had already cut it to "KH".
    # name = re.sub(r"\bKH\b", "", name, flags=re.IGNORECASE)
    # REMOVED: cost ~1,270 rows - SHEIKH->SHEI, SHAIKH->SHAI,
    # FARRUKH->FARRU, RUKH->RU. Far more damage than IKRAMKH was worth.
    # name = re.sub(r"KH$", "", name, flags=re.IGNORECASE)

    # ── Standalone zero between names ───────────────────────────
    name = re.sub(r"\b\d{1,3}\b", "", name)      # removes 0, 10, 100 etc.

    # ── Trailing digit junk ─────────────────────────────────────
    name = re.sub(r"(\b[A-Z]+)\d+\b", r"\1", name)

    # ── Standalone digit sequences (4+) ─────────────────────────
    name = re.sub(r"\b\d{4,}\b", "", name)

    # ── Ampersand ───────────────────────────────────────────────
    name = name.replace("&", " AND ")

    # ── Trailing single char junk ───────────────────────────────
    name = re.sub(r"\s+[A-Z]\s*$", "", name)

    # ── Collapse spaces ─────────────────────────────────────────
    name = re.sub(r"\s+", " ", name).strip()

    # ── Deduplicate repeated names ──────────────────────────────
    words = name.split()
    if len(words) >= 2:
        mid = len(words) // 2
        if words[:mid] == words[mid:mid*2]:
            name = " ".join(words[:mid])
        else:
            # Only fold an EXACT even-length repeat. The old version
            # used name[half:half*2].lstrip() on odd-length strings,
            # which split inside a word - the cause of FAISAL -> FAIS.
            half = len(name) // 2
            if (half > 2 and len(name) % 2 == 0
                    and name[:half] == name[half:]):
                name = name[:half].strip()

    name = re.sub(r"\s+", " ", name).strip()

    return name if name else None

def _flag_names(series):
    """Vectorised replacement for the two identical row-loop flag blocks.
    Same four rules, same order, same ', ' join."""
    s = series.astype(str).str.strip()
    live = s.ne("") & ~s.isin(["nan", "None"])

    rules = [
        (s.str.contains(r"[A-Z]{15,}", regex=True, na=False), "Concatenated/no spaces"),
        (s.str.match(r"^[A-Z]{1,2}$", na=False),              "Too short"),
        (s.str.contains(r"\bAND\b", regex=True, na=False),    "Joint name (AND)"),
        (s.str.contains(r"\s/\s", regex=True, na=False),      "Joint name (slash)"),
    ]

    out = pd.Series("", index=series.index, dtype=object)
    for mask, label in rules:
        m = live & mask
        out[m] = out[m].where(out[m].eq(""), out[m] + ", ") + label
    return out


def _normalize_dates_by_channel(df):
    """Parse each date column using that ROW's channel convention, then write
    everything back as DD/MM/YYYY.

    Note on Open Date: an account opening date can be years old, so it must
    NOT be anchored to the reporting month. Instead it inherits the same
    ordering as the rest of its channel, which is safe because the ordering
    is a property of the exporting system, not of the date's value.
    """
    if "Channel" not in df.columns:
        print("         WARNING: no Channel column; using DEFAULT_DAYFIRST "
              "for all rows.")
        df["_chan_tmp"] = None
        chan_col = "_chan_tmp"
    else:
        chan_col = "Channel"

    chan = df[chan_col].astype(str).str.strip()
    groups = {}
    for c in chan.unique():
        groups[c] = CHANNEL_DAYFIRST.get(c, DEFAULT_DAYFIRST)

    unknown = [c for c in groups
               if c not in CHANNEL_DAYFIRST and c not in ("nan", "None", "")]
    if unknown:
        print(f"         WARNING: channel(s) {unknown} not in "
              f"CHANNEL_DAYFIRST; using DEFAULT_DAYFIRST={DEFAULT_DAYFIRST}")

    report = {}

    for col in DATE_COLUMNS:
        if col not in df.columns:
            continue

        out = pd.Series([None] * len(df), index=df.index, dtype=object)
        raw = df[col]
        had_value = raw.map(lambda v: not _is_empty(v))

        for c, dayfirst in groups.items():
            m = chan.eq(c)
            if not m.any():
                continue
            parsed = pd.to_datetime(raw[m], errors="coerce",
                                    format="mixed", dayfirst=dayfirst)
            out[m] = parsed.dt.strftime("%d/%m/%Y").where(parsed.notna(), None)

            lost = int((had_value[m] & out[m].isna()).sum())
            if lost:
                report.setdefault(c, {})[col] = lost

        df[col] = out

    if report:
        print("         Could not parse (had a value, produced no date):")
        for c in sorted(report):
            bits = ", ".join(f"{k}={v:,}" for k, v in report[c].items())
            print(f"           {c:10s} {bits}")
    else:
        print("         All non-empty dates parsed successfully.")

    if chan_col == "_chan_tmp":
        df.drop(columns=["_chan_tmp"], inplace=True)

    return df


def cleanse(df):
    df = df.copy()
    start = time.time()

    print("\n" + "=" * 60)
    print("  HBL PRI - Step 2: Data Cleansing")
    print(f"  Processing {len(df):,} rows")
    print("=" * 60 + "\n")

# 1. Purpose of Remittance -> split
    #    Remitter ID = numeric, alphanumeric (mixed letters+digits), or XXX patterns
    #    Purpose of Remittances = pure text strings only
    print("  [1/6] Splitting Purpose of Remittance...")
    src = "Purpose of Remittance"
    if src in df.columns:
        for _need in ("Remitter ID", "Purpose of Remittances"):
            if _need not in df.columns:
                df[_need] = None

        val = df[src].astype(str).str.strip()
        has_val = val.ne("") & ~val.isin(["nan", "None"])

        is_rid = (
            val.str.fullmatch(r"\d+", na=False)
            | (val.str.fullmatch(r"[A-Za-z0-9]+", na=False)
               & val.str.contains(r"\d", na=False))
            | val.str.fullmatch(r"(?i)X{2,}", na=False)
        )

        rid_empty = df["Remitter ID"].pipe(_ev)
        pur_empty = df["Purpose of Remittances"].pipe(_ev)

        m = has_val & is_rid & rid_empty
        df.loc[m, "Remitter ID"] = val[m]

        m = has_val & ~is_rid & pur_empty
        df.loc[m, "Purpose of Remittances"] = val[m]

    # 2. Remitter ID fallback
    print("  [2/6] Filling Remitter ID from fallback columns...")
    for fb in ["Remitter ID_2", "Remitter ID_3", "Remitter ID_4"]:
        if fb not in df.columns:
            continue
        mask = df["Remitter ID"].pipe(_ev)
        vals = df.loc[mask, fb].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
        ok = ~vals.isin(["", "nan", "None"]) & vals.notna()
        df.loc[mask & ok.reindex(df.index, fill_value=False), "Remitter ID"] = vals[ok]

    # 3. Remitter ID: strip leading "/"
    print("  [3/6] Cleaning Remitter ID...")
    df["Remitter ID"] = (
        df["Remitter ID"].astype(str).str.strip().str.lstrip("/")
        .replace({"nan": None, "None": None, "": None})
    )



    # 4. Name cleaning
    print("  [4/6] Cleaning names...")
    for col in ["Beneficiary Name", "Remitter Name"]:
        if col not in df.columns:
            continue
        _orig = df[col]
        df[COMM_ORIG_PREFIX + col] = _orig
        _clean = _clean_names_series(_orig)

        # Cleansing that EMPTIES a name has done more harm than good: the
        # name feeds two of the six keys, so an emptied name silently
        # drops that row out of EQ-1 and EQ-4. Fall back to the original,
        # tidied only for case and spacing.
        _lost = _clean.pipe(_ev) & ~_orig.pipe(_ev)
        if _lost.any():
            _fallback = _orig.map(
                lambda v: re.sub(r"\s+", " ", _s(v).upper()).strip())
            _clean = _clean.where(~_lost, _fallback)
            print(f"           {col}: {int(_lost.sum()):,} name(s) were "
                  f"emptied by cleansing - original restored")
        df[col] = _clean

# # 4b. Beneficiary Name: overwrite from LINK TITLE where available
#     if "LINK TITLE" in df.columns:
#         link_vals = df["LINK TITLE"].astype(str).str.strip()
#         ok = ~link_vals.isin(["", "nan", "None"]) & link_vals.notna()
#         df.loc[ok, "Beneficiary Name"] = df.loc[ok, "LINK TITLE"].apply(_clean_single_name)

# 4b. Beneficiary Name: fill from LINK TITLE when empty
    #     Skip pure numeric LINK TITLE values (e.g., 60064)
    if "LINK TITLE" in df.columns:
        bene_empty = df["Beneficiary Name"].pipe(_ev)
        link_vals = df.loc[bene_empty, "LINK TITLE"].astype(str).str.strip()
        ok = (
            ~link_vals.isin(["", "nan", "None"])
            & link_vals.notna()
            & link_vals.str.contains(r"[A-Za-z]", regex=True)
        )
        filled = bene_empty & ok.reindex(df.index, fill_value=False)
        df.loc[filled, "Beneficiary Name"] = _clean_names_series(
            df.loc[filled, "LINK TITLE"])

# 4c. Flag names that need manual review
    print("  [4c]  Flagging names for manual review...")
    flag_map = {
        "Remitter Name": "_flag Remitter Name",
        "Beneficiary Name": "_flag Beneficiary Name",
    }
    for col, flag_col in flag_map.items():
        df[flag_col] = ""
        if col in df.columns:
            df[flag_col] = _flag_names(df[col])

# 4d. Replace flagged Beneficiary Names with LINK TITLE and re-cleanse
    print("  [4d]  reverifying LINK Title...")
    if "LINK TITLE" in df.columns and "_flag Beneficiary Name" in df.columns:
        flagged = df["_flag Beneficiary Name"].astype(str).str.strip() != ""
        if flagged.any():
            link_vals = df.loc[flagged, "LINK TITLE"].astype(str).str.strip()
            ok = (
                ~link_vals.isin(["", "nan", "None"])
                & link_vals.notna()
                & link_vals.str.contains(r"[A-Za-z]", regex=True)
            )
            replaced = flagged & ok.reindex(df.index, fill_value=False)
            if replaced.sum() > 0:
                df.loc[replaced, "Beneficiary Name"] = _clean_names_series(
                    df.loc[replaced, "LINK TITLE"])
                # Re-flag after replacement (same rules, one definition)
                df.loc[replaced, "_flag Beneficiary Name"] = _flag_names(
                    df.loc[replaced, "Beneficiary Name"])
                print(f"  [4d]  {replaced.sum():,} flagged names replaced from LINK TITLE and re-cleansed")

# 4e. Reviewed names (decisions kept from earlier review, all runs)
    for col in ["Remitter Name", "Beneficiary Name"]:
        if col not in df.columns:
            continue
        df["_rule " + col] = df[col]
        if NAME_OVERRIDES or NAME_VARIANTS:
            new = apply_name_dictionary(df[COMM_ORIG_PREFIX + col], df[col])
            changed = new.pipe(_sv).ne(df[col].pipe(_sv))
            df[col] = new
            df["_flag " + col] = _flag_names(df[col])
            print(f"  [4e]  {col}: {int(changed.sum()):,} row(s) use a reviewed name")

# # 3b. Beneficiary Name: fill from LINK TITLE when empty
#     if "LINK TITLE" in df.columns:
#         bene_empty = df["Beneficiary Name"].pipe(_ev)
#         link_vals = df.loc[bene_empty, "LINK TITLE"].astype(str).str.strip()
#         ok = ~link_vals.isin(["", "nan", "None"]) & link_vals.notna()
#         df.loc[bene_empty & ok.reindex(df.index, fill_value=False), "Beneficiary Name"] = link_vals[ok]

# 5. Date normalization (DD/MM/YYYY)
    print("  [5/6] Normalizing dates...")
    df = _normalize_dates_by_channel(df)

    # 6. General cleanup
    print("  [6/6] General cleanup...")
    skip = {"Upload Date", "Open Date", "Value Date", "Payment Date"}
    nums = {"Amount", "FCY Amount"}
    for col in df.columns:
        if col in skip:
            continue
        if col in nums:
            df[col] = pd.to_numeric(
                df[col].astype(str).str.replace(",", "").str.strip(), errors="coerce")
        elif df[col].dtype == object:
            df[col] = df[col].astype(str).str.strip().replace({"nan": None, "None": None, "": None})

# Prevent scientific notation for long numeric columns
    df = _fix_text_columns(df)

    # Regenerate derived columns
    print("  Regenerating derived columns...")
    df = generate_derived_columns(df)

    print(f"\n  CLEANSING COMPLETE in {time.time() - start:.1f}s\n")
    return df


# ════════════════════════════════════════════════════════════════════
#  PART 3: VLOOKUP
# ════════════════════════════════════════════════════════════════════

# ── File paths ──────────────────────────────────────────────────────
ENTITY_LIST_FILE = "entity_list.xlsx"

# ITRS files per month — add/remove as needed
ITRS_FILES = {
    "Oct, 2025": "ITRS Data Oct, 2025.xlsx",
    "Nov, 2025": "ITRS Data Nov, 2025.xlsx",
    "Sep, 2025": "ITRS Data Sep, 2025.xlsx",
}

def _normalize_re(code):
    """Strip trailing X's from R.E code for matching. CHASUS33XXX → CHASUS33"""
    if not code:
        return ""
    return re.sub(r"X+$", "", str(code).strip(), flags=re.IGNORECASE)

def vlookup(df):
    """
    Apply VLOOKUP enrichment on the cleansed DataFrame.
    1. Entity List: R.E → R.E Name, Country, Claim/No Claim, Claim Country
    2. ITRS: R.E + URN → Country of Origin (TOTAL sheet first, then RDA)
    """
    df = df.copy()
    start = time.time()

    print("\n" + "=" * 60)
    print("  HBL PRI - Step 3: VLOOKUP Enrichment")
    print(f"  Processing {len(df):,} rows")
    print("=" * 60 + "\n")

    # ── 1. Entity List Lookup ───────────────────────────────────
    df = _lookup_entity_list(df)

    # ── 2. ITRS Lookup ──────────────────────────────────────────
    df = _lookup_itrs(df)

    print(f"\n  VLOOKUP COMPLETE in {time.time() - start:.1f}s\n")
    return df


def _lookup_entity_list(df):
    """Match R.E → PFB_FNINCODE, fetch R.E Name, Country, Claim/No Claim."""
    if not os.path.exists(ENTITY_LIST_FILE):
        print(f"  [1/2] Entity List: FILE NOT FOUND ({ENTITY_LIST_FILE}), skipping.")
        return df

    print(f"  [1/2] Entity List lookup...")
    try:
        ent = pd.read_excel(ENTITY_LIST_FILE, dtype=str, engine="calamine")
    except Exception:
        ent = pd.read_excel(ENTITY_LIST_FILE, dtype=str, engine="openpyxl")

# Build lookup dict: normalized PFB_FNINCODE → {desc, country, remarks}
    for _c in ("PFB_FNINCODE", "PFB_FNINDESC", "COUNTRY", "Remarks"):
        if _c not in ent.columns:
            print(f"         WARNING: entity list has no column '{_c}'")
            ent[_c] = None

    ent = ent.copy()
    ent["_key"] = ent["PFB_FNINCODE"].pipe(_mu, lambda v: _normalize_re(_s(v)))
    ent = ent[ent["_key"].ne("")].drop_duplicates("_key", keep="last")

    name_map = dict(zip(ent["_key"], ent["PFB_FNINDESC"].pipe(_sv)))
    ctry_map = dict(zip(ent["_key"], ent["COUNTRY"].pipe(_sv)))
    clam_map = dict(zip(ent["_key"], ent["Remarks"].pipe(_sv)))

    # Apply lookup (vectorised)
    keys = df["R.E"].pipe(_mu, lambda v: _normalize_re(_s(v)))
    hit = keys.isin(name_map.keys())

    df.loc[hit, "R.E Name"] = keys[hit].map(name_map).replace("", None)
    df.loc[hit, "Country"] = keys[hit].map(ctry_map).replace("", None)
    df.loc[hit, "Claim / No Claim"] = keys[hit].map(clam_map).replace("", None)
    df.loc[hit, "Claim Country"] = keys[hit].map(ctry_map).replace("", None)
    matched = int(hit.sum())

    unmatched = len(df) - matched
    print(f"         Matched: {matched:,} | Unmatched: {unmatched:,}")
    return df


def _itrs_sheets_for(path, prefix):
    """Every sheet in `path` whose name starts with `prefix`.

    A month is sometimes split across "TOTAL 01-15" and "TOTAL 16-31".
    Matching only the exact name would find neither; matching only the
    first would silently lose half the month. So all of them are returned,
    in workbook order.

    Case and whitespace are ignored: "total 01-15", "TOTAL01-15" and
    "Total 01 - 15" all match the prefix "TOTAL".
    """
    want = re.sub(r"\s+", "", str(prefix)).upper()
    try:
        names = pd.ExcelFile(path, engine="calamine").sheet_names
    except Exception:
        return []
    return [n for n in names
            if re.sub(r"\s+", "", str(n)).upper().startswith(want)]


ITRS_CACHE_DIR = ""     # set by the web app: parsed ITRS sheets are kept here
ITRS_FILE_IDS = {}      # path -> SHA-256 of the uploaded file (cache key)


def _itrs_cache_path(path, sheet):
    fid = ITRS_FILE_IDS.get(os.path.abspath(path))
    if not ITRS_CACHE_DIR or not fid:
        return ""
    import hashlib
    tag = hashlib.sha1(("%s|%s" % (fid, sheet)).encode("utf-8")).hexdigest()[:24]
    return os.path.join(ITRS_CACHE_DIR, "itrs_%s.pkl" % tag)


def _read_itrs_sheet(path, sheet, cache):
    """One ITRS sheet -> (frame of _key/_cc, message). Runs in a worker
    process, so everything it needs arrives as arguments (the web app's
    settings are not visible there). The frame keeps the LAST occurrence
    of a key, exactly like the dict the lookup used to build."""
    if cache and os.path.exists(cache):
        try:
            return pd.read_pickle(cache), "cached"
        except Exception:
            pass
    try:
        try:
            itrs = pd.read_excel(path, sheet_name=sheet, dtype=str, engine="calamine")
        except Exception:
            itrs = pd.read_excel(path, sheet_name=sheet, dtype=str, engine="openpyxl")
    except Exception as e:
        return None, "could not read (%s), skipping." % e
    want = {_norm_header(c): c for c in ("R.E", "URN", "Country Code")}
    itrs = itrs.rename(columns={c: want[_norm_header(c)] for c in itrs.columns
                                if _norm_header(c) in want and c not in want.values()})
    missing = [c for c in ("R.E", "URN", "Country Code") if c not in itrs.columns]
    if missing:
        return None, "missing columns %s, skipping." % missing
    out = pd.DataFrame({
        "_key": itrs["R.E"].pipe(_mu, lambda v: _normalize_re(_s(v))) + itrs["URN"].pipe(_sv),
        "_cc": itrs["Country Code"].pipe(_sv)})
    out = out[out["_key"].ne("") & out["_cc"].ne("")]
    out = out.drop_duplicates("_key", keep="last").reset_index(drop=True)
    if cache:
        try:
            os.makedirs(os.path.dirname(cache), exist_ok=True)
            out.to_pickle(cache + ".tmp")
            os.replace(cache + ".tmp", cache)
        except Exception:
            pass
    return out, "read"


def _read_itrs_job(args):
    return _read_itrs_sheet(*args)


def _lookup_itrs(df):
    """Match R.E + URN -> Country Code from ITRS files (TOTAL then RDA).

    Every sheet needed is read up front - in parallel, and from the cache
    when the same file was read before - then applied in the same order
    as always: per month, all TOTAL sheets, then all RDA sheets, first
    match wins."""
    upload_dates = pd.to_datetime(df["Upload Date"], errors="coerce", format="%d/%m/%Y")
    periods = upload_dates.dt.to_period("M")
    months = periods.dropna().unique()
    if len(months) == 0:
        print(f"  [2/2] ITRS lookup: No valid dates found, skipping.")
        return df
    print(f"  [2/2] ITRS lookup ({len(months)} months detected)...")

    df["_itrs_key"] = (df["R.E"].pipe(_mu, lambda v: _normalize_re(_s(v)))
                       + df["URN"].pipe(_sv))
    needs_lookup = df["Country of Origin"].pipe(_ev)
    month_map = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
                 7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"}

    plan = []        # (period, itrs_key, path, [sheets])
    for period in sorted(months):
        itrs_key = f"{month_map.get(period.month, '')}, {period.year}"
        if itrs_key not in ITRS_FILES:
            print(f"         {itrs_key}: No ITRS file configured, skipping.")
            continue
        path = ITRS_FILES[itrs_key]
        if not os.path.exists(path):
            print(f"         {itrs_key}: FILE NOT FOUND ({path}), skipping.")
            continue
        if not ((periods == period) & needs_lookup).any():
            continue
        sheets = []
        for prefix in ["TOTAL", "RDA"]:
            found = _itrs_sheets_for(path, prefix)
            if not found:
                print(f"         {itrs_key}: no '{prefix}*' sheet, skipping.")
            sheets.extend(found)
        plan.append((period, itrs_key, path, sheets))

    jobs = [(path, sheet, _itrs_cache_path(path, sheet))
            for _p, _k, path, sheets in plan for sheet in sheets]
    t0 = time.time()
    results = {}
    if NAME_WORKERS > 1 and len(jobs) > 1:
        try:
            for job, res in zip(jobs, _process_map(_read_itrs_job, jobs,
                                                   min(NAME_WORKERS, len(jobs)))):
                results[job] = res
        except Exception as e:
            print(f"         (parallel ITRS reading unavailable: {e}; reading one by one)")
            results = {}
    for job in jobs:
        if job not in results:
            results[job] = _read_itrs_sheet(*job)
    n_cached = sum(1 for r in results.values() if r[1] == "cached")
    print(f"         {len(jobs)} ITRS sheet(s) loaded in {time.time() - t0:.1f}s"
          f"{f' ({n_cached} from cache)' if n_cached else ''}")

    for period, itrs_key, path, sheets in plan:
        month_mask = (periods == period) & needs_lookup
        for sheet in sheets:
            if not month_mask.any():
                break
            frame, msg = results[(path, sheet, _itrs_cache_path(path, sheet))]
            if frame is None:
                print(f"         {itrs_key} [{sheet}]: {msg}")
                continue
            lookup = pd.Series(frame["_cc"].values, index=frame["_key"].values)
            cand = df.loc[month_mask, "_itrs_key"]
            found = cand.map(lookup)
            hit_idx = found[found.notna()].index
            df.loc[hit_idx, "Country of Origin"] = found[hit_idx]
            needs_lookup.loc[hit_idx] = False
            month_mask.loc[hit_idx] = False
            print(f"         {itrs_key} [{sheet}]: {len(hit_idx):,} matched")

    df.drop(columns=["_itrs_key"], inplace=True)
    total_filled = (~df["Country of Origin"].pipe(_ev)).sum()
    still_empty = df["Country of Origin"].pipe(_ev).sum()
    print(f"         Total filled: {total_filled:,} | Still empty: {still_empty:,}")
    return df


def _rule_orre(df):
    """Split and relabel ORRE rows.

    Returns (main_df, orre_df). orre_df is the rows pulled OUT of the main
    sheet; it may be empty.
    """
    for col in ("R.E", "URN", "Bene Bank"):
        if col not in df.columns:
            print(f"         ORRE: no '{col}' column, rule skipped.")
            return df, None

    re_s = df["R.E"].pipe(_sv)

    if ORRE_MATCH_MODE == "startswith":
        in_scope = re_s.str.startswith(
            ORRE_TAG if ORRE_MATCH_CASE_SENSITIVE else ORRE_TAG.upper()
        ) if ORRE_MATCH_CASE_SENSITIVE else re_s.str.upper().str.startswith(
            ORRE_TAG.upper())
    else:
        in_scope = re_s.str.contains(
            re.escape(ORRE_TAG), case=ORRE_MATCH_CASE_SENSITIVE,
            regex=True, na=False)

    n_scope = int(in_scope.sum())
    if n_scope == 0:
        print(f"         ORRE: no rows matched '{ORRE_TAG}' in R.E.")
        return df, None

    urn_s = df["URN"].pipe(_sv)
    ends_digit = urn_s.str.match(r".*\d$", na=False)
    urn_blank = urn_s.eq("")

    keep = in_scope & ends_digit
    move = in_scope & ~ends_digit
    if not ORRE_BLANK_URN_TO_TAB:
        move = move & ~urn_blank

    # Relabel the rows that stay
    bank = df["Bene Bank"].pipe(_sv).str.upper().str.strip()
    is_hbl = bank.eq(ORRE_HBL_BANK.upper())

    df.loc[keep & is_hbl, "R.E"] = ORRE_HBL_VALUE
    df.loc[keep & ~is_hbl, "R.E"] = ORRE_OTHER_VALUE

    n_hbl = int((keep & is_hbl).sum())
    n_oth = int((keep & ~is_hbl).sum())
    n_move = int(move.sum())

    print(f"         ORRE: {n_scope:,} row(s) in scope")
    print(f"           -> {ORRE_HBL_VALUE}:  {n_hbl:,}")
    print(f"           -> {ORRE_OTHER_VALUE}:  {n_oth:,}")
    print(f"           -> moved to '{ORRE_SHEET_NAME}' tab: {n_move:,} "
          f"(URN not ending in a digit"
          f"{', incl. blank URN' if ORRE_BLANK_URN_TO_TAB else ''})")

    orre_df = df.loc[move].copy() if n_move else None
    main_df = df.loc[~move].copy() if n_move else df

    return main_df, orre_df


def _amount_key(val):
    """Normalise an amount to a fixed-decimal string for key building.

    Strips commas, currency symbols and spaces. '84155', '84155.0',
    ' 84,155.00 ' and 84155.0 all collapse to '84155.00'. Returns '' when
    the value is not numeric, so such rows can never form a false match.
    """
    s = _s(val)
    if not s:
        return ""
    # Strip thousands separators, currency symbols and spaces, but keep
    # exponent notation intact - a large float can stringify as 1.5e+15,
    # and blindly deleting the 'e' would turn it into a different number.
    cleaned = re.sub(r"[,\s\u00a0]", "", s)
    candidates = [cleaned]
    m = re.search(r"-?\d+(?:\.\d+)?", cleaned)   # e.g. "Rs.20003.25"
    if m:
        candidates.append(m.group(0))
    for candidate in candidates:
        if not candidate or candidate in ("-", ".", "-."):
            continue
        try:
            return f"{float(candidate):.{AMOUNT_KEY_DECIMALS}f}"
        except (ValueError, OverflowError):
            continue
    return ""


def _cancel_pattern():
    """Build the Comments regex once."""
    parts = [re.escape(k) for k in CANCEL_KEYWORDS]
    parts += [r"\b" + re.escape(k) + r"\b" for k in CANCEL_KEYWORDS_WORD]
    return "|".join(parts)


CANCEL_REASON_COL = "Cancel Reason"
# Excel keeps 15 significant digits. A 16+ digit reference typed or pasted
# into the refunds workbook as a NUMBER therefore arrives with its tail
# zeroed (2026126050980614 -> 2026126050980610). Those are matched on the
# first 15 digits + the amount, and reported.
REFUND_PRECISION_DIGITS = 15


def _refund_ref(val):
    """Reference from the refunds workbook as clean text."""
    s = re.sub(r"\s+", "", _s(val))
    if not s:
        return ""
    if re.fullmatch(r"\d+\.0+", s):
        return s.split(".")[0]
    if re.fullmatch(r"\d(\.\d+)?[eE]\+?\d+", s):
        try:
            from decimal import Decimal
            return str(int(Decimal(s)))
        except Exception:
            return s
    return s


def _rule_cancelled(df):
    """Move refunded/cancelled rows to their own sheet.

    Returns (main_df, cancelled_df). The cancelled frame carries a
    'Cancel Reason' column saying which rule caught each row.
    """
    if "Comments" not in df.columns:
        print("         Cancelled: no 'Comments' column.")
        comment_hit = pd.Series(False, index=df.index)
    else:
        comment_hit = df["Comments"].pipe(_sv).str.contains(
            _cancel_pattern(), case=False, regex=True, na=False)
    n_comment = int(comment_hit.sum())

    file_hit = pd.Series(False, index=df.index)
    loose15 = pd.Series(False, index=df.index)
    if not REFUNDS_FILE or not os.path.exists(REFUNDS_FILE):
        print(f"         Cancelled: refunds file NOT FOUND - "
              f"file match skipped, comments rule still applied.")
    elif "URN" not in df.columns or "Amount" not in df.columns:
        print("         Cancelled: main sheet lacks URN/Amount, "
              "file match skipped.")
    else:
        ref, _ref_hdr = _read_sheet_with_header_scan(
            REFUNDS_FILE, 0, REFUND_REF_COL, RDA_HBL_HEADER_SCAN_ROWS)
        if ref is None:
            print(f"         Cancelled: WARNING no '{REFUND_REF_COL}' header "
                  f"found in the first {RDA_HBL_HEADER_SCAN_ROWS} rows of the "
                  f"refunds file")
        else:
            cols = {_norm_header(c): c for c in ref.columns}
            c_ref = cols.get(_norm_header(REFUND_REF_COL))
            c_amt = cols.get(_norm_header(REFUND_AMT_COL))
            if c_ref is None or c_amt is None:
                print(f"         Cancelled: WARNING refunds file needs columns "
                      f"'{REFUND_REF_COL}' and '{REFUND_AMT_COL}'; found "
                      f"{list(ref.columns)}")
            else:
                ref_no = ref[c_ref].pipe(_mu, _refund_ref)
                ref_amt = ref[c_amt].pipe(_mu, _amount_key)
                live = ref_no.ne("")
                urn = df["URN"].pipe(_sv)
                main_amt = df["Amount"].pipe(_mu, _amount_key)

                if REFUND_KEY_INCLUDES_AMOUNT:
                    ref_key = ref_no + "|" + ref_amt
                    main_key = urn + "|" + main_amt
                else:
                    ref_key = ref_no
                    main_key = urn
                file_hit = main_key.isin(set(ref_key[live])) & urn.ne("")
                print(f"         Cancelled: {int(live.sum()):,} refund "
                      f"record(s) loaded (header on row {_ref_hdr + 1})")
                print(f"           reference + amount match: "
                      f"{int(file_hit.sum()):,} row(s)")

                # -- 15-digit fallback for references damaged by Excel --
                P = REFUND_PRECISION_DIGITS
                used = set(main_key[file_hit])
                left = live & ~ref_key.isin(used)
                cand = left & ref_no.str.fullmatch(r"\d{%d,}" % (P + 1)) \
                    & ref_no.str[P:].str.fullmatch(r"0+")
                if cand.any():
                    k15 = set((ref_no.str[:P] + "|" + ref_no.str.len().astype(str)
                               + "|" + ref_amt)[cand])
                    m15 = (urn.str[:P] + "|" + urn.str.len().astype(str)
                           + "|" + main_amt)
                    loose15 = (m15.isin(k15) & ~file_hit
                               & urn.str.fullmatch(r"\d{%d,}" % (P + 1)))
                    if loose15.any():
                        print(f"           WARNING: {int(loose15.sum()):,} "
                              f"more row(s) matched on the first {P} digits "
                              f"+ amount - the refunds file holds these "
                              f"references as numbers, so Excel zeroed the "
                              f"last digit(s). Store that column as Text.")
                        for u in urn[loose15].head(5):
                            print(f"             {u}")
                    used |= set()
                hit_all = file_hit | loose15

                # -- refund records that found nothing --
                got = set(urn[hit_all])
                got15 = set(urn[loose15].str[:P])
                unmatched = [r for r in ref_no[live]
                             if r not in got and r[:P] not in got15]
                loose_urn = urn.isin(set(ref_no[live])) & urn.ne("") & ~hit_all
                if loose_urn.any():
                    print(f"           WARNING: {int(loose_urn.sum()):,} row(s) "
                          f"match a refund reference but NOT its amount - "
                          f"left in place, please review:")
                    for _i in df.index[loose_urn][:5]:
                        print(f"             URN {urn.at[_i]}: amount "
                              f"{main_amt.at[_i]}")
                if unmatched:
                    print(f"           {len(unmatched):,} refund record(s) "
                          f"found no transaction (other month, or ORRE):")
                    for r in unmatched[:5]:
                        print(f"             {r}")
                    if len(unmatched) > 5:
                        print(f"             ... and {len(unmatched) - 5:,} more")

    move = comment_hit | file_hit | loose15
    n_move = int(move.sum())
    print(f"         Cancelled: comments keyword: {n_comment:,} row(s)")
    print(f"         Cancelled: moved to '{CANCELLED_SHEET_NAME}' tab: "
          f"{n_move:,}")
    if n_move == 0:
        return df, None

    reason = pd.Series("", index=df.index, dtype=object)
    reason[file_hit] = "Refund file"
    reason[loose15] = "Refund file (first %d digits + amount)" % REFUND_PRECISION_DIGITS
    both = comment_hit & reason.ne("")
    reason[both] = reason[both] + " + comment keyword"
    reason[comment_hit & reason.eq("")] = "Comment keyword"
    out = df.loc[move].copy()
    out[CANCEL_REASON_COL] = reason[move]
    return df.loc[~move].copy(), out


def _to_number(val):
    """Tolerant numeric parse for Amount. Returns None when not numeric,
    so a bad value yields a BLANK USD Eqv. rather than a misleading 0."""
    s = _s(val)
    if not s:
        return None
    cleaned = re.sub(r"[,\s\u00a0]", "", s)
    candidates = [cleaned]
    m = re.search(r"-?\d+(?:\.\d+)?", cleaned)
    if m:
        candidates.append(m.group(0))
    for c in candidates:
        if not c or c in ("-", ".", "-."):
            continue
        try:
            return float(c)
        except (ValueError, OverflowError):
            continue
    return None


def _apply_usd_conversion(df):
    """Fill USD Rate on every row and compute USD Eqv. = Amount / rate.

    Runs before the split rules so ORRE / Cancelled rows carry the values.
    """
    if USD_RATE is None:
        print(f"         USD: USD_RATE is None - step skipped. Set it at the "
              f"top of this file to populate '{USD_RATE_COL}'.")
        return df

    try:
        rate = float(USD_RATE)
    except (TypeError, ValueError):
        print(f"         USD: USD_RATE={USD_RATE!r} is not a number - "
              f"step skipped.")
        return df

    if rate == 0:
        print("         USD: USD_RATE is 0 - refused (division by zero).")
        return df

    for col in (USD_RATE_COL, USD_EQV_COL):
        if col not in df.columns:
            print(f"         USD: adding missing column '{col}'.")
            df[col] = None

    df[USD_RATE_COL] = rate

    amt = df["Amount"].map(_to_number) if "Amount" in df.columns else None
    if amt is None:
        print("         USD: no 'Amount' column - USD Eqv. not computed.")
        return df

    eqv = (amt / rate).round(USD_EQV_DECIMALS)
    df[USD_EQV_COL] = eqv.where(amt.notna(), None)

    n_ok = int(eqv.notna().sum())
    n_blank = len(df) - n_ok
    print(f"         USD: rate {rate:,.4f} applied to {len(df):,} row(s)")
    print(f"         USD: USD Eqv. computed for {n_ok:,} row(s), "
          f"{n_blank:,} left blank (Amount missing or non-numeric)")
    return df


def _norm_ref(val):
    """Strip ALL whitespace from a reference - same effect as Excel
    text-to-column on the RDA-HBL reference column."""
    return re.sub(r"\s+", "", _s(val))


def _norm_header(val):
    """Header comparison key: lowercase, no whitespace."""
    return re.sub(r"\s+", "", _s(val)).lower()


_SCAN_CACHE = {}


def _read_sheet_with_header_scan(path, sheet, target_header, scan_rows):
    """Read one worksheet, finding the header row rather than assuming it.

    Some sheets start at row 1, some at row 2. Reads raw, scans the first
    `scan_rows` rows for one containing `target_header`, then re-reads
    using that row as the header. Returns (df, header_row) or (None, None).
    """
    target = _norm_header(target_header)
    try:
        _ck = (os.path.abspath(path), sheet, target, os.path.getmtime(path))
    except OSError:
        return None, None
    if _ck in _SCAN_CACHE:
        return _SCAN_CACHE[_ck]
    while len(_SCAN_CACHE) > 12:
        _SCAN_CACHE.pop(next(iter(_SCAN_CACHE)))
    res = _read_sheet_with_header_scan_uncached(path, sheet, target_header,
                                                scan_rows)
    _SCAN_CACHE[_ck] = res
    return res


def _read_sheet_with_header_scan_uncached(path, sheet, target_header,
                                          scan_rows):
    target = _norm_header(target_header)
    try:
        try:
            raw = pd.read_excel(path, sheet_name=sheet, dtype=str,
                                header=None, engine="calamine",
                                nrows=scan_rows)
        except Exception:
            raw = pd.read_excel(path, sheet_name=sheet, dtype=str,
                                header=None, engine="openpyxl",
                                nrows=scan_rows)
    except Exception:
        return None, None

    header_row = None
    for i in range(min(scan_rows, len(raw))):
        cells = {_norm_header(v) for v in raw.iloc[i].tolist()}
        if target in cells:
            header_row = i
            break

    if header_row is None:
        return None, None

    try:
        try:
            df = pd.read_excel(path, sheet_name=sheet, dtype=str,
                               header=header_row, engine="calamine")
        except Exception:
            df = pd.read_excel(path, sheet_name=sheet, dtype=str,
                               header=header_row, engine="openpyxl")
    except Exception:
        return None, None

    return df, header_row


def _load_rda_hbl_refs():
    """Collect every reference from every sheet of every .xlsx in the
    RDA-HBL folder. Returns (set_of_refs, files_seen)."""
    refs = set()
    files_seen = 0

    if not os.path.isdir(RDA_HBL_FOLDER):
        print(f"           {RDA_HBL_FOLDER}/ NOT FOUND - RDA HBL step "
              f"skipped.")
        return refs, files_seen

    names = sorted(
        f for f in os.listdir(RDA_HBL_FOLDER)
        if f.lower().endswith((".xlsx", ".xlsm", ".xls"))
        and not f.startswith("~$")          # Excel lock files
    )
    if not names:
        print(f"           {RDA_HBL_FOLDER}/ contains no Excel files.")
        return refs, files_seen

    target = _norm_header(RDA_HBL_REF_COL)

    for fname in names:
        path = os.path.join(RDA_HBL_FOLDER, fname)
        files_seen += 1
        try:
            xl = pd.ExcelFile(path, engine="calamine")
            sheets = xl.sheet_names
        except Exception as e:
            print(f"           {fname}: could not open ({e})")
            continue

        file_total = 0
        for sheet in sheets:
            sub, hdr_row = _read_sheet_with_header_scan(
                path, sheet, RDA_HBL_REF_COL, RDA_HBL_HEADER_SCAN_ROWS)
            if sub is None:
                continue

            col = next((c for c in sub.columns
                        if _norm_header(c) == target), None)
            if col is None:
                continue

            vals = sub[col].pipe(_mu, _norm_ref)
            vals = vals[vals.ne("")]
            refs.update(vals)
            file_total += len(vals)
            print(f"           {fname} [{sheet}]: {len(vals):,} ref(s), "
                  f"header on row {hdr_row + 1}")

        if file_total == 0:
            print(f"           {fname}: NO usable sheet found "
                  f"(no '{RDA_HBL_REF_COL}' header in first "
                  f"{RDA_HBL_HEADER_SCAN_ROWS} rows)")

    return refs, files_seen


def _rule_rda(df, extra_sheets):
    """Classify RDA / NON RDA on the MAIN SHEET only.

    ORRE and Cancelled frames are read (to double-check leftover lookup
    rows) but never modified.

    Returns (df, unmatched_df_or_None).
    """
    if RDA_COL not in df.columns:
        print(f"         RDA: adding missing column '{RDA_COL}'.")
        df[RDA_COL] = None

    if "URN" not in df.columns or "R.E" not in df.columns:
        print("         RDA: main sheet lacks R.E/URN - step skipped.")
        return df, None

    main_re = df["R.E"].pipe(_mu, lambda v: _normalize_re(_s(v)))
    main_urn = df["URN"].pipe(_mu, _norm_ref)
    main_key = main_re + "|" + main_urn

    classified = pd.Series(False, index=df.index)
    unmatched_df = None

    # ── 1. RDA-Other -> 3RD BANK RDA ────────────────────────────
    print("         RDA: [1/3] RDA-Other lookup...")
    if not os.path.exists(RDA_OTHER_FILE):
        print(f"           {RDA_OTHER_FILE} NOT FOUND - step skipped.")
    else:
        try:
            try:
                other = pd.read_excel(RDA_OTHER_FILE, dtype=str,
                                      engine="calamine")
            except Exception:
                other = pd.read_excel(RDA_OTHER_FILE, dtype=str,
                                      engine="openpyxl")
        except Exception as e:
            other = None
            print(f"           could not read {RDA_OTHER_FILE} ({e})")

        if other is not None:
            missing = [c for c in ("R.E", "URN") if c not in other.columns]
            if missing:
                print(f"           {RDA_OTHER_FILE} missing {missing}; "
                      f"found {list(other.columns)}")
            else:
                o_key = (other["R.E"].pipe(_mu, lambda v: _normalize_re(_s(v)))
                         + "|" + other["URN"].pipe(_mu, _norm_ref))
                o_valid = o_key.ne("|")
                key_set = set(o_key[o_valid])

                hit = main_key.isin(key_set) & main_urn.ne("")
                df.loc[hit, RDA_COL] = RDA_VALUE_3RD
                classified |= hit
                print(f"           {len(other):,} record(s) loaded, "
                      f"{int(hit.sum()):,} main row(s) -> {RDA_VALUE_3RD}")

                # Which lookup rows found nothing in main?
                main_set = set(main_key[main_urn.ne("")])
                left = o_valid & ~o_key.isin(main_set)

                # Double-check leftovers against ORRE / Cancelled
                for tab in (ORRE_SHEET_NAME, CANCELLED_SHEET_NAME):
                    tdf = extra_sheets.get(tab)
                    if tdf is None or not len(tdf) or not left.any():
                        continue
                    if "R.E" not in tdf.columns or "URN" not in tdf.columns:
                        continue
                    t_key = set(
                        tdf["R.E"].pipe(_mu, lambda v: _normalize_re(_s(v)))
                        + "|" + tdf["URN"].pipe(_mu, _norm_ref))
                    found = left & o_key.isin(t_key)
                    if found.any():
                        print(f"           {int(found.sum()):,} leftover(s) "
                              f"found in '{tab}' tab")
                        left = left & ~found

                n_left = int(left.sum())
                if n_left:
                    unmatched_df = other.loc[left].copy()
                    print(f"           RED FLAG: {n_left:,} {RDA_OTHER_FILE} "
                          f"row(s) matched nothing in main, ORRE or "
                          f"Cancelled -> '{RDA_OTHER_UNMATCH_SHEET}' tab")
                else:
                    print(f"           all {RDA_OTHER_FILE} rows accounted "
                          f"for.")

    # ── 2. RDA-HBL -> RDA HBL (unclassified rows only) ──────────
    print("         RDA: [2/3] RDA-HBL folder lookup...")
    refs, files_seen = _load_rda_hbl_refs()
    if refs:
        avail = ~classified & main_urn.ne("")
        hit = avail & main_urn.isin(refs)
        df.loc[hit, RDA_COL] = RDA_VALUE_HBL
        classified |= hit
        print(f"           {len(refs):,} distinct ref(s) from "
              f"{files_seen} file(s), {int(hit.sum()):,} main row(s) "
              f"-> {RDA_VALUE_HBL}")

    # ── 3. Remainder -> Non RDA ─────────────────────────────────
    print("         RDA: [3/3] Remainder...")
    rest = ~classified
    df.loc[rest, RDA_COL] = RDA_VALUE_NON
    print(f"           {int(rest.sum()):,} row(s) -> {RDA_VALUE_NON}")

    counts = df[RDA_COL].pipe(_sv).value_counts()
    for k, v in counts.items():
        print(f"           {k:16s} {v:,}")

    return df, unmatched_df


def _rule_account_review(df):
    """Flag Account No patterns needing manual review.

    Writes RDA_COMMENT_COL, positioned immediately after RDA_COL. The
    value is the matched pattern, e.g. "0786+44".
    """
    if "Account No" not in df.columns:
        print("         Review: no 'Account No' column - step skipped.")
        return df

    acct = df["Account No"].pipe(_sv)
    rda = df[RDA_COL].pipe(_sv).str.upper() if RDA_COL in df.columns else None

    comment = pd.Series("", index=df.index, dtype=object)
    if rda is None:
        eligible = pd.Series(True, index=df.index)
    else:
        wanted = {w.upper() for w in RDA_REVIEW_WHEN}
        eligible = rda.isin(wanted)

    total = 0
    for prefix, suffix in RDA_REVIEW_PATTERNS:
        m = (eligible
             & acct.str.startswith(prefix)
             & acct.str.endswith(suffix))
        label = f"{prefix}+{suffix}"
        comment[m & comment.eq("")] = label
        n = int(m.sum())
        total += n
        if n:
            print(f"           {label}: {n:,} row(s)")

    df[RDA_COMMENT_COL] = comment.replace({"": None})

    # Position immediately after RDA_COL
    cols = [c for c in df.columns if c != RDA_COMMENT_COL]
    if RDA_COL in cols:
        at = cols.index(RDA_COL) + 1
        cols.insert(at, RDA_COMMENT_COL)
    else:
        cols.append(RDA_COMMENT_COL)
    df = df[cols]

    flagged = int(df[RDA_COMMENT_COL].notna().sum())
    print(f"         Review: {flagged:,} row(s) flagged for manual "
          f"intervention (of {total:,} pattern hits)")
    return df


def _cnic_normalize(series):
    """Strip hyphens, spaces and non-breaking spaces. Done BEFORE
    validation so 12345-1234567-1 is not thrown away as invalid."""
    return series.pipe(_sv).str.replace(r"[-\s\u00a0]", "", regex=True)


def _cnic_valid_mask(series):
    """Exactly CNIC_LENGTH digits, numeric only, not starting with 0."""
    s = series.pipe(_sv)
    return (s.str.fullmatch(r"\d{" + str(CNIC_LENGTH) + r"}", na=False)
            & ~s.str.startswith("0"))


def _cnic_clean_step(df, label):
    """Normalise then blank out everything that fails validation."""
    before = int(df[CNIC_COL].pipe(_sv).ne("").sum())
    df[CNIC_COL] = _cnic_normalize(df[CNIC_COL])
    good = _cnic_valid_mask(df[CNIC_COL])
    df.loc[~good, CNIC_COL] = None
    after = int(good.sum())
    print(f"           {label}: {before:,} non-blank -> {after:,} valid "
          f"({before - after:,} cleared)")
    return df


def _rule_cnic(df):
    """Validate CNIC NO., backfill from 7122.xlsx then fm.xlsx, re-validate."""
    if CNIC_COL not in df.columns:
        print(f"         CNIC: no '{CNIC_COL}' column - step skipped.")
        return df

    # ── 1-2. strip hyphens, then validate ───────────────────────
    df = _cnic_clean_step(df, "[1/4] initial validation")

    urn = df["URN"].pipe(_sv) if "URN" in df.columns else None
    if urn is None:
        print("         CNIC: no URN column - backfill skipped.")
        return df

    # ── 3. Backfill A: Mode == OC, from 7122.xlsx ───────────────
    print(f"         CNIC: [2/4] {CNIC_OC_FILE} backfill (Mode == "
          f"{CNIC_OC_MODE})...")
    blank = df[CNIC_COL].pipe(_ev)
    mode_ok = (df["Mode"].pipe(_sv).str.upper().str.strip()
               .eq(CNIC_OC_MODE.upper()) if "Mode" in df.columns
               else pd.Series(False, index=df.index))
    target = blank & mode_ok & urn.ne("")
    print(f"           {int(target.sum()):,} blank row(s) with Mode = "
          f"{CNIC_OC_MODE}")

    if target.any():
        if not os.path.exists(CNIC_OC_FILE):
            print(f"           {CNIC_OC_FILE} NOT FOUND - skipped.")
        else:
            sub, hdr = _read_sheet_with_header_scan(
                CNIC_OC_FILE, 0, CNIC_OC_SOURCE_COL,
                RDA_HBL_HEADER_SCAN_ROWS)
            if sub is None:
                print(f"           no '{CNIC_OC_SOURCE_COL}' header found "
                      f"in first {RDA_HBL_HEADER_SCAN_ROWS} rows.")
            elif CNIC_OC_KEY_COL not in sub.columns:
                print(f"           {CNIC_OC_FILE} has no "
                      f"'{CNIC_OC_KEY_COL}' column; found "
                      f"{list(sub.columns)[:8]}")
            else:
                lut = {}
                for k, v in zip(sub[CNIC_OC_KEY_COL].pipe(_mu, _norm_ref),
                                sub[CNIC_OC_SOURCE_COL]):
                    val = re.sub(r"[-\s\u00a0]", "", _s(v))
                    if k and val:
                        lut.setdefault(k, val)
                found = urn.where(target).map(lut)
                got = found.notna() & target
                df.loc[got, CNIC_COL] = found[got]
                print(f"           header row {hdr + 1}, {len(lut):,} key(s), "
                      f"{int(got.sum()):,} filled")

    # ── 4. Backfill B: Channel == FM, from the FM source ────────
    print(f"         CNIC: [3/4] FM backfill (Channel == "
          f"{CNIC_FM_CHANNEL})...")
    blank = df[CNIC_COL].pipe(_ev)
    chan_ok = (df["Channel"].pipe(_sv).eq(CNIC_FM_CHANNEL)
               if "Channel" in df.columns
               else pd.Series(False, index=df.index))
    # Mode == OC applies to the whole CNIC exercise, not just the 7122
    # step. Today this is a no-op (Naration line 3 is only populated on
    # FM's 43 OC rows anyway) but it stops AC values leaking in if that
    # ever changes.
    mode_ok_fm = (df["Mode"].pipe(_sv).str.upper().str.strip()
                  .eq(CNIC_OC_MODE.upper()) if "Mode" in df.columns
                  else pd.Series(False, index=df.index))
    target = blank & chan_ok & mode_ok_fm & urn.ne("")
    print(f"           {int(target.sum()):,} blank FM row(s) with Mode = "
          f"{CNIC_OC_MODE}")

    if target.any():
        if not FM_FILE or not os.path.exists(FM_FILE):
            print(f"           FM source ({FM_FILE}) NOT FOUND - skipped.")
        else:
            try:
                fm = read_excel_fast(FM_FILE, "FM (for CNIC)")
            except Exception as e:
                fm = None
                print(f"           could not read {FM_FILE} ({e})")

            if fm is not None:
                miss = [c for c in (CNIC_FM_KEY_COL, CNIC_FM_SOURCE_COL)
                        if c not in fm.columns]
                if miss:
                    print(f"           {FM_FILE} missing {miss}; found "
                          f"{list(fm.columns)[:8]}")
                else:
                    lut = {}
                    for k, v in zip(fm[CNIC_FM_KEY_COL].pipe(_mu, _norm_ref),
                                    fm[CNIC_FM_SOURCE_COL]):
                        val = re.sub(r"[-\s\u00a0]", "", _s(v))
                        if k and val:
                            lut.setdefault(k, val)
                    found = urn.where(target).map(lut)
                    got = found.notna() & target
                    df.loc[got, CNIC_COL] = found[got]
                    print(f"           {len(lut):,} key(s), "
                          f"{int(got.sum()):,} filled")

    # ── 5. Re-validate everything the lookups brought in ────────
    df = _cnic_clean_step(df, "[4/4] final validation")

    filled = int(df[CNIC_COL].pipe(_sv).ne("").sum())
    print(f"         CNIC: {filled:,} valid of {len(df):,} row(s) "
          f"({len(df) - filled:,} blank)")
    return df


def _ac_normalise(val):
    """Strip spaces and hyphens for length measurement. PK is kept."""
    return re.sub(AC_STRIP_FOR_LENGTH, "", _s(val))


def _ac_cnic_valid(val):
    """Passport (leading P) passes verbatim; otherwise 13 digits."""
    s = re.sub(r"[-\s\u00a0]", "", _s(val))
    if not s:
        return None
    if s[:1].upper() == AC_PASSPORT_PREFIX.upper():
        return s
    return s if re.fullmatch(r"\d{13}", s) else None


def _rule_account_cnic(df):
    """Mode == AC: enforce Account No length, then resolve CNIC-A/C."""
    if AC_CNIC_COL not in df.columns:
        df[AC_CNIC_COL] = None

    if "Account No" not in df.columns:
        print("         AC: no 'Account No' column - step skipped.")
        return df

    is_ac = (df["Mode"].pipe(_sv).str.upper().str.strip().eq(AC_MODE.upper())
             if "Mode" in df.columns else pd.Series(False, index=df.index))
    n_ac = int(is_ac.sum())
    if n_ac == 0:
        print(f"         AC: no rows with Mode = {AC_MODE}.")
        return df
    print(f"         AC: {n_ac:,} row(s) with Mode = {AC_MODE}")

    # ── 1-2. length rule ────────────────────────────────────────
    acct = df["Account No"].pipe(_mu, _ac_normalise)
    length = acct.str.len()

    was_blank = is_ac & acct.eq("")
    is_24 = is_ac & length.eq(24)
    is_14 = is_ac & length.eq(14)
    bad = is_ac & ~acct.eq("") & ~length.isin(AC_VALID_LENGTHS)

    df.loc[is_24, "Account No"] = acct[is_24].str[-AC_KEEP_RIGHT:]
    df.loc[is_14, "Account No"] = acct[is_14]
    df.loc[bad, "Account No"] = None

    print(f"           length 14 kept            : {int(is_14.sum()):,}")
    print(f"           length 24 -> right {AC_KEEP_RIGHT}      : "
          f"{int(is_24.sum()):,}")
    print(f"           other length -> BLANKED   : {int(bad.sum()):,}")
    if int(was_blank.sum()):
        print(f"           already blank             : "
              f"{int(was_blank.sum()):,}")
    print(f"           -> {int(bad.sum()) + int(was_blank.sum()):,} row(s) "
          f"need a manual Account No")

    # ── 3-4. DL1534 lookup ──────────────────────────────────────
    have_acct = is_ac & df["Account No"].pipe(_sv).ne("")
    print(f"         AC: [2/3] {AC_CNIC_FILE} lookup "
          f"({int(have_acct.sum()):,} row(s) with a valid account)...")

    if not have_acct.any():
        pass
    elif not AC_CNIC_FILE or not os.path.exists(AC_CNIC_FILE):
        print(f"           {AC_CNIC_FILE} NOT FOUND - lookup skipped.")
    else:
        sub, hdr = _read_sheet_with_header_scan(
            AC_CNIC_FILE, 0, AC_CNIC_SOURCE_COL, RDA_HBL_HEADER_SCAN_ROWS)
        if sub is None:
            print(f"           no '{AC_CNIC_SOURCE_COL}' header found in "
                  f"the first {RDA_HBL_HEADER_SCAN_ROWS} rows.")
        if sub is not None:
            _want = {_norm_header(c): c for c in
                     (AC_CNIC_KEY_COL, AC_CNIC_SOURCE_COL, AC_ACCT_TYPE_COL)}
            sub = sub.rename(columns={c: _want[_norm_header(c)]
                                      for c in sub.columns
                                      if _norm_header(c) in _want
                                      and c not in _want.values()})
        if sub is None:
            pass
        elif AC_CNIC_KEY_COL not in sub.columns:
            print(f"           {AC_CNIC_FILE} has no '{AC_CNIC_KEY_COL}'; "
                  f"found {list(sub.columns)[:8]}")
        else:
            lut = {}
            type_lut = {}
            raw_n = kept_n = 0
            _types = (sub[AC_ACCT_TYPE_COL]
                      if AC_ACCT_TYPE_COL in sub.columns
                      else pd.Series([None] * len(sub), index=sub.index))
            if AC_ACCT_TYPE_COL not in sub.columns:
                print(f"           WARNING: no '{AC_ACCT_TYPE_COL}' column in "
                      f"{AC_CNIC_FILE} - {ACCT_TYPE_COL} left blank")
            for k, v, t in zip(sub[AC_CNIC_KEY_COL].pipe(_mu, _ac_normalise),
                               sub[AC_CNIC_SOURCE_COL], _types):
                if not k:
                    continue
                raw_n += 1
                if _s(t):
                    type_lut.setdefault(k, _s(t))
                ok = _ac_cnic_valid(v)
                if ok:
                    kept_n += 1
                    lut.setdefault(k, ok)

            key = df["Account No"].pipe(_mu, _ac_normalise)
            found = key.where(have_acct).map(lut)
            got = found.notna() & have_acct
            df.loc[got, AC_CNIC_COL] = found[got]

            if ACCT_TYPE_COL not in df.columns:
                df[ACCT_TYPE_COL] = None
            t_found = key.where(have_acct).map(type_lut)
            t_got = t_found.notna() & have_acct
            df.loc[t_got, ACCT_TYPE_COL] = t_found[t_got]
            if type_lut:
                print(f"           {ACCT_TYPE_COL}: {int(t_got.sum()):,} "
                      f"resolved, {len(set(type_lut.values())):,} distinct "
                      f"type(s) in {AC_CNIC_FILE}")

            n_pass = int(found[got].astype(str).str[:1].str.upper()
                         .eq(AC_PASSPORT_PREFIX.upper()).sum())
            print(f"           header row {hdr + 1}, {raw_n:,} record(s), "
                  f"{kept_n:,} with a usable identifier")
            print(f"           matched: {int(got.sum()):,} "
                  f"({n_pass:,} passport, "
                  f"{int(got.sum()) - n_pass:,} CNIC)")

    # ── 5. fall back to CNIC NO. ────────────────────────────────
    print(f"         AC: [3/3] filling remaining from CNIC NO. ...")
    if CNIC_COL in df.columns:
        blank = is_ac & df[AC_CNIC_COL].pipe(_ev)
        cand = df[CNIC_COL].where(blank).pipe(_mu, _ac_cnic_valid)
        fill = cand.notna() & blank
        df.loc[fill, AC_CNIC_COL] = cand[fill]
        print(f"           {int(fill.sum()):,} filled from {CNIC_COL}")
    else:
        print(f"           no {CNIC_COL} column - skipped.")

    # ── position the new column right after Account No ──────────
    cols = [c for c in df.columns if c != AC_CNIC_COL]
    if "Account No" in cols:
        cols.insert(cols.index("Account No") + 1, AC_CNIC_COL)
    else:
        cols.append(AC_CNIC_COL)
    df = df[cols]

    still = int((is_ac & df[AC_CNIC_COL].pipe(_ev)).sum())
    print(f"         AC: {int((is_ac & ~df[AC_CNIC_COL].pipe(_ev)).sum()):,}"
          f" resolved, {still:,} still blank (manual intervention)")
    return df


def _comm_name_key(val):
    """Normalise a name for exact matching.

    Uppercase, punctuation removed, internal whitespace collapsed. Exact
    matching on raw text would miss "MUHAMMAD  ALI" vs "Muhammad Ali";
    fuzzy matching would move rows that merely RESEMBLE a listed name,
    which is the more expensive error on a commercial split.
    """
    s = _s(val).upper()
    s = re.sub(r"[^A-Z0-9 ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _resolve_sheet(available, want, aliases, prefixes):
    """Find the sheet for a role among the names a workbook actually has.

    Tried in order: the configured name, each accepted alias, then any
    sheet whose name starts with one of the prefixes. Case and
    whitespace are ignored throughout.

    The prefix fallback exists because the template has already changed
    spelling once (REMI COM -> REME COM) and will likely change again.
    """
    norm = {_norm_header(s): s for s in available}

    for candidate in [want] + list(aliases):
        hit = norm.get(_norm_header(candidate))
        if hit is not None:
            return hit

    for p in prefixes:
        pn = _norm_header(p)
        for key, original in norm.items():
            if key.startswith(pn):
                return original
    return None


# Legal-form words ignored when comparing a transaction name with the
# commercial repository for a NEAR match. Near matches are never applied
# automatically - they are offered for approval.
COMM_LEGAL_TOKENS = {
    "PVT", "PRIVATE", "LTD", "LIMITED", "CO", "COMPANY", "LLC", "LLP", "INC",
    "CORP", "CORPORATION", "SMC", "PLC", "FZE", "FZC", "FZCO", "EST", "WLL",
    "MESSRS", "THE", "AND", "GUARANTEE",
}
# {"remi": {row name key, ...}, "bene": {...}} - near matches the user approved.
COMMERCIAL_APPROVED = {"remi": set(), "bene": set()}
_COMM_CACHE = {}


def _comm_core_key(key):
    """Name key without legal-form words. '' when fewer than two words
    remain - a single common word must never drive a match."""
    k = re.sub(r"^M S ", "", key)
    toks = [t for t in k.split() if t not in COMM_LEGAL_TOKENS]
    return " ".join(toks) if len(toks) >= 2 else ""


def load_commercial_names():
    """Read the commercial repository folder.

    Returns {"remi": {key: listed name}, "bene": {...},
             "remi_core": {core key: listed name}, "bene_core": {...},
             "files": n}

    Every listed name is indexed twice for exact matching: as written
    (case, punctuation and spacing ignored) and after the SAME cleansing
    the transactions go through. That is what makes a repository name
    such as "1/ABC TRADERS." meet its cleansed transaction counterpart.
    """
    out = {"remi": {}, "bene": {}, "remi_core": {}, "bene_core": {}, "files": 0}
    folder = COMMERCIAL_FOLDER
    if not folder or not os.path.isdir(folder):
        print("           WARNING: commercial repository not provided - "
              "name-based commercial checks skipped.")
        return out

    names = sorted(f for f in os.listdir(folder)
                   if f.lower().endswith((".xlsx", ".xlsm", ".xls"))
                   and not f.startswith("~$"))
    stamp = tuple((f, os.path.getmtime(os.path.join(folder, f))) for f in names)
    if _COMM_CACHE.get("stamp") == (folder, stamp):
        return _COMM_CACHE["data"]
    if not names:
        print("           WARNING: commercial repository folder holds no "
              "Excel files.")
        return out

    for fname in names:
        path = os.path.join(folder, fname)
        out["files"] += 1
        try:
            available = pd.ExcelFile(path, engine="calamine").sheet_names
        except Exception as e:
            print(f"           WARNING: {fname}: could not open ({e})")
            continue

        for side, want_sheet, want_col, label, aliases, prefixes in (
                ("remi", COMM_REMI_SHEET, COMM_REMI_COL, "remitter",
                 COMM_REMI_ALIASES, COMM_REMI_PREFIXES),
                ("bene", COMM_BENE_SHEET, COMM_BENE_COL, "beneficiary",
                 COMM_BENE_ALIASES, COMM_BENE_PREFIXES)):
            actual = _resolve_sheet(available, want_sheet, aliases, prefixes)
            if actual is None:
                print(f"           WARNING: {fname}: no {label} sheet "
                      f"(found {available})")
                continue
            sub, hdr = _read_sheet_with_header_scan(
                path, actual, want_col, RDA_HBL_HEADER_SCAN_ROWS)
            if sub is None:
                print(f"           WARNING: {fname} [{actual}]: no "
                      f"'{want_col}' header in the first "
                      f"{RDA_HBL_HEADER_SCAN_ROWS} rows")
                continue
            col = next((c for c in sub.columns
                        if _norm_header(c) == _norm_header(want_col)), None)
            if col is None:
                continue
            n = 0
            for raw in sub[col].pipe(_sv):
                if not raw:
                    continue
                n += 1
                k_raw = _comm_name_key(raw)
                k_clean = _comm_name_key(_clean_single_name(raw))
                for k in (k_raw, k_clean):
                    if k:
                        out[side].setdefault(k, raw)
                        core = _comm_core_key(k)
                        if core:
                            out[side + "_core"].setdefault(core, raw)
            print(f"           {fname} [{actual}]: {n:,} {label} name(s), "
                  f"header row {hdr + 1}")

    print(f"           Commercial repository: {len(out['remi']):,} remitter "
          f"key(s), {len(out['bene']):,} beneficiary key(s) from "
          f"{out['files']} workbook(s)")
    for side, tab in (("remi", SBP_TAB_REME_COMM), ("bene", SBP_TAB_BENE_COMM)):
        if not out[side]:
            print(f"           WARNING: no {side} names loaded - the {tab} "
                  f"tab cannot be filled by name")
    _COMM_CACHE["stamp"] = (folder, stamp)
    _COMM_CACHE["data"] = out
    return out


COMM_ORIG_PREFIX = "_orig "     # internal columns holding pre-cleansing names


def commercial_match(df, side, repo=None):
    """Compare a name column with the repository.

    Returns (exact, near, approved_mask):
      exact     bool Series - listed name matched exactly (either the
                cleansed or the original transaction name)
      near      object Series - the listed name it RESEMBLES once legal
                suffixes are ignored, else None. Never includes exact rows.
      approved  bool Series - near match previously approved by the user
    """
    col = "Remitter Name" if side == "remi" else "Beneficiary Name"
    repo = repo or load_commercial_names()
    false = pd.Series(False, index=df.index)
    none = pd.Series([None] * len(df), index=df.index, dtype=object)
    if col not in df.columns or not repo[side]:
        return false, none, false

    def keyed(c):
        vals = df[c].astype(object)
        uniq = pd.unique(vals.dropna())
        m = {v: _comm_name_key(v) for v in uniq}
        return vals.map(m).fillna("")

    k1 = keyed(col)
    oc = COMM_ORIG_PREFIX + col
    k2 = keyed(oc) if oc in df.columns else k1
    exact_keys = repo[side].keys()
    exact = k1.isin(exact_keys) | k2.isin(exact_keys)

    core_map = repo[side + "_core"]
    def cored(k):
        m = {v: _comm_core_key(v) for v in pd.unique(k)}
        return k.map(m)
    c1, c2 = cored(k1), (cored(k2) if k2 is not k1 else None)
    near = c1.map(core_map)
    if c2 is not None:
        near = near.where(near.notna(), c2.map(core_map))
    near = near.where(~exact, None)
    near = near.where(near.notna(), None)
    approved = near.notna() & k1.isin(COMMERCIAL_APPROVED.get(side, ()))
    return exact, near, approved


def commercial_suggestions(df):
    """Near matches for the user to approve or reject, one line per
    distinct (side, transaction name)."""
    repo = load_commercial_names()
    out = []
    mode = (df["Mode"].pipe(_sv).str.upper().str.strip()
            if "Mode" in df.columns else pd.Series("", index=df.index))
    amt = pd.to_numeric(df["Amount"], errors="coerce") if "Amount" in df.columns \
        else pd.Series(0.0, index=df.index)
    for side, col in (("remi", "Remitter Name"), ("bene", "Beneficiary Name")):
        exact, near, _ = commercial_match(df, side, repo)
        m = near.notna()
        if side == "bene":
            m = m & ~mode.isin({x.upper() for x in SBP_BENE_NAME_EXCLUDE_MODES})
        if not m.any():
            continue
        g = pd.DataFrame({"name": df.loc[m, col].pipe(_sv), "listed": near[m],
                          "amount": amt[m]})
        for (name, listed), part in g.groupby(["name", "listed"], sort=True):
            out.append({"side": side, "name": name, "key": _comm_name_key(name),
                        "listed": listed, "rows": int(len(part)),
                        "amount": float(part["amount"].sum())})
    return out


def _sbp_extract(sbp, mask, tab, sheets, label):
    """Move the masked rows out of SBP Claim onto their own tab."""
    mask = mask & sbp.index.to_series().isin(sbp.index)
    n = int(mask.sum())
    if n:
        sheets[tab] = sbp.loc[mask].copy()
        sbp = sbp.loc[~mask].copy()
    print(f"           {label:24} {n:>8,}   remaining {len(sbp):,}")
    return sbp


SBP_ALWAYS_TABS = [SBP_TAB_NO_CLAIM, SBP_TAB_CM, SBP_TAB_BELOW_200,
                   SBP_TAB_UK_PENSION, SBP_TAB_BENE_COMM, SBP_TAB_REME_COMM,
                   SBP_TAB_RDA]


def _entity_name_norm(v):
    """R.E Name compared without case, punctuation or extra spaces, and
    with LTD read as LIMITED."""
    s = re.sub(r"[^A-Z0-9]+", " ", _s(v).upper()).split()
    return " ".join("LIMITED" if t == "LTD" else t for t in s)


def uk_pension_mask(df):
    """URN starts with G1 and the R.E is Habib Bank Limited London."""
    if "URN" not in df.columns or "R.E Name" not in df.columns:
        return pd.Series(False, index=df.index)
    want = _entity_name_norm(SBP_UK_RE_NAME)
    names = df["R.E Name"].pipe(_mu, _entity_name_norm)
    return (df["URN"].pipe(_sv).str.upper().str.startswith(SBP_UK_URN_PREFIX.upper())
            & names.eq(want))


def _null_frame(columns):
    """A tab that must exist even when empty carries a single 'Null'."""
    return pd.DataFrame([["Null"] + [None] * (len(columns) - 1)],
                        columns=list(columns))


def is_null_frame(frame):
    return (frame is not None and len(frame) == 1
            and str(frame.iloc[0, 0]) == "Null"
            and frame.iloc[0, 1:].isna().all())


def build_sbp_claim(df):
    """Split a copy of TOTAL into the SBP Claim tabs.

    Returns (sbp_claim_df, {tab_name: frame}). df itself - TOTAL - is
    NOT modified. Rules run in order; a row leaves at the first rule
    that catches it.
    """
    sheets = {}
    sbp = df.copy()
    print(f"           {'rule':24} {'moved':>8}   remaining")
    print("           " + "-" * 48)

    # 1. No Claim
    if "Claim / No Claim" in sbp.columns:
        m = sbp["Claim / No Claim"].pipe(_sv).str.upper().str.strip().eq(
            SBP_NO_CLAIM_VALUE.upper())
        sbp = _sbp_extract(sbp, m, SBP_TAB_NO_CLAIM, sheets, "No Claim")

    # 2. Mode == CM
    if "Mode" in sbp.columns:
        m = sbp["Mode"].pipe(_sv).str.upper().str.strip().eq(
            SBP_CM_MODE.upper())
        sbp = _sbp_extract(sbp, m, SBP_TAB_CM, sheets, f"Mode {SBP_CM_MODE}")

    # 3. USD Eqv. < 200
    if "USD Eqv." in sbp.columns:
        v = pd.to_numeric(sbp["USD Eqv."].astype(str)
                          .str.replace(",", "", regex=False).str.strip(),
                          errors="coerce")
        m = v.notna() & (v < SBP_USD_THRESHOLD)
        sbp = _sbp_extract(sbp, m, SBP_TAB_BELOW_200, sheets,
                           f"USD Eqv. < {SBP_USD_THRESHOLD:g}")

    # 4. HBL UK worker pension - before the commercial checks, so a
    #    pension paid by a listed body (e.g. the Department for Work and
    #    Pensions) is never taken as a commercial remittance.
    sbp = _sbp_extract(sbp, uk_pension_mask(sbp), SBP_TAB_UK_PENSION, sheets,
                       "UK pension")

    # 5-6. commercial
    print("           loading commercial repository...")
    repo = load_commercial_names()
    if not COMMERCIAL_ACCT_TYPES:
        print(f"           note: no commercial customer types are marked - "
              f"no {AC_MODE} row is treated as commercial by type")

    mode = (sbp["Mode"].pipe(_sv).str.upper().str.strip()
            if "Mode" in sbp.columns else pd.Series("", index=sbp.index))

    # 4. Bene Comm: AC rows by customer type; other modes by name
    wanted = {str(t).strip().upper() for t in COMMERCIAL_ACCT_TYPES}
    by_type = pd.Series(False, index=sbp.index)
    if wanted and ACCT_TYPE_COL in sbp.columns:
        by_type = (mode.eq(AC_MODE.upper())
                   & sbp[ACCT_TYPE_COL].pipe(_sv).str.upper().str.strip()
                     .isin(wanted))
    exact, _near, approved = commercial_match(sbp, "bene", repo)
    excl = {m.upper() for m in SBP_BENE_NAME_EXCLUDE_MODES}
    by_name = (exact | approved) & ~mode.isin(excl)
    print(f"           (Bene Comm: {int(by_type.sum()):,} by customer type, "
          f"{int((exact & ~mode.isin(excl)).sum()):,} by listed name, "
          f"{int((approved & ~mode.isin(excl)).sum()):,} by approved near match)")
    sbp = _sbp_extract(sbp, by_type | by_name, SBP_TAB_BENE_COMM, sheets,
                       "Bene Comm")

    # 5. Reme Comm - all remaining rows, any mode
    exact, _near, approved = commercial_match(sbp, "remi", repo)
    print(f"           (Reme Comm: {int(exact.sum()):,} by listed name, "
          f"{int(approved.sum()):,} by approved near match)")
    sbp = _sbp_extract(sbp, exact | approved, SBP_TAB_REME_COMM, sheets,
                       "Reme Comm")

    # 7. RDA - keep Non RDA, move the rest
    if RDA_COL in sbp.columns:
        m = ~sbp[RDA_COL].pipe(_sv).str.upper().str.strip().eq(
            SBP_NON_RDA_VALUE.upper())
        sbp = _sbp_extract(sbp, m, SBP_TAB_RDA, sheets, "RDA")

    # Every extraction tab appears in the final file, even when empty.
    for tab in SBP_ALWAYS_TABS:
        if tab not in sheets:
            sheets[tab] = _null_frame(df.columns)
    return sbp, sheets


def _eq_order(df):
    """Row order deciding which rows survive a per-key limit.

    Returned as a list of positional indices. Earliest Open Date first,
    then original order - a stable sort, so equal dates keep their
    original sequence. With EQ_ORDER_BY == "amount", largest first.
    """
    tmp = pd.DataFrame(index=df.index)
    tmp["_pos"] = range(len(df))

    if EQ_ORDER_BY == "amount" and "Amount" in df.columns:
        amt = pd.to_numeric(
            df["Amount"].astype(str).str.replace(",", "", regex=False)
            .str.strip(), errors="coerce").fillna(-1)
        tmp["_k"] = -amt                      # negate for descending
    elif "Open Date" in df.columns:
        d = pd.to_datetime(df["Open Date"], format="%d/%m/%Y",
                           errors="coerce")
        # Unparseable dates sort last rather than first, so a bad date
        # never displaces a good row from the surviving set.
        tmp["_k"] = d.fillna(pd.Timestamp.max)
    else:
        tmp["_k"] = 0

    return tmp.sort_values(["_k", "_pos"], kind="stable").index


SPLIT_MAX5_SHEET = "MAX 5 SPLIT"


def apply_equations(df):
    """Mark EQ-1..EQ-6 and split the over-limit rows out.

    Returns (kept_df, split_df_or_None). Both carry all six markers and
    a 'Split Reason' naming the equation that removed the row.
    """
    work = df.copy()
    for col, _, _ in EQUATIONS:
        work[col] = None
    work[SPLIT_REASON_COL] = None

    live = pd.Series(True, index=work.index)
    order = _eq_order(work)

    print(f"           {'equation':10} {'limit':>6} "
          f"{'TRUE':>8} {'FALSE':>8} {'blank':>8}   remaining")
    print("           " + "-" * 58)

    for col, key_col, limit in EQUATIONS:
        if key_col not in work.columns:
            print(f"           {col:10} key column missing - skipped")
            continue

        keys = work[key_col].pipe(_sv)
        # A blank key is not comparable: never marked, never moved.
        usable = live & keys.ne("")

        k = keys.reindex(order)
        k = k[usable.reindex(order).values]
        rank = k.groupby(k, sort=False).cumcount() + 1
        over = pd.Series(False, index=work.index)
        over.loc[rank.index[rank.values > limit]] = True
        under = usable & ~over

        work.loc[under, col] = EQ_FALSE
        work.loc[over, col] = EQ_TRUE
        newly = over & work[SPLIT_REASON_COL].isna()
        work.loc[newly, SPLIT_REASON_COL] = col
        live = live & ~over

        print(f"           {col:10} {limit:>6} "
              f"{int(over.sum()):>8,} {int(under.sum()):>8,} "
              f"{int((live & keys.eq('')).sum()):>8,}   "
              f"{int(live.sum()):,}")

    split = work.loc[~live].copy() if (~live).any() else None
    kept = work.loc[live].copy()
    return kept, split


def collect_acct_types(df):
    """Distinct Acct Type values present on AC rows of THIS dataset.

    Deliberately not "every type in DL1534" - the reference file lists
    types that never occur in a given month, and asking about those is
    noise. Only what actually landed in the data is worth marking.
    """
    if ACCT_TYPE_COL not in df.columns or "Mode" not in df.columns:
        return []
    is_ac = df["Mode"].pipe(_sv).str.upper().str.strip().eq(AC_MODE.upper())
    vals = {v for v in df.loc[is_ac, ACCT_TYPE_COL].pipe(_sv) if v}
    return sorted(vals)


def build_sbp_and_equations(df):
    """TOTAL -> SBP Claim -> extraction tabs -> equations -> split tabs.

    Returns {sheet_name: frame}; df (TOTAL) is not modified.
      SPLIT        rows beyond 1 per key per day      (EQ-1..EQ-3)
      MAX 5 SPLIT  rows beyond 5 per key in the month (EQ-4..EQ-6)
    """
    print(f"         Building {SBP_SHEET} from {TOTAL_SHEET} "
          f"({len(df):,} rows)...")
    sheets = {}
    sbp, sbp_sheets = build_sbp_claim(df)
    sheets.update(sbp_sheets)

    print(f"         Applying equations...")
    sbp, split = apply_equations(sbp)
    sheets[SBP_SHEET] = sbp

    max5_eq = {c for c, _, lim in EQUATIONS if lim > 1}
    if split is not None and len(split):
        is5 = split[SPLIT_REASON_COL].isin(max5_eq)
        day, mon = split.loc[~is5], split.loc[is5]
    else:
        day = mon = None
    cols = list(sbp.columns)
    sheets[SPLIT_SHEET] = day if day is not None and len(day) else _null_frame(cols)
    sheets[SPLIT_MAX5_SHEET] = mon if mon is not None and len(mon) else _null_frame(cols)

    n_day = 0 if day is None else len(day)
    n_mon = 0 if mon is None else len(mon)
    print(f"         {SBP_SHEET}: {len(sbp):,} eligible  |  "
          f"{SPLIT_SHEET}: {n_day:,}  |  {SPLIT_MAX5_SHEET}: {n_mon:,}")
    return sheets


def apply_business_rules(df):
    """Run all post-vlookup rules.

    Returns (main_df, extra_sheets) where extra_sheets is a dict of
    {worksheet_name: DataFrame} to write as additional tabs.
    """
    start = time.time()
    print("\n" + "=" * 60)
    print("  HBL PRI - Step 4: Business Rules")
    print(f"  Processing {len(df):,} rows")
    print("=" * 60 + "\n")

    extra_sheets = {}

    # Runs BEFORE the splits so ORRE / Cancelled rows carry the values.
    print("  [0] USD conversion...")
    df = _apply_usd_conversion(df)

    # Before the splits, so ORRE / Cancelled rows carry their CNIC.
    print("  [0b] CNIC validation and backfill...")
    df = _rule_cnic(df)

    # Runs BEFORE the rebuild below: it blanks or truncates Account No,
    # which feeds "Account No / CNIC" and "Remitter ID + Bene ID".
    print("  [0b2] Account No length rule and CNIC-A/C lookup...")
    df = _rule_account_cnic(df)

    # MUST run after _rule_cnic: cleanse() built this column before the
    # backfill existed, so every OC row would otherwise carry the stale
    # (usually blank) CNIC.
    print("  [0c] Rebuilding derived columns with final CNIC...")
    df = generate_derived_columns(df)
    if ACCOUNT_CNIC_COL in df.columns:
        _n_cnic = int(df[ACCOUNT_CNIC_COL].pipe(_sv)
                      .str.startswith(ACCOUNT_CNIC_PREFIX).sum())
        _n_acct = int(df[ACCOUNT_CNIC_COL].pipe(_sv)
                      .str.startswith(ACCOUNT_ACCT_PREFIX).sum())
        _n_blank = int(df[ACCOUNT_CNIC_COL].pipe(_ev).sum())
        print(f"         {ACCOUNT_CNIC_COL}: {_n_cnic:,} CNIC form, "
              f"{_n_acct:,} A/C form, {_n_blank:,} blank")

    _rules = {
        "orre": ("ORRE split and relabel", _rule_orre, ORRE_SHEET_NAME),
        "cancelled": ("Cancelled split", _rule_cancelled,
                      CANCELLED_SHEET_NAME),
    }
    _total = len(RULE_ORDER)
    for _i, _key in enumerate(RULE_ORDER, start=1):
        if _key not in _rules:
            print(f"  WARNING: unknown rule '{_key}' in RULE_ORDER, skipped.")
            continue
        _label, _fn, _sheet = _rules[_key]
        print(f"  [{_i}/{_total}] {_label}...")
        df, _out = _fn(df)
        if _out is not None and len(_out):
            extra_sheets[_sheet] = _out

    # RDA runs AFTER the splits: leftover RDA-Other rows are double-checked
    # against the ORRE and Cancelled frames, which must already exist.
    # Classification applies to the MAIN SHEET only.
    print(f"  [{_total + 1}] RDA classification...")
    df, _rda_unmatched = _rule_rda(df, extra_sheets)
    if _rda_unmatched is not None and len(_rda_unmatched):
        extra_sheets[RDA_OTHER_UNMATCH_SHEET] = _rda_unmatched

    print(f"  [{_total + 2}] Account pattern review...")
    df = _rule_account_review(df)

    # First pass. Several components are filled in by hand later, so
    # pipeline_runner rebuilds these after corrections are merged.
    print(f"  [{_total + 3}] Building match keys...")
    df = build_match_keys(df)

    # SBP Claim and the equations are NOT built here. They run at
    # finalisation instead, once the blanks have been corrected and the
    # commercial account types marked - so they see real values rather
    # than a first pass. See build_sbp_and_equations().
    print(f"  [{_total + 4}] {TOTAL_SHEET} ready: {len(df):,} row(s)")
    _types = collect_acct_types(df)
    if _types:
        print(f"         {len(_types)} distinct {ACCT_TYPE_COL} value(s) "
              f"on {AC_MODE} rows: {', '.join(_types[:8])}"
              f"{'...' if len(_types) > 8 else ''}")
    print(f"         {SBP_SHEET} is built at finalisation, after "
          f"corrections.")
    # (SBP Claim summary now printed by build_sbp_and_equations at
    # finalisation - the old line here referenced variables that no
    # longer exist in this scope.)

    print(f"\n  RULES COMPLETE - {len(df):,} rows remain in main sheet "
          f"in {time.time() - start:.1f}s\n")
    return df, extra_sheets


def recompute_after_mode_change(df, mask):
    """Re-derive everything that depends on Mode for the masked rows.

    Used when the reviewer amends a transaction mode: the CNIC backfill,
    the account rule, the DL1534 lookup and the derived columns are all
    mode-specific, so they are run again for just those rows.
    """
    if not mask.any():
        return df
    sub = df.loc[mask].copy()
    mode = sub["Mode"].pipe(_sv).str.upper().str.strip()

    rh_ib = sub["Channel"].pipe(_sv).eq("RH") & mode.eq("IB")
    if rh_ib.any() and "Payment Date" in sub.columns:
        sub.loc[rh_ib, "Payment Date"] = sub.loc[rh_ib, "Upload Date"]

    sub = _rule_cnic(sub)
    not_ac = ~mode.eq(AC_MODE.upper())
    for c in (AC_CNIC_COL, ACCT_TYPE_COL):
        if c in sub.columns:
            sub.loc[not_ac, c] = None
    if (~not_ac).any():
        sub = _rule_account_cnic(sub)
    sub = generate_derived_columns(sub)
    sub = _rule_account_review(sub)
    for c in df.columns:
        if c in sub.columns:
            df.loc[mask, c] = sub[c]
    return df


# ---- reviewed names: decisions kept across runs (data/names.json) ----
NAME_OVERRIDES = {}     # original name key -> name to use
NAME_VARIANTS = {}      # cleansed name -> canonical spelling


def name_key(v):
    """How an original name is recognised again: case and spacing ignored."""
    return re.sub(r"\s+", " ", _s(v).upper()).strip()


def apply_name_dictionary(orig, rule):
    """Name to use for each row: the reviewed name for that original if
    there is one, otherwise the rule result; then the approved spelling."""
    out = rule.astype(object).copy()
    if NAME_OVERRIDES:
        hit = orig.pipe(_mu, lambda v: NAME_OVERRIDES.get(name_key(v)) if _s(v) else None)
        m = hit.notna()
        out[m] = hit[m]
    if NAME_VARIANTS:
        hit = out.pipe(_mu, lambda v: NAME_VARIANTS.get(_s(v)) if _s(v) else None)
        m = hit.notna()
        out[m] = hit[m]
    return out


def name_skeleton(name):
    """Rough sound-alike form, used only to FIND possible spelling variants
    for review (never to change a name). Spaces, vowels and doubled
    letters are ignored, and the common spellings of Muhammad agree."""
    s = re.sub(r"[^A-Z]", "", _s(name).upper())
    s = re.sub(r"M[OU]HA?M+[AE]D|MOHD|MUHD", "MHMD", s)
    if not s:
        return ""
    s = s.replace("PH", "F").replace("Q", "K").replace("CK", "K")
    s = s[0] + re.sub(r"[AEIOUY]", "", s[1:])
    return re.sub(r"(.)\1+", r"\1", s)


def ai_name_valid(original, suggestion):
    """An AI-cleaned name is accepted only if it was made by deleting
    junk and/or splitting joined words: every word must appear, in order,
    inside the original's letters. Spelling can never change."""
    src = re.sub(r"&", "AND", _s(original).upper())
    src = re.sub(r"[^A-Z0-9]", "", src)
    words = re.sub(r"[^A-Z0-9 ]", " ", _s(suggestion).upper()).split()
    if not words:
        return False
    pos = 0
    for w in words:
        i = src.find(w, pos)
        if i < 0:
            return False
        pos = i + len(w)
    return True


