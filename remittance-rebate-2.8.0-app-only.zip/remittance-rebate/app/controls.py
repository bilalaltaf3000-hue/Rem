"""
Control checks and audit trail for the final report.

Every check is recomputed independently from the finished sheets - it
does not reuse the masks or counters the processing steps produced - so
a defect in a rule shows up here instead of being silently repeated.

run_checks() returns (checks, control_summary_frame, audit_trail_frame).
A check is {"id", "check", "status", "detail"}; status is PASS, FAIL,
WARN or INFO. FAIL means the report should not be relied on until the
difference is explained.
"""
import datetime

import pandas as pd

import engine

_s = engine._s


def _amount(frame):
    if frame is None or "Amount" not in frame.columns or engine.is_null_frame(frame):
        return 0.0
    return float(pd.to_numeric(frame["Amount"], errors="coerce").sum())


def _rows(frame):
    if frame is None or engine.is_null_frame(frame):
        return 0
    return int(len(frame))


def _ids(frame):
    if frame is None or engine.is_null_frame(frame) or "Row ID" not in frame.columns:
        return pd.Series([], dtype=object)
    return frame["Row ID"]


def run_checks(run, book):
    checks = []

    def add(cid, check, ok, detail, warn_only=False, info=False):
        status = "INFO" if info else ("PASS" if ok else ("WARN" if warn_only else "FAIL"))
        checks.append({"id": cid, "check": check, "status": status, "detail": detail})

    total = book[engine.TOTAL_SHEET]
    sbp = book[engine.SBP_SHEET]
    orre = book.get(engine.ORRE_SHEET_NAME)
    canc = book.get(engine.CANCELLED_SHEET_NAME)
    tabs = engine.SBP_ALWAYS_TABS + [engine.SPLIT_SHEET, engine.SPLIT_MAX5_SHEET]
    st = run.stats

    # C01 completeness: nothing lost or duplicated between sources and tabs
    n_in = st.get("consolidated_rows", 0)
    n_out = _rows(total) + _rows(orre) + _rows(canc)
    add("C01", "Consolidated transactions = TOTAL + ORRE + Cancelled (count)", n_in == n_out,
        "consolidated %s; TOTAL %s + ORRE %s + Cancelled %s = %s"
        % (f"{n_in:,}", f"{_rows(total):,}", f"{_rows(orre):,}", f"{_rows(canc):,}", f"{n_out:,}"))
    a_in = st.get("consolidated_amount", 0.0)
    a_out = _amount(total) + _amount(orre) + _amount(canc)
    add("C02", "Consolidated transactions = TOTAL + ORRE + Cancelled (amount)",
        abs(a_in - a_out) < 0.01 * max(1, n_in) ** 0.5,
        "consolidated %s; tabs %s; difference %s" % (f"{a_in:,.2f}", f"{a_out:,.2f}", f"{a_in - a_out:,.2f}"))
    allid = pd.concat([_ids(total), _ids(orre), _ids(canc)], ignore_index=True)
    dup = int(allid.duplicated().sum())
    add("C03", "Every transaction has one unique Row ID", dup == 0 and bool(allid.pipe(engine._sv).ne("").all()),
        "%s Row IDs, %s duplicated" % (f"{len(allid):,}", f"{dup:,}"))

    # C04-C06 TOTAL is fully and exclusively distributed
    n_parts = _rows(sbp) + sum(_rows(book.get(t)) for t in tabs)
    add("C04", "TOTAL = SBP Claim + extraction tabs + split tabs (count)", n_parts == _rows(total),
        "TOTAL %s; SBP Claim %s + %s = %s" % (
            f"{_rows(total):,}", f"{_rows(sbp):,}",
            " + ".join("%s %s" % (t, f"{_rows(book.get(t)):,}") for t in tabs), f"{n_parts:,}"))
    a_parts = _amount(sbp) + sum(_amount(book.get(t)) for t in tabs)
    add("C05", "TOTAL = SBP Claim + extraction tabs + split tabs (amount)",
        abs(a_parts - _amount(total)) < 0.01 * max(1, _rows(total)) ** 0.5,
        "TOTAL %s; tabs %s; difference %s" % (
            f"{_amount(total):,.2f}", f"{a_parts:,.2f}", f"{_amount(total) - a_parts:,.2f}"))
    spread = pd.concat([_ids(sbp)] + [_ids(book.get(t)) for t in tabs], ignore_index=True)
    twice = int(spread.duplicated().sum())
    missing = int((~_ids(total).isin(set(spread))).sum())
    add("C06", "No transaction appears on two tabs, none is missing", twice == 0 and missing == 0,
        "%s on more than one tab, %s on no tab" % (f"{twice:,}", f"{missing:,}"))

    # C07-C10 nothing ineligible is left in SBP Claim
    if len(sbp):
        mode = sbp["Mode"].pipe(engine._sv).str.upper().str.strip()
        n = int(sbp["Claim / No Claim"].pipe(engine._sv).str.upper().str.strip().eq(
            engine.SBP_NO_CLAIM_VALUE.upper()).sum())
        add("C07", "SBP Claim holds no 'NO CLAIM' entity", n == 0, "%s found" % f"{n:,}")
        n = int(mode.eq(engine.SBP_CM_MODE).sum())
        add("C08", "SBP Claim holds no Mode CM transaction", n == 0, "%s found" % f"{n:,}")
        usd = pd.to_numeric(sbp["USD Eqv."], errors="coerce")
        n = int((usd < engine.SBP_USD_THRESHOLD).sum())
        add("C09", "SBP Claim holds no transaction below US$%g" % engine.SBP_USD_THRESHOLD,
            n == 0, "%s found; %s with no USD equivalent" % (f"{n:,}", f"{int(usd.isna().sum()):,}"))
        n = int((~sbp[engine.RDA_COL].pipe(engine._sv).str.upper().str.strip().eq(
            engine.SBP_NON_RDA_VALUE.upper())).sum())
        add("C10", "SBP Claim holds only Non RDA transactions", n == 0, "%s found" % f"{n:,}")
        wanted = {str(t).upper() for t in engine.COMMERCIAL_ACCT_TYPES}
        n = int((mode.eq("AC") & sbp[engine.ACCT_TYPE_COL].pipe(engine._sv).str.upper().isin(wanted)).sum()) \
            if wanted and engine.ACCT_TYPE_COL in sbp.columns else 0
        add("C11", "SBP Claim holds no commercial customer type", n == 0,
            "%s found; types marked commercial: %s" % (f"{n:,}", ", ".join(sorted(wanted)) or "none"))
        repo = engine.load_commercial_names()
        ex_r, _n, ap_r = engine.commercial_match(sbp, "remi", repo)
        ex_b, _n, ap_b = engine.commercial_match(sbp, "bene", repo)
        excl = {m.upper() for m in engine.SBP_BENE_NAME_EXCLUDE_MODES}
        n_r = int((ex_r | ap_r).sum())
        n_b = int(((ex_b | ap_b) & ~mode.isin(excl)).sum())
        add("C12", "SBP Claim holds no listed commercial remitter or beneficiary",
            n_r == 0 and n_b == 0, "%s remitter, %s beneficiary name(s) found" % (f"{n_r:,}", f"{n_b:,}"))
        n_repo = len(repo["remi"]) + len(repo["bene"])
        add("C13", "Commercial names repository was loaded", n_repo > 0,
            "%s remitter and %s beneficiary name key(s) from %s workbook(s)"
            % (f"{len(repo['remi']):,}", f"{len(repo['bene']):,}", repo["files"]), warn_only=True)

        # C14 equations: no key over its limit, recounted from scratch
        worst = []
        for col, key_col, limit in engine.EQUATIONS:
            if key_col not in sbp.columns:
                continue
            k = sbp[key_col].pipe(engine._sv)
            vc = k[k.ne("")].value_counts()
            over = int((vc > limit).sum())
            if over:
                worst.append("%s: %s key(s) over %d" % (col, f"{over:,}", limit))
        add("C14", "SBP Claim respects every equation limit (1 per day, 5 per month)",
            not worst, "; ".join(worst) or "no key exceeds its limit")

    # C22 HBL UK worker pension: where did every G1 / HBL London row go?
    where = {}
    for name in [engine.SBP_SHEET] + tabs:
        f = book.get(name)
        if f is None or engine.is_null_frame(f) or not len(f):
            continue
        n = int(engine.uk_pension_mask(f).sum())
        if n:
            where[name] = n
    n_tab = where.pop(engine.SBP_TAB_UK_PENSION, 0)
    add("C22", "Every G1 transaction from %s is on the %s tab"
        % (engine.SBP_UK_RE_NAME, engine.SBP_TAB_UK_PENSION), not where,
        "%s on the tab%s" % (f"{n_tab:,}", "; elsewhere: " + ", ".join(
            "%s %s" % (k, f"{v:,}") for k, v in where.items()) if where else ""),
        warn_only=True)
    g1 = total["URN"].pipe(engine._sv).str.upper().str.startswith(engine.SBP_UK_URN_PREFIX)
    other = total.loc[g1 & ~engine.uk_pension_mask(total), "R.E Name"].pipe(engine._sv)
    if len(other):
        vc = other.replace("", "(blank)").value_counts()
        add("C23", "G1 transactions from another R.E (not treated as UK pension)", True,
            ", ".join("%s %s" % (k, f"{v:,}") for k, v in vc.head(8).items()), info=True)

    # C15 cancelled references do not survive in TOTAL
    pat = engine._cancel_pattern()
    n = int(total["Comments"].pipe(engine._sv).str.contains(pat, case=False, regex=True).sum()) \
        if "Comments" in total.columns else 0
    add("C15", "No transaction with a cancellation/refund comment remains in TOTAL", n == 0,
        "%s found (restored by a reviewer, if any)" % f"{n:,}", warn_only=True)

    # C16 USD equivalent recomputed
    rate = run.meta.get("usd_rate")
    try:
        amt = pd.to_numeric(total["Amount"], errors="coerce")
        usd = pd.to_numeric(total["USD Eqv."], errors="coerce")
        diff = ((amt / float(rate)).round(2) - usd).abs()
        n = int((diff > 0.011).sum())
        add("C16", "USD equivalent = Amount / USD rate on every TOTAL row", n == 0,
            "rate %s; %s row(s) differ; %s row(s) have no amount" % (rate, f"{n:,}", f"{int(amt.isna().sum()):,}"))
    except Exception as e:
        add("C16", "USD equivalent = Amount / USD rate on every TOTAL row", False, "could not verify: %s" % e)

    # C17 outstanding values
    counts = run.query_counts("eligible")
    left = {k: v for k, v in counts.items() if v}
    add("C17", "No outstanding values remain on claim-eligible transactions", not left,
        ", ".join("%s %s" % (k, f"{v:,}") for k, v in left.items()) or "none outstanding",
        warn_only=True)
    pend = [s for s in run.suggestion_list() if not s["decision"]]
    add("C18", "Every commercial near match has been decided", not pend,
        "%s awaiting a decision" % len(pend), warn_only=True)

    # C19 reporting period
    d = pd.to_datetime(total["Upload Date"], format="%d/%m/%Y", errors="coerce")
    per = d.dt.to_period("M").value_counts().sort_index()
    add("C19", "Upload dates by month", True,
        ", ".join("%s %s" % (p.strftime("%b %Y"), f"{v:,}") for p, v in per.items())
        + ("; %s without a date" % f"{int(d.isna().sum()):,}" if d.isna().any() else ""), info=True)
    key = total["R.E"].pipe(engine._sv) + "|" + total["URN"].pipe(engine._sv) + "|" + total["Amount"].pipe(engine._sv)
    n = int(key.duplicated(keep=False).sum())
    add("C20", "Transactions sharing the same R.E + URN + Amount in TOTAL", True,
        "%s row(s) - review if unexpected" % f"{n:,}", info=True)
    for ch, c in sorted(st.get("channels", {}).items()):
        add("C21", "Channel %s" % ch, True, "%s transactions, amount %s"
            % (f"{c:,}", f"{st.get('channel_amounts', {}).get(ch, 0):,.2f}"), info=True)

    # ── Control Summary sheet ───────────────────────────────────
    rows = [["RESULT", "", "ALL CONTROLS PASSED" if not any(c["status"] == "FAIL" for c in checks)
             else "%d CONTROL(S) FAILED" % sum(c["status"] == "FAIL" for c in checks), ""]]
    rows += [[c["id"], c["check"], c["status"], c["detail"]] for c in checks]
    rows.append(["", "", "", ""])
    rows.append(["TAB", "Worksheet", "Transactions", "Amount"])
    for name, frame in book.items():
        if "Row ID" in getattr(frame, "columns", []):
            rows.append(["TAB", name, f"{_rows(frame):,}", f"{_amount(frame):,.2f}"])
    summary = pd.DataFrame(rows, columns=["Ref", "Check", "Status", "Detail"])

    # ── Audit Trail sheet ───────────────────────────────────────
    a = []

    def item(section, name, value="", by="", at="", extra=""):
        a.append([section, name, value, by, at, extra])

    m = run.meta
    item("Run", "Run name", m.get("name"))
    item("Run", "Run reference", m.get("id"))
    item("Run", "Created", "", m.get("created_by"), m.get("created_at"))
    item("Run", "Processed", "", "", m.get("processed_at"))
    item("Run", "Report generated", "", "", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    item("Run", "Application version", m.get("version"))
    item("Run", "USD rate", m.get("usd_rate"))
    item("Run", "Reporting period", m.get("period"))
    item("Run", "Reviewed names in use", "%s name decision(s), %s spelling merge(s)"
         % (f"{len(engine.NAME_OVERRIDES):,}", f"{len(engine.NAME_VARIANTS):,}"))
    item("Run", "Commercial customer types", ", ".join(m.get("cust_types") or []) or "(none marked)")
    for slot, files in (m.get("files") or {}).items():
        for name, info in files.items():
            item("Input file", "%s: %s" % (slot, name), "%s bytes" % f"{info.get('size', 0):,}",
                 info.get("by"), info.get("at"), "SHA-256 " + info.get("sha256", ""))
    for d in m.get("decision_log") or []:
        item("Commercial near match", "%s: %s" % ("Remitter" if d["side"] == "remi" else "Beneficiary",
                                                  d["key"]), d["decision"], d["user"], d["at"])
    for e in run.journal:
        if e["action"] == "names":
            label = {"name": "Name reviewed", "variant": "Spelling merged",
                     "reject": "Not the same person"}.get(e.get("kind"), "Name")
            item("Manual change", "%s  %s" % (label, e.get("key", "")),
                 "-> '%s'%s" % (e.get("new") or "(undone)",
                                "; %s row(s)" % f"{e['rows']:,}" if e.get("rows") else ""),
                 e.get("user"), e.get("at"), e.get("source") or "")
            continue
        label = {"set": "Value entered", "mode": "Mode amended", "cancel": "Marked cancelled",
                 "restore": "Restored from Cancelled"}.get(e["action"], e["action"])
        item("Manual change", "%s  %s  URN %s" % (label, e["row_id"], e.get("urn", "")),
             "%s: '%s' -> '%s'" % (e.get("column") or "tab", e.get("old", ""), e.get("new", "")),
             e.get("user"), e.get("at"), (e.get("source") or "") + (
                 " - " + e["note"] if e.get("note") else ""))
    if not run.journal:
        item("Manual change", "(none)")
    for t in m.get("timings") or []:
        item("Timing", t["stage"], "%.1f s" % t["seconds"])
    audit = pd.DataFrame(a, columns=["Section", "Item", "Value", "By", "At", "Detail"])
    return checks, summary, audit
