"""
Optional AI assistance through the bank's own vLLM server
(OpenAI-compatible API, e.g. http://127.0.0.1:8001/v1).

The model is ADVISORY ONLY. It never reads or writes the dataset and no
figure in any report depends on it: it gives an opinion on commercial
near matches (a person still approves or rejects each one) and explains
log warnings in plain language. If the server is down or slow, every
function here fails quietly and the application carries on without it.
"""
import json
import re
import urllib.error
import urllib.request

TIMEOUT_STATUS = 3
TIMEOUT_CHAT = 120
_model_cache = {}


def _get(url, timeout):
    with urllib.request.urlopen(urllib.request.Request(url), timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def status(settings):
    """{'available': bool, 'model': str, 'detail': str}"""
    base = (settings.get("llm_url") or "").rstrip("/")
    if not base:
        return {"available": False, "model": "", "detail": "AI assistance is not configured."}
    try:
        data = _get(base + "/models", TIMEOUT_STATUS)
        ids = [m.get("id") for m in data.get("data", []) if m.get("id")]
        model = settings.get("llm_model") or (ids[0] if ids else "")
        if not model:
            return {"available": False, "model": "", "detail": "The model server lists no model."}
        _model_cache[base] = model
        return {"available": True, "model": model, "detail": ""}
    except Exception as e:
        return {"available": False, "model": "",
                "detail": "Model server not reachable at %s (%s)." % (base, type(e).__name__)}


def chat(settings, system, user, max_tokens=900):
    base = (settings.get("llm_url") or "").rstrip("/")
    model = settings.get("llm_model") or _model_cache.get(base)
    if not model:
        st = status(settings)
        if not st["available"]:
            raise RuntimeError(st["detail"])
        model = st["model"]
    body = json.dumps({"model": model, "temperature": 0, "max_tokens": max_tokens,
                       "messages": [{"role": "system", "content": system},
                                    {"role": "user", "content": user}]}).encode("utf-8")
    req = urllib.request.Request(base + "/chat/completions", data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_CHAT) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        return data["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        raise RuntimeError("The model server returned an error (%s)." % e.code)
    except Exception as e:
        raise RuntimeError("The model server did not answer (%s)." % type(e).__name__)


NAME_SYSTEM = (
    "You help a bank operations officer decide whether a name seen on a remittance "
    "transaction refers to the same COMMERCIAL entity as a name on the bank's list of "
    "commercial (business) names. Individuals must never be treated as commercial. "
    "Differences in legal suffix (PVT, LTD, LIMITED, CO, SMC), punctuation, spacing or "
    "obvious abbreviation do not make two businesses different. A different trade word, "
    "city or person's name does. Answer ONLY with a JSON array, one object per pair, in "
    'the same order: {"n": <number>, "same": "yes" | "no" | "unsure", "reason": "<max 12 words>"}.')


def review_names(settings, pairs):
    """pairs: [{'name':..., 'listed':...}] -> [{'same':..., 'reason':...}] (same order)."""
    out = []
    for start in range(0, len(pairs), 25):
        block = pairs[start:start + 25]
        prompt = "\n".join('%d. transaction name: "%s"  |  listed commercial name: "%s"'
                           % (i + 1, p["name"], p["listed"]) for i, p in enumerate(block))
        text = chat(settings, NAME_SYSTEM, prompt, max_tokens=60 * len(block) + 100)
        got = {}
        m = re.search(r"\[.*\]", text, flags=re.S)
        try:
            for item in json.loads(m.group(0) if m else text):
                got[int(item.get("n", 0))] = item
        except Exception:
            pass
        for i in range(len(block)):
            item = got.get(i + 1) or {}
            same = str(item.get("same", "unsure")).lower()
            out.append({"same": same if same in ("yes", "no", "unsure") else "unsure",
                        "reason": str(item.get("reason", "no opinion returned"))[:160]})
    return out


LOG_SYSTEM = (
    "You are assisting a bank operations officer who runs a monthly remittance rebate "
    "process: four channel extracts (RH, GRS, FM, RIM/PIM) are consolidated, cleansed, "
    "enriched from reference files (entity list, ITRS, refunds, RDA lists, 7122 CNIC file, "
    "DL1534 account master, commercial names) and split into claim tabs. Below are warning "
    "lines from the processing log. For each distinct issue say, in plain business English: "
    "what it means, whether it can affect the claim figures, and exactly what the officer "
    "should check or fix (usually in one of the uploaded files). Be brief and concrete. "
    "Do not invent causes that the log does not support; say when you are not sure.")


def explain_log(settings, lines):
    text = "\n".join(lines[-80:])
    if not text.strip():
        return "There are no warnings in the log."
    return chat(settings, LOG_SYSTEM, text[:12000], max_tokens=900)
