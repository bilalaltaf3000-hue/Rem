"""
Fast .xlsx writer for large tabular sheets.

xlsxwriter and openpyxl build a workbook cell by cell in Python; at
30-60 million cells that is the slowest part of the whole process. This
writer builds each column's cell XML with array operations and streams
the sheet into the zip in row blocks, so memory stays flat and the cost
per cell is a small fraction of a per-cell call.

What it produces is deliberately plain and standard:
  * one styled, frozen, auto-filtered header row per sheet
  * text as inline strings (no shared-string table to build)
  * real numbers with a number format, real dates as DD/MM/YYYY
  * a sheet longer than Excel's row limit continues on "<name> (2)" ...

write_workbook() is the only entry point. write_workbook_compat() writes
the same content with xlsxwriter and is used automatically if this
writer fails for any reason.
"""
import collections
import datetime as _dt
import re
import zipfile
import zlib

import numpy as np
import pandas as pd

MAX_DATA_ROWS = 1048575          # Excel rows minus the header
BLOCK_ROWS = 40000
HEADER_HEIGHT = 30
MAX_WIDTH = 46

_ILLEGAL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")
_EPOCH = np.datetime64("1899-12-30", "D")
_STR_OPEN = '" t="inlineStr"><is><t>'
_STR_CLOSE = "</t></is></c>"


def _col_letter(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _safe_name(name, used):
    base = re.sub(r"[:\\/?*\[\]]", "_", str(name)).strip("'")[:31] or "Sheet"
    out, n = base, 2
    while out.lower() in used:
        suffix = " (%d)" % n
        out = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(out.lower())
    return out


def _text_cells(vals, null):
    """object array of str ('' where null), XML-safe."""
    probe = "\x00".join(vals.tolist()) if len(vals) else ""
    if _ILLEGAL.search(probe.replace("\x00", "")):
        vals = np.array([_ILLEGAL.sub("", v) for v in vals.tolist()], dtype=object)
    if "&" in probe or "<" in probe or ">" in probe:
        vals = np.array([_esc(v) if ("&" in v or "<" in v or ">" in v) else v
                         for v in vals.tolist()], dtype=object)
    return vals


def _as_text(col):
    """(object array of str, null mask) for any column."""
    arr = col.to_numpy(dtype=object)
    null = pd.isna(arr)
    if null.any():
        arr = arr.copy()
        arr[null] = ""
    if pd.api.types.infer_dtype(arr, skipna=False) != "string":
        arr = np.array([v if isinstance(v, str) else _plain(v) for v in arr.tolist()],
                       dtype=object)
    empty = arr == ""
    return arr, (null | empty)


def _plain(v):
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, (pd.Timestamp, _dt.datetime, _dt.date)):
        return v.strftime("%d/%m/%Y")
    return str(v)


def _plan_column(name, col, number_formats, date_columns, style_of):
    """Decide how a column is written. Returns a dict the block builder
    uses; all per-value conversion happens here, once."""
    if name in number_formats:
        num = pd.to_numeric(col, errors="coerce").to_numpy(dtype="float64")
        ok = np.isfinite(num)
        txt, tnull = _as_text(col)
        as_text = ~ok & ~tnull              # non-numeric leftovers stay visible
        nums = np.where(ok, num, 0.0).astype("U32").astype(object)
        # 150000.0 -> 150000 keeps the file smaller; value is unchanged
        return {"kind": "num", "ok": ok, "nums": nums, "style": style_of(number_formats[name]),
                "text": _text_cells(txt, tnull) if as_text.any() else None, "as_text": as_text}
    if name in date_columns:
        if pd.api.types.is_datetime64_any_dtype(col):
            d = col
        else:
            d = pd.to_datetime(col, format="%d/%m/%Y", errors="coerce")
        ok = d.notna().to_numpy()
        days = ((d.to_numpy().astype("datetime64[D]") - _EPOCH).astype("int64"))
        nums = np.where(ok, days, 0).astype("U12").astype(object)
        txt, tnull = _as_text(col) if not pd.api.types.is_datetime64_any_dtype(col) \
            else (np.full(len(col), "", dtype=object), np.ones(len(col), bool))
        as_text = ~ok & ~tnull
        return {"kind": "num", "ok": ok, "nums": nums, "style": style_of("DD/MM/YYYY"),
                "text": _text_cells(txt, tnull) if as_text.any() else None, "as_text": as_text}
    txt, tnull = _as_text(col)
    return {"kind": "text", "text": _text_cells(txt, tnull), "null": tnull}


def _styles_xml(formats, header_color):
    rgb = "FF" + header_color.lstrip("#").upper()
    numfmts = "".join('<numFmt numFmtId="%d" formatCode="%s"/>' % (164 + i, _esc(f))
                      for i, f in enumerate(formats))
    xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
           '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" '
           'applyFill="1" applyBorder="1" applyAlignment="1">'
           '<alignment horizontal="left" vertical="center" wrapText="1"/></xf>']
    xfs += ['<xf numFmtId="%d" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            % (164 + i) for i in range(len(formats))]
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            + ('<numFmts count="%d">%s</numFmts>' % (len(formats), numfmts) if formats else "")
            + '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
              '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill>'
              '<fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="%s"/><bgColor indexed="64"/></patternFill></fill></fills>'
              '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
              '<border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right>'
              '<top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="%d">%s</cellXfs>'
              '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
              '</styleSheet>') % (rgb, len(xfs), "".join(xfs))


def _sheet_head(frame, nrow, widths, selected):
    ncol = len(frame.columns)
    letters = [_col_letter(j) for j in range(ncol)]
    last = "%s%d" % (letters[-1] if ncol else "A", nrow + 1)
    head = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<dimension ref="A1:%s"/><sheetViews><sheetView workbookViewId="0"%s>'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            '</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'
            % (last, ' tabSelected="1"' if selected else "")]
    for j, c in enumerate(frame.columns):
        w = widths.get(c) or max(12, min(MAX_WIDTH, len(str(c)) + 3))
        head.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (j + 1, j + 1, w))
    head.append('</cols><sheetData><row r="1" ht="%d" customHeight="1">' % HEADER_HEIGHT)
    for j, c in enumerate(frame.columns):
        head.append('<c r="%s1" s="1" t="inlineStr"><is><t>%s</t></is></c>'
                    % (letters[j], _esc(_ILLEGAL.sub("", str(c)))))
    head.append("</row>")
    tail = "</sheetData>"
    if nrow and ncol:
        tail += '<autoFilter ref="A1:%s"/>' % last
    return "".join(head).encode("utf-8"), (tail + "</worksheet>").encode("utf-8")


def _build_block(part, first_row, number_formats, date_columns, formats):
    """XML for one block of rows, as UTF-8 bytes."""
    def style_of(fmt):
        return 2 + formats.index(fmt)
    n, ncol = len(part), len(part.columns)
    rows = np.arange(first_row, first_row + n).astype("U8").astype(object)
    rows_str = rows + _STR_OPEN
    grid = np.empty((n, ncol + 2), dtype=object)
    grid[:, 0] = '<row r="' + rows + '">'
    grid[:, ncol + 1] = "</row>"
    for j, c in enumerate(part.columns):
        p = _plan_column(c, part.iloc[:, j], number_formats, date_columns, style_of)
        ref = '<c r="' + _col_letter(j)
        if p["kind"] == "text":
            cells = (ref + rows_str) + p["text"] + _STR_CLOSE
            cells[p["null"]] = ""
        else:
            cells = (ref + rows) + ('" s="%d"><v>' % p["style"]) + p["nums"] + "</v></c>"
            cells[~p["ok"]] = ""
            if p["text"] is not None:
                t = p["as_text"]
                cells[t] = (ref + rows_str[t]) + p["text"][t] + _STR_CLOSE
        grid[:, j + 1] = cells
    return "".join(grid.ravel().tolist()).encode("utf-8")


def _deflate_segment(data, level):
    """Raw-deflate `data` so that segments can simply be concatenated."""
    co = zlib.compressobj(level, zlib.DEFLATED, -15)
    return co.compress(data) + co.flush(zlib.Z_FULL_FLUSH)


def _block_job(args):
    part, first_row, number_formats, date_columns, formats, level = args
    data = _build_block(part, first_row, number_formats, date_columns, formats)
    return _deflate_segment(data, level), zlib.crc32(data), len(data)


# -- crc32 of a concatenation, from the parts' crcs (port of zlib's) --
def _gf2_times(mat, vec):
    s, i = 0, 0
    while vec:
        if vec & 1:
            s ^= mat[i]
        vec >>= 1
        i += 1
    return s


def _gf2_square(mat):
    return [_gf2_times(mat, mat[n]) for n in range(32)]


def crc32_combine(crc1, crc2, len2):
    if len2 <= 0:
        return crc1
    odd = [0xEDB88320] + [1 << n for n in range(31)]
    even = _gf2_square(odd)
    odd = _gf2_square(even)
    while True:
        even = _gf2_square(odd)
        if len2 & 1:
            crc1 = _gf2_times(even, crc1)
        len2 >>= 1
        if not len2:
            break
        odd = _gf2_square(even)
        if len2 & 1:
            crc1 = _gf2_times(odd, crc1)
        len2 >>= 1
        if not len2:
            break
    return crc1 ^ crc2


class _FinalBlock(object):
    """Stands in for the zip entry's compressor: the entry's data is
    appended already compressed, and closing it adds the final (empty)
    deflate block."""
    def flush(self):
        return b"\x03\x00"


def _zip64(frame):
    return len(frame) * max(1, len(frame.columns)) * 120 > 3500000000


def _write_sheet_serial(zf, entry, frame, number_formats, date_columns, formats, widths,
                        selected):
    head, tail = _sheet_head(frame, len(frame), widths, selected)
    with zf.open(entry, "w", force_zip64=_zip64(frame)) as fh:
        fh.write(head)
        for start in range(0, len(frame), BLOCK_ROWS):
            fh.write(_build_block(frame.iloc[start:start + BLOCK_ROWS], 2 + start,
                                  number_formats, date_columns, formats))
        fh.write(tail)


def _write_sheet_parallel(zf, pool, workers, entry, frame, number_formats, date_columns,
                          formats, widths, selected, level):
    """Blocks are built AND compressed in worker processes; this process
    only appends the compressed segments to the zip entry."""
    head, tail = _sheet_head(frame, len(frame), widths, selected)
    with zf.open(entry, "w", force_zip64=_zip64(frame)) as fh:
        for attr in ("_compressor", "_fileobj", "_crc", "_file_size", "_compress_size"):
            if not hasattr(fh, attr):
                raise RuntimeError("zip writer internals differ in this Python")
        fh._compressor = _FinalBlock()   # segments arrive already deflated
        state = {"crc": 0, "size": 0, "csize": 0}

        def emit(seg, crc, size):
            fh._fileobj.write(seg)
            state["crc"] = crc if state["size"] == 0 else crc32_combine(state["crc"], crc, size)
            state["size"] += size
            state["csize"] += len(seg)

        emit(_deflate_segment(head, level), zlib.crc32(head), len(head))
        pending = collections.deque()
        starts = iter(range(0, len(frame), BLOCK_ROWS))
        while True:
            while len(pending) < workers * 2:
                start = next(starts, None)
                if start is None:
                    break
                pending.append(pool.submit(_block_job, ((
                    frame.iloc[start:start + BLOCK_ROWS], 2 + start, number_formats,
                    date_columns, formats, level))))
            if not pending:
                break
            emit(*pending.popleft().result())
        emit(_deflate_segment(tail, level), zlib.crc32(tail), len(tail))
        fh._crc = state["crc"]
        fh._file_size = state["size"]
        fh._compress_size = state["csize"]


PARALLEL_MIN_CELLS = 1500000     # below this a pool costs more than it saves


def write_workbook(path, sheets, number_formats=None, date_columns=(), widths=None,
                   header_color="#00857D", progress=None, compresslevel=1, workers=1):
    """sheets: list of (name, DataFrame). Returns [(sheet name, rows), ...].

    workers > 1 spreads the work over that many processes."""
    number_formats = dict(number_formats or {})
    date_columns = set(date_columns)
    widths = widths or {}
    formats = []
    for f in list(number_formats.values()) + ["DD/MM/YYYY"]:
        if f not in formats:
            formats.append(f)

    used, parts = set(), []
    for name, frame in sheets:
        if frame is None:
            continue
        pieces = max(1, -(-len(frame) // MAX_DATA_ROWS))
        for k in range(pieces):
            nm = name if k == 0 else "%s (%d)" % (name, k + 1)
            parts.append((_safe_name(nm, used),
                          frame.iloc[k * MAX_DATA_ROWS:(k + 1) * MAX_DATA_ROWS]))

    cells = sum(f.shape[0] * f.shape[1] for _n, f in parts)
    pool = None
    if workers > 1 and cells >= PARALLEL_MIN_CELLS:
        try:
            import concurrent.futures as cf
            import multiprocessing as mp
            pool = cf.ProcessPoolExecutor(max_workers=workers, mp_context=mp.get_context("spawn"))
        except Exception:
            pool = None

    written = []
    try:
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, allowZip64=True,
                             compresslevel=compresslevel) as zf:
            for i, (name, frame) in enumerate(parts):
                if progress:
                    progress(name, i, len(parts), len(frame))
                entry = "xl/worksheets/sheet%d.xml" % (i + 1)
                if pool is not None and len(frame) > BLOCK_ROWS:
                    _write_sheet_parallel(zf, pool, workers, entry, frame, number_formats,
                                          date_columns, formats, widths, i == 0, compresslevel)
                else:
                    _write_sheet_serial(zf, entry, frame, number_formats, date_columns,
                                        formats, widths, i == 0)
                written.append((name, len(frame)))
            _write_package_parts(zf, [n for n, _f in parts], formats, header_color)
    finally:
        if pool is not None:
            pool.shutdown(wait=True, cancel_futures=True)
    return written


def _write_package_parts(zf, names, formats, header_color):
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
          '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000"/></bookViews><sheets>']
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for i, name in enumerate(names):
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>'
                  % (_esc(name).replace('"', "&quot;"), i + 1, i + 1))
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1))
    rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (len(names) + 1))
    zf.writestr("[Content_Types].xml", "".join(ct) + "</Types>")
    zf.writestr("_rels/.rels",
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    zf.writestr("xl/workbook.xml", "".join(wb) + "</sheets></workbook>")
    zf.writestr("xl/_rels/workbook.xml.rels", "".join(rels))
    zf.writestr("xl/styles.xml", _styles_xml(formats, header_color))


def write_workbook_compat(path, sheets, number_formats=None, date_columns=(), widths=None,
                          header_color="#00857D", progress=None):
    """Same content through xlsxwriter (slower). Fallback only."""
    import xlsxwriter
    number_formats = number_formats or {}
    date_columns = set(date_columns)
    wb = xlsxwriter.Workbook(path, {"constant_memory": True, "strings_to_numbers": False,
                                    "strings_to_formulas": False, "strings_to_urls": False,
                                    "nan_inf_to_errors": True})
    head = wb.add_format({"bold": True, "bg_color": header_color, "font_color": "white",
                          "border": 1, "text_wrap": True, "valign": "vcenter", "align": "left"})
    fm = {f: wb.add_format({"num_format": f}) for f in set(number_formats.values())}
    dfmt = wb.add_format({"num_format": "DD/MM/YYYY"})
    used, written = set(), []
    for si, (name, frame) in enumerate(sheets):
        if frame is None:
            continue
        frame = frame.iloc[:MAX_DATA_ROWS]
        nm = _safe_name(name, used)
        if progress:
            progress(nm, si, len(sheets), len(frame))
        ws = wb.add_worksheet(nm)
        cols = list(frame.columns)
        kinds = []
        data = []
        for c in cols:
            if c in number_formats:
                kinds.append(fm[number_formats[c]])
                data.append(pd.to_numeric(frame[c], errors="coerce").tolist())
            elif c in date_columns:
                kinds.append(dfmt)
                d = pd.to_datetime(frame[c], format="%d/%m/%Y", errors="coerce")
                data.append([None if pd.isna(v) else v.to_pydatetime() for v in d])
            else:
                kinds.append(None)
                t, null = _as_text(frame[c])
                t[null] = None
                data.append(t.tolist())
            ws.set_column(len(kinds) - 1, len(kinds) - 1, max(12, min(MAX_WIDTH, len(str(c)) + 3)))
        ws.set_row(0, HEADER_HEIGHT)
        for j, c in enumerate(cols):
            ws.write_string(0, j, str(c), head)
        for i in range(len(frame)):              # row by row: required by constant_memory
            for j in range(len(cols)):
                v = data[j][i]
                if v is None or (isinstance(v, float) and v != v):
                    continue
                if kinds[j] is None:
                    ws.write_string(i + 1, j, v)
                elif kinds[j] is dfmt:
                    ws.write_datetime(i + 1, j, v, dfmt)
                else:
                    ws.write_number(i + 1, j, v, kinds[j])
        ws.freeze_panes(1, 0)
        if len(frame) and cols:
            ws.autofilter(0, 0, len(frame), len(cols) - 1)
        written.append((nm, len(frame)))
    wb.close()
    return written
