"""
Remittance Rebate Calculator - run state and processing phases.

One Run = one month's exercise. It owns the uploaded files, the working
dataset (held in memory, snapshotted to disk), the journal of every
manual change, and the generated reports.

    Phase 1  process()    consolidate -> cleanse -> enrich -> business rules
    Review                query file out / in, amend mode, mark cancelled,
                          customer types, commercial near matches
    Phase 2  generate()   derived columns + keys -> SBP Claim tabs ->
                          equations -> control checks -> final workbook

Phase 2 can be repeated as often as needed; it always starts from the
current working dataset and never alters it.
"""
import collections
import contextlib
import datetime
import hashlib
import io
import json
import os
import pickle
import re
import shutil
import threading
import time

import pandas as pd

import controls
import engine
import names_review
import xlsx_fast

VERSION = "2.8.0"

# slot -> (label, multiple files?, engine constant, group, hint)
SLOTS = collections.OrderedDict([
    ("rh", ("RH extract", True, "RH_FILE", "channel", "Tab-delimited text (.txt); add every part")),
    ("grs", ("GRS extract", True, "GRS_FILE", "channel", "Excel; all sheets and all files are combined")),
    ("fm", ("FM extract", True, "FM_FILE", "channel", "Excel; all sheets and all files are combined")),
    ("rimpim", ("RIM / PIM extract", True, "RIMPIM_FILE", "channel", "Excel; all sheets and all files are combined")),
    ("entity_list", ("Entity list", False, "ENTITY_LIST_FILE", "reference",
                     "R.E name, country and claim status")),
    ("itrs", ("ITRS data", True, None, "reference",
              "One or more files named 'ITRS Data Mon, YYYY.xlsx'")),
    ("refunds", ("Refunds / cancellations", False, "REFUNDS_FILE", "reference",
                 "Reference No. and Amount")),
    ("rda_other", ("RDA - other banks", False, "RDA_OTHER_FILE", "reference", "R.E and URN")),
    ("rda_hbl", ("RDA - HBL", True, "RDA_HBL_FOLDER", "reference", "One or more workbooks")),
    ("cnic_oc", ("7122 (CNIC for cash-over-counter)", False, "CNIC_OC_FILE", "reference",
                 "URN and Nar 2 - CNIC")),
    ("ac_cnic", ("DL1534 (account master)", False, "AC_CNIC_FILE", "reference",
                 "ext_acct_num, cnic, cust_type")),
    ("commercial", ("Commercial names repository", True, "COMMERCIAL_FOLDER", "reference",
                    "Remitter and beneficiary commercial names")),
])
CHANNEL_SLOTS = [k for k, v in SLOTS.items() if v[3] == "channel"]

# column -> Mode the blank only matters for (None = every row)
QUERY_COLUMNS = collections.OrderedDict([
    ("CNIC NO.", "OC"), ("Remitter ID", None), ("Account No", "AC"), ("CNIC-A/C", "AC"),
    ("Remitter Name", None), ("Beneficiary Name", None),
    ("Upload Date", None), ("Open Date", None), ("Payment Date", None),
    ("R.E Name", None), ("Country", None), ("Country of Origin", None),
    ("Claim / No Claim", None), ("RDA / NON RDA", None),
])
ACT_MODE = "Change Mode To"
ACT_CANCEL = "Cancel? (Y)"
SHEET_MODE = "Change of Mode"
SHEET_CANCEL = "Mark Cancelled"
SHEET_README = "Read me"
QUERY_SHEET_CAP = 100000
BASE_MODES = ["AC", "OC", "IB", "CM"]
INTERNAL_PREFIX = "_"

_s = engine._s


class RunError(Exception):
    """A problem the user can act on; shown as-is in the browser."""


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _safe_filename(name):
    name = os.path.basename(str(name).replace("\\", "/")).strip()
    name = re.sub(r"[^\w .,()&+\-]", "_", name)
    return name[:150] or "file"


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def replace_file(tmp, dst):
    """os.replace with retries. On Windows the swap fails with 'Access is
    denied' while another thread (or a virus scanner) has the target open
    for a moment; on Linux the first attempt always succeeds."""
    for attempt in range(40):
        try:
            os.replace(tmp, dst)
            return
        except PermissionError:
            time.sleep(0.05 if attempt < 20 else 0.25)
    with open(tmp, "rb") as src, open(dst, "wb") as out:    # last resort: overwrite in place
        shutil.copyfileobj(src, out)
    with contextlib.suppress(OSError):
        os.remove(tmp)


class _Tee(io.TextIOBase):
    """Turns the engine's print() output into classified log lines."""

    def __init__(self, sink):
        self.sink, self.buf = sink, ""

    def write(self, s):
        self.buf += s
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            line = line.rstrip()
            if not line.strip() or set(line.strip()) <= set("=-"):
                continue
            low = line.lower()
            lvl = ("error" if "error" in low
                   else "warn" if ("warning" in low or "not found" in low or "red flag" in low)
                   else "ok" if "complete" in low else "info")
            self.sink(line.strip(), lvl)
        return len(s)

    def flush(self):
        pass


class Run(object):
    def __init__(self, root, settings=None):
        self.root = root
        self.settings = settings or {}
        self.meta = {}
        self.total = None            # working TOTAL frame
        self.extra = {}              # ORRE / Cancelled / RDA-Other-Unmatch
        self.stats = {}
        self.sheets = None           # last generated workbook, for browsing
        self.checks = []
        self.journal = []
        self.log = []
        self.suggestions = []
        self.names_rev = 0
        self._excl_lock = threading.RLock()
        self.total_ver = 0          # bumped whenever TOTAL is replaced or loses/gains rows
        self._pos = None

    # ── persistence ─────────────────────────────────────────────
    @property
    def run_id(self):
        return self.meta.get("id", "")

    @property
    def data_dir(self):
        """The data folder shared by all runs (users, names, caches)."""
        return os.path.dirname(os.path.dirname(os.path.abspath(self.root)))

    def p(self, *parts):
        return os.path.join(self.root, *parts)

    @classmethod
    def create(cls, runs_dir, name, user, settings=None):
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        run = cls(os.path.join(runs_dir, stamp), settings)
        os.makedirs(run.p("inputs"))
        os.makedirs(run.p("outputs"))
        run.meta = {"id": stamp, "name": (name or "").strip() or "Run " + stamp,
                    "created_by": user, "created_at": _now(), "usd_rate": None,
                    "status": "new", "cust_types": [], "decisions": {"remi": {}, "bene": {}},
                    "timings": [], "outputs": [], "version": VERSION}
        run.save_meta()
        return run

    @classmethod
    def load(cls, root, settings=None):
        run = cls(root, settings)
        with open(run.p("meta.json"), encoding="utf-8") as fh:
            run.meta = json.load(fh)
        if os.path.exists(run.p("log.jsonl")):
            with open(run.p("log.jsonl"), encoding="utf-8") as fh:
                run.log = [json.loads(x) for x in fh if x.strip()][-4000:]
        if os.path.exists(run.p("state.pkl")):
            with open(run.p("state.pkl"), "rb") as fh:
                st = pickle.load(fh)
            run.total, run.extra, run.stats = st["total"], st["extra"], st["stats"]
            run.suggestions = st.get("suggestions", [])
            run.checks = run.meta.get("checks") or []
            run._push_config()
            if os.path.exists(run.p("journal.jsonl")):
                with open(run.p("journal.jsonl"), encoding="utf-8") as fh:
                    entries = [json.loads(x) for x in fh if x.strip()]
                run._replay(entries)
                run.journal = entries
            if run.meta.get("status") in ("processing", "generating"):
                run.meta["status"] = "processed"
        elif run.meta.get("status") != "new":
            run.meta["status"] = "new"
        return run

    def save_meta(self):
        tmp = self.p("meta.json.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.meta, fh, indent=1)
        replace_file(tmp, self.p("meta.json"))

    def _snapshot(self):
        tmp = self.p("state.pkl.tmp")
        with open(tmp, "wb") as fh:
            pickle.dump({"total": self.total, "extra": self.extra, "stats": self.stats,
                         "suggestions": self.suggestions}, fh, protocol=4)
        replace_file(tmp, self.p("state.pkl"))
        if os.path.exists(self.p("journal.jsonl")):
            os.remove(self.p("journal.jsonl"))
        self.journal = []

    def say(self, msg, level="info"):
        msg = re.sub(re.escape(self.p("inputs")) + r"[\\/]\w+[\\/]?", "", str(msg))
        entry = {"t": datetime.datetime.now().strftime("%H:%M:%S"), "m": msg, "l": level}
        self.log.append(entry)
        if len(self.log) > 6000:
            del self.log[:1000]
        try:
            with open(self.p("log.jsonl"), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry) + "\n")
        except OSError:
            pass

    def _record(self, entries):
        self.journal.extend(entries)
        with open(self.p("journal.jsonl"), "a", encoding="utf-8") as fh:
            for e in entries:
                fh.write(json.dumps(e) + "\n")

    # ── inputs ──────────────────────────────────────────────────
    def slot_dir(self, slot):
        return self.p("inputs", slot)

    def files(self, slot):
        d = self.slot_dir(slot)
        if not os.path.isdir(d):
            return []
        return sorted(f for f in os.listdir(d) if not f.startswith(".") and not f.endswith(".part"))

    def add_file(self, slot, filename, stream, length, user):
        if slot not in SLOTS:
            raise RunError("Unknown file slot '%s'." % slot)
        name = _safe_filename(filename)
        ext = os.path.splitext(name)[1].lower()
        allowed = (".txt", ".tsv", ".csv") if slot == "rh" else (".xlsx", ".xlsm", ".xls")
        if ext not in allowed:
            raise RunError("%s expects a %s file; '%s' was not accepted."
                           % (SLOTS[slot][0], " / ".join(allowed), name))
        d = self.slot_dir(slot)
        os.makedirs(d, exist_ok=True)
        if not SLOTS[slot][1]:
            for old in self.files(slot):
                os.remove(os.path.join(d, old))
        tmp = os.path.join(d, name + ".part")
        left = int(length)
        with open(tmp, "wb") as fh:
            while left > 0:
                block = stream.read(min(1 << 20, left))
                if not block:
                    break
                fh.write(block)
                left -= len(block)
        if left:
            os.remove(tmp)
            raise RunError("Upload of '%s' was interrupted - please try again." % name)
        replace_file(tmp, os.path.join(d, name))
        info = self.meta.setdefault("files", {}).setdefault(slot, {})
        info[name] = {"by": user, "at": _now(), "size": int(length),
                      "sha256": _sha256(os.path.join(d, name))}
        if not SLOTS[slot][1]:
            self.meta["files"][slot] = {name: info[name]}
        self.save_meta()
        return name

    def remove_file(self, slot, name):
        path = os.path.join(self.slot_dir(slot), _safe_filename(name))
        if os.path.exists(path):
            os.remove(path)
        self.meta.get("files", {}).get(slot, {}).pop(_safe_filename(name), None)
        self.save_meta()

    def inputs(self):
        out = []
        for slot, (label, multi, _c, group, hint) in SLOTS.items():
            info = self.meta.get("files", {}).get(slot, {})
            out.append({"slot": slot, "label": label, "multi": multi, "group": group,
                        "hint": hint,
                        "files": [dict(info.get(f, {}), name=f) for f in self.files(slot)]})
        return out

    def _itrs_map(self):
        out = {}
        pat = re.compile(r"ITRS\s*Data\s*([A-Za-z]{3})[a-z]*,?\s*(\d{4})", re.IGNORECASE)
        for f in self.files("itrs"):
            m = pat.search(f)
            if m:
                out["%s, %s" % (m.group(1).title(), m.group(2))] = os.path.join(
                    self.slot_dir("itrs"), f)
        return out

    def _push_config(self):
        """Point the engine at this run's files and settings."""
        for slot, (_l, multi, const, _g, _h) in SLOTS.items():
            if not const:
                continue
            files = self.files(slot)
            if multi:
                setattr(engine, const, self.slot_dir(slot) if files else "")
            else:
                setattr(engine, const, os.path.join(self.slot_dir(slot), files[0]) if files else "")
        engine.ITRS_FILES = self._itrs_map()
        engine.ITRS_CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(self.root)),
                                             "cache", "itrs")
        info = (self.meta.get("files") or {}).get("itrs") or {}
        engine.ITRS_FILE_IDS = {os.path.abspath(os.path.join(self.slot_dir("itrs"), f)):
                                info[f].get("sha256") for f in self.files("itrs") if f in info}
        engine.USD_RATE = self.meta.get("usd_rate") or None
        engine.WRITE_INTERMEDIATE = False
        engine.COMMERCIAL_ACCT_TYPES = list(self.meta.get("cust_types") or [])
        dec = self.meta.get("decisions") or {}
        engine.COMMERCIAL_APPROVED = {
            side: {k for k, v in (dec.get(side) or {}).items() if v == "approve"}
            for side in ("remi", "bene")}
        engine.NAME_WORKERS = int(self.settings.get("workers") or 1)
        names_review.push(names_review.load(self.data_dir))

    def readiness(self):
        """Problems that stop processing, and gaps worth knowing about."""
        blocking, notes = [], []
        if not any(self.files(s) for s in CHANNEL_SLOTS):
            blocking.append("Upload at least one channel extract (RH, GRS, FM or RIM/PIM).")
        if not self.files("entity_list"):
            blocking.append("Upload the Entity list.")
        try:
            if not float(self.meta.get("usd_rate") or 0) > 0:
                raise ValueError
        except (TypeError, ValueError):
            blocking.append("Enter the USD rate for the month.")
        for slot in SLOTS:
            if slot in ("entity_list",) or slot in CHANNEL_SLOTS:
                continue
            if not self.files(slot):
                notes.append("%s not uploaded - that step will be skipped." % SLOTS[slot][0])
        bad = [f for f in self.files("itrs") if f not in
               [os.path.basename(p) for p in self._itrs_map().values()]]
        for f in bad:
            notes.append("ITRS file '%s' is not named 'ITRS Data Mon, YYYY' and will be ignored." % f)
        return blocking, notes

    # ── phase 1 ─────────────────────────────────────────────────
    def process(self, progress=lambda label, i, n: None):
        blocking, notes = self.readiness()
        if blocking:
            raise RunError(" ".join(blocking))
        self.meta.update(status="processing", timings=[], outputs=[])
        self.save_meta()
        self.sheets, self.checks = None, []
        for n in notes:
            self.say(n, "warn")
        self._push_config()
        engine._NAME_CACHE.clear()
        tee = _Tee(self.say)
        timings = []
        steps = ["Consolidating channel extracts", "Cleansing names, identifiers and dates",
                 "Applying entity and ITRS enrichment", "Applying business rules",
                 "Preparing review"]
        t_all = time.time()

        def run_step(i, fn):
            progress(steps[i], i, len(steps))
            t = time.time()
            with contextlib.redirect_stdout(tee):
                res = fn()
            timings.append({"stage": steps[i], "seconds": round(time.time() - t, 2)})
            return res

        df = run_step(0, lambda: engine.consolidate(
            rh_path=engine.RH_FILE, fm_path=engine.FM_FILE, grs_path=engine.GRS_FILE,
            rimpim_path=engine.RIMPIM_FILE, output_path=None))
        self.say("Consolidated %s transactions" % format(len(df), ","), "ok")
        df = run_step(1, lambda: engine.cleanse(df))
        amt = pd.to_numeric(df["Amount"], errors="coerce")
        self.stats = {"consolidated_rows": int(len(df)),
                      "consolidated_amount": float(amt.sum()),
                      "channels": {str(k): int(v) for k, v in df["Channel"].value_counts().items()},
                      "channel_amounts": {str(k): float(v) for k, v in
                                          amt.groupby(df["Channel"]).sum().items()}}
        df = run_step(2, lambda: engine.vlookup(df))
        df, extra = run_step(3, lambda: engine.apply_business_rules(df))
        self.total = df.reset_index(drop=True)
        self.extra = {k: v.reset_index(drop=True) for k, v in extra.items()}
        self._pos = None

        def prep():
            self.total_ver += 1
            self.suggestions = engine.commercial_suggestions(self.total)
            self.exclusion_tab()
            self.query_counts()
            names_review.prebuild(self, self.data_dir)
            return None
        run_step(4, prep)
        self._snapshot()
        timings.append({"stage": "Total - processing", "seconds": round(time.time() - t_all, 2)})
        self.meta.update(status="processed", timings=timings, processed_at=_now(),
                         period=self._period())
        self.save_meta()
        progress("Processing complete", len(steps), len(steps))
        self.say("Processing complete: %s transactions in TOTAL, %.1f s"
                 % (format(len(self.total), ","), time.time() - t_all), "ok")

    def _period(self):
        try:
            d = pd.to_datetime(self.total["Upload Date"], format="%d/%m/%Y", errors="coerce")
            top = d.dt.to_period("M").value_counts()
            return top.index[0].strftime("%b %Y") if len(top) else ""
        except Exception:
            return ""

    # ── helpers on the working frame ────────────────────────────
    def _need(self):
        if self.total is None:
            raise RunError("This run has not been processed yet.")

    def _labels(self, row_ids):
        """Row ID -> index label in TOTAL (missing ids are dropped)."""
        if self._pos is None:
            self._pos = pd.Series(self.total.index, index=self.total["Row ID"].values)
        ids = [r for r in row_ids if r in self._pos.index]
        return ids, self._pos.loc[ids].tolist()

    def data_key(self):
        """Changes whenever TOTAL's content may have changed (other than by
        a name decision, which only touches the name columns)."""
        return (id(self.total), len(self.total), self.total_ver,
                sum(1 for e in self.journal if e.get("action") != "names"))

    def _cached(self, name, fn):
        """Per data version cache for values derived from TOTAL."""
        store = getattr(self, "_derived", None)
        key = self.data_key()
        if store is None or store[0] != key:
            store = (key, {})
            self._derived = store
        if name not in store[1]:
            store[1][name] = fn()
        return store[1][name]

    def _mode(self, frame=None):
        if frame is None:
            return self._cached("mode", lambda: self.total["Mode"].pipe(engine._sv)
                                .str.upper().str.strip())
        return frame["Mode"].pipe(engine._sv).str.upper().str.strip()

    def exclusion_tab(self):
        """Per TOTAL row, the extraction tab that will take it in the report
        (No Claim, CM, Below US$200, UK pension, Bene Comm, Reme Comm, RDA),
        or '' if it can still be claimed - the same function the report
        uses. The costly, data-dependent part is computed once per data
        version; customer types and near-match decisions are re-applied in
        a fraction of a second. Name decisions do not refresh it (Generate
        does)."""
        with self._excl_lock:
            dkey = self.data_key()
            parts = getattr(self, "_excl_parts", None)
            if parts is None or parts[0] != dkey:
                self._push_config()
                with contextlib.redirect_stdout(io.StringIO()):
                    parts = (dkey, engine.exclusion_parts(self.total))
                self._excl_parts = parts
            dec = self.meta.get("decisions") or {}
            ckey = (dkey, tuple(sorted(self.meta.get("cust_types") or [])),
                    json.dumps(dec, sort_keys=True))
            cache = getattr(self, "_excl_cache", None)
            if cache and cache[0] == ckey:
                return cache[1]
            engine.COMMERCIAL_ACCT_TYPES = list(self.meta.get("cust_types") or [])
            engine.COMMERCIAL_APPROVED = {
                side: {k for k, v in (dec.get(side) or {}).items() if v == "approve"}
                for side in ("remi", "bene")}
            tab = engine.exclusion_from_parts(parts[1])
            self._excl_cache = (ckey, tab)
        if cache is not None and cache[1].index.equals(tab.index):
            changed = cache[1].ne(tab)
            if changed.any():
                names_review.exclusion_changed(self, changed)
        return tab

    def excluded_mask(self):
        """Transactions the report will exclude anyway; left out of the
        review work when the scope is 'eligible'."""
        if getattr(self, "_excl_once", None) is not None:
            return self._excl_once          # reused within one counting pass
        return self.exclusion_tab().ne("")

    def names_scope(self):
        return "all" if self.meta.get("names_scope") == "all" else "eligible"

    @contextlib.contextmanager
    def _one_pass(self):
        """Work out the exclusions once for a group of blank_mask() calls."""
        self._excl_once = None
        self._excl_once = self.excluded_mask()
        try:
            yield
        finally:
            self._excl_once = None

    def query_scope(self):
        return "all" if self.meta.get("query_scope") == "all" else "eligible"

    def blank_mask(self, col, scope=None):
        mode_only = QUERY_COLUMNS[col]
        if col not in self.total.columns:
            return pd.Series(False, index=self.total.index)

        def base():
            m = self.total[col].pipe(engine._ev)
            if mode_only:
                m = m & self._mode().eq(mode_only)
            return m
        m = base() if col in names_review.NAME_COLS else self._cached("blank " + col, base)
        if (scope or self.query_scope()) == "eligible":
            m = m & ~self.excluded_mask()
        return m

    def known_modes(self):
        seen = [m for m in self._mode().unique() if m]
        return BASE_MODES + sorted(m for m in seen if m not in BASE_MODES)

    # ── validation of a manual value ────────────────────────────
    def _clean_value(self, col, value, mode):
        """Returns (clean value, None) or (None, reason)."""
        v = _s(value)
        if not v:
            return None, "blank"
        if col == "CNIC NO.":
            d = re.sub(r"[-\s ]", "", v)
            if re.fullmatch(r"\d+\.0", d):
                d = d[:-2]
            if not re.fullmatch(r"[1-9]\d{12}", d):
                return None, "CNIC must be 13 digits and not start with 0"
            return d, None
        if col == "CNIC-A/C":
            d = re.sub(r"[-\s ]", "", v)
            if re.fullmatch(r"\d+\.0", d):
                d = d[:-2]
            if d[:1].upper() == "P" and len(d) > 3:
                return d, None
            if not re.fullmatch(r"\d{13}", d):
                return None, "must be a 13-digit CNIC or a passport number starting with P"
            return d, None
        if col == "Account No":
            d = re.sub(r"[-\s ]", "", v)
            if re.fullmatch(r"\d+\.0", d):
                d = d[:-2]
            if mode == "AC":
                if len(d) == 24:
                    d = d[-14:]
                if len(d) != 14:
                    return None, "account number must be 14 characters (or a 24-character IBAN)"
            return d, None
        if col in engine.DATE_COLUMNS:
            d = pd.NaT
            if re.fullmatch(r"\d{1,2}[/-]\d{1,2}[/-]\d{4}", v):
                d = pd.to_datetime(v.replace("-", "/"), format="%d/%m/%Y", errors="coerce")
            elif re.match(r"\d{4}-\d{2}-\d{2}", v):
                d = pd.to_datetime(v[:10], format="%Y-%m-%d", errors="coerce")
            elif re.fullmatch(r"\d{5}(\.0+)?", v):          # Excel serial number
                d = pd.Timestamp("1899-12-30") + pd.Timedelta(days=int(float(v)))
            if pd.isna(d) or not (1990 <= d.year <= 2100):
                return None, "date must be DD/MM/YYYY"
            return d.strftime("%d/%m/%Y"), None
        if col == "RDA / NON RDA":
            for ok in (engine.RDA_VALUE_3RD, engine.RDA_VALUE_HBL, engine.RDA_VALUE_NON):
                if v.upper() == ok.upper():
                    return ok, None
            return None, "must be '%s', '%s' or '%s'" % (
                engine.RDA_VALUE_3RD, engine.RDA_VALUE_HBL, engine.RDA_VALUE_NON)
        if col == "Claim / No Claim":
            return v.upper(), None
        if col in ("Remitter Name", "Beneficiary Name", "R.E Name", "Country"):
            return re.sub(r"\s+", " ", v).upper(), None
        if re.fullmatch(r"\d+\.0", v):
            v = v[:-2]
        return v, None

    # ── applying changes (also used when replaying the journal) ──
    def _apply_sets(self, items):
        """items: [(row_id, column, clean value)]. Returns journal entries."""
        if not items:
            return []
        entries = []
        frame = pd.DataFrame(items, columns=["rid", "col", "val"])
        ids, labels = self._labels(frame["rid"].tolist())
        lab = dict(zip(ids, labels))
        frame = frame[frame["rid"].isin(lab)]
        acct_labels = []
        # Account No first: it can bring CNIC-A/C and Cust Type with it,
        # and an explicit value for those in the same batch must win.
        for col in sorted(frame["col"].unique(), key=lambda c: c != "Account No"):
            part = frame[frame["col"] == col].drop_duplicates("rid", keep="last")
            labels_c = [lab[r] for r in part["rid"]]
            if col not in self.total.columns:
                self.total[col] = None
            old = self.total.loc[labels_c, col].pipe(engine._sv).tolist()
            self.total.loc[labels_c, col] = part["val"].values
            urns = self.total.loc[labels_c, "URN"].pipe(engine._sv).tolist()
            for rid, urn, o, v in zip(part["rid"], urns, old, part["val"]):
                entries.append({"action": "set", "row_id": rid, "urn": urn, "column": col,
                                "old": o, "new": v})
            if col == "Account No":
                acct_labels = labels_c
            if col in names_review.NAME_COLS:
                self.names_rev += 1
        if acct_labels:
            mask = pd.Series(False, index=self.total.index)
            mask.loc[acct_labels] = True
            mask &= self._mode().eq("AC")
            if mask.any():
                with contextlib.redirect_stdout(io.StringIO()):
                    sub = engine._rule_account_cnic(self.total.loc[mask].copy())
                for c in ("Account No", engine.AC_CNIC_COL, engine.ACCT_TYPE_COL):
                    if c in sub.columns:
                        self.total.loc[mask, c] = sub[c]
        return entries

    def _apply_modes(self, items):
        """items: [(row_id, new mode)]."""
        if not items:
            return []
        frame = pd.DataFrame(items, columns=["rid", "mode"]).drop_duplicates("rid", keep="last")
        ids, labels = self._labels(frame["rid"].tolist())
        frame = frame.set_index("rid").loc[ids]
        old = self.total.loc[labels, "Mode"].pipe(engine._sv).tolist()
        urns = self.total.loc[labels, "URN"].pipe(engine._sv).tolist()
        self.total.loc[labels, "Mode"] = frame["mode"].values
        mask = pd.Series(False, index=self.total.index)
        mask.loc[labels] = True
        with contextlib.redirect_stdout(io.StringIO()):
            self.total = engine.recompute_after_mode_change(self.total, mask)
        return [{"action": "mode", "row_id": r, "urn": u, "column": "Mode", "old": o, "new": n}
                for r, u, o, n in zip(ids, urns, old, frame["mode"])]

    def _apply_cancel(self, items):
        """items: [(row_id, reason)]. Moves rows TOTAL -> Cancelled."""
        if not items:
            return []
        reasons = dict(items)
        ids, labels = self._labels(list(reasons))
        if not ids:
            return []
        rows = self.total.loc[labels].copy()
        rows[engine.CANCEL_REASON_COL] = ["Marked by reviewer" + (": " + reasons[r] if reasons[r] else "")
                                          for r in ids]
        cur = self.extra.get(engine.CANCELLED_SHEET_NAME)
        self.extra[engine.CANCELLED_SHEET_NAME] = (
            rows if cur is None else pd.concat([cur, rows], ignore_index=True, sort=False))
        self.total = self.total.drop(index=labels).reset_index(drop=True)
        self._pos = None
        self.total_ver += 1
        return [{"action": "cancel", "row_id": r, "urn": _s(u), "column": "", "old": "TOTAL",
                 "new": "Cancelled", "note": reasons[r]}
                for r, u in zip(ids, rows["URN"])]

    def _apply_restore(self, row_ids):
        cur = self.extra.get(engine.CANCELLED_SHEET_NAME)
        if cur is None or not len(cur):
            return []
        m = cur["Row ID"].isin(set(row_ids))
        if not m.any():
            return []
        rows = cur.loc[m].drop(columns=[engine.CANCEL_REASON_COL], errors="ignore").copy()
        # These rows left before RDA classification ran; do it now.
        with contextlib.redirect_stdout(io.StringIO()):
            rows, _ = engine._rule_rda(rows, {})
            rows = engine._rule_account_review(rows)
        self.extra[engine.CANCELLED_SHEET_NAME] = cur.loc[~m].reset_index(drop=True)
        self.total = (pd.concat([self.total, rows], ignore_index=True, sort=False)
                      .sort_values("Row ID", kind="stable").reset_index(drop=True))
        self._pos = None
        self.total_ver += 1
        return [{"action": "restore", "row_id": r, "urn": _s(u), "column": "",
                 "old": "Cancelled", "new": "TOTAL"} for r, u in zip(rows["Row ID"], rows["URN"])]

    def _replay(self, entries):
        """Re-apply journalled changes on top of the last snapshot."""
        i = 0
        while i < len(entries):
            act = entries[i]["action"]
            j = i
            while j < len(entries) and entries[j]["action"] == act:
                j += 1
            block = entries[i:j]
            if act == "set":
                self._apply_sets([(e["row_id"], e["column"], e["new"]) for e in block])
            elif act == "mode":
                self._apply_modes([(e["row_id"], e["new"]) for e in block])
            elif act == "cancel":
                self._apply_cancel([(e["row_id"], e.get("note", "")) for e in block])
            elif act == "restore":
                self._apply_restore([e["row_id"] for e in block])
            elif act == "names":
                names_review.replay(self, block)
            i = j

    def _commit(self, entries, user, source):
        stamp = _now()
        for e in entries:
            e.update(user=user, at=stamp, source=source)
        if entries:
            self._record(entries)
            if self.meta.get("status") == "generated":
                self.meta["status"] = "processed"       # report is now out of date
                self.meta["stale"] = True
                self.save_meta()

    # ── review: single transaction ──────────────────────────────
    FIND_FIELDS = collections.OrderedDict([
        ("any", ("Any field", None)),
        ("urn", ("URN / Row ID", ["URN", "Row ID", "RH Reference", "Payorder No"])),
        ("name", ("Remitter or beneficiary name", ["Remitter Name", "Beneficiary Name",
                                                   "_orig Remitter Name", "_orig Beneficiary Name",
                                                   "LINK TITLE"])),
        ("account", ("Account No / IBAN", ["Account No", "IBAN No"])),
        ("cnic", ("CNIC", ["CNIC NO.", "CNIC-A/C"])),
        ("remid", ("Remitter ID", ["Remitter ID", "Remitter ID_2", "Remitter ID_3", "Remitter ID_4"])),
        ("contact", ("Contact No", ["Contact No"])),
    ])

    def find(self, q, field="any", limit=200):
        """Transactions in TOTAL, Cancelled and ORRE whose chosen field
        contains the text (case, spaces and dashes ignored)."""
        self._need()
        q = _s(q)
        if len(q) < 3:
            raise RunError("Type at least 3 characters to search.")
        if field not in self.FIND_FIELDS:
            field = "any"
        cols = self.FIND_FIELDS[field][1]
        if cols is None:
            cols = []
            for _k, (_l, cs) in self.FIND_FIELDS.items():
                cols += cs or []
        needle = re.sub(r"[\s\-]", "", q).upper()
        out, total = [], 0
        frames = [("TOTAL", self.total)] + [(k, v) for k, v in self.extra.items()
                                            if "Row ID" in v.columns and len(v)
                                            and not engine.is_null_frame(v)]
        for name, frame in frames:
            m = pd.Series(False, index=frame.index)
            for c in cols:
                if c in frame.columns:
                    v = frame[c].pipe(engine._sv).str.upper().str.replace(r"[\s\-]", "", regex=True)
                    m |= v.str.contains(needle, regex=False)
            total += int(m.sum())
            for _i, row in frame.loc[m].head(max(0, limit - len(out))).iterrows():
                rec = {c: _fmt(row[c]) for c in frame.columns if not c.startswith(INTERNAL_PREFIX)
                       and c not in engine.KEY_DEFINITIONS and not c.startswith("EQ-")}
                rec["_sheet"] = name
                rec["_tab"] = self.report_tab(rec.get("Row ID", "")) if name == "TOTAL" else ""
                out.append(rec)
        return {"rows": out, "total": total, "limit": limit}

    def bulk_edit(self, row_ids, action, value, user):
        """Mode change, cancel or restore for several transactions at once."""
        self._need()
        row_ids = [_s(r).upper() for r in row_ids if _s(r)]
        if not row_ids:
            raise RunError("Tick one or more transactions first.")
        if action == "mode":
            mode = _s(value).upper()
            if not re.fullmatch(r"[A-Z]{2,4}", mode):
                raise RunError("Choose a valid mode.")
            ids, labels = self._labels(row_ids)
            cur = dict(zip(ids, self.total.loc[labels, "Mode"].pipe(engine._sv).str.upper()))
            entries = self._apply_modes([(r, mode) for r in ids if cur.get(r) != mode])
        elif action == "cancel":
            ids, _l = self._labels(row_ids)
            entries = self._apply_cancel([(r, _s(value)) for r in ids])
        elif action == "restore":
            entries = self._apply_restore(row_ids)
        else:
            raise RunError("Unknown action.")
        self._commit(entries, user, "screen")
        if entries:
            self.say("%s on %d transaction(s) by %s" % (
                {"mode": "Mode changed to " + _s(value).upper(), "cancel": "Marked cancelled",
                 "restore": "Restored to TOTAL"}[action], len(entries), user))
        return {"applied": len(entries)}

    def report_tab(self, row_id):
        """The tab of the last generated report that holds this TOTAL row."""
        if not self.sheets or not row_id:
            return ""
        for name, frame in self.sheets.items():
            if name in (engine.TOTAL_SHEET, engine.ORRE_SHEET_NAME, engine.CANCELLED_SHEET_NAME,
                        engine.RDA_OTHER_UNMATCH_SHEET) or "Row ID" not in frame.columns:
                continue
            if (frame["Row ID"].values == row_id).any():
                return name
        return ""

    def edit(self, row_id, changes, user):
        """changes: {column: value}; special keys 'Mode', '_cancel', '_restore'."""
        self._need()
        report = {"applied": 0, "rejected": []}
        if changes.get("_restore"):
            ent = self._apply_restore([row_id])
            self._commit(ent, user, "screen")
            report["applied"] += len(ent)
            return report
        ids, labels = self._labels([row_id])
        if not ids:
            raise RunError("Row %s is not in TOTAL." % row_id)
        entries = []
        if changes.get("_cancel"):
            entries += self._apply_cancel([(row_id, _s(changes.get("_reason")))])
            self._commit(entries, user, "screen")
            return {"applied": len(entries), "rejected": []}
        mode = _s(self.total.at[labels[0], "Mode"]).upper()
        new_mode = _s(changes.get("Mode")).upper()
        if new_mode and new_mode != mode:
            if not re.fullmatch(r"[A-Z]{2,4}", new_mode):
                report["rejected"].append({"column": "Mode", "value": new_mode,
                                           "reason": "not a valid mode"})
            else:
                entries += self._apply_modes([(row_id, new_mode)])
                mode = new_mode
        sets = []
        for col, val in changes.items():
            if col in ("Mode",) or col.startswith("_") or col not in QUERY_COLUMNS:
                continue
            ids, labels = self._labels([row_id])
            if _s(val) == _s(self.total.at[labels[0], col]):
                continue
            clean, why = self._clean_value(col, val, mode)
            if why == "blank":
                continue
            if why:
                report["rejected"].append({"column": col, "value": _s(val), "reason": why})
            else:
                sets.append((row_id, col, clean))
        entries += self._apply_sets(sets)
        self._commit(entries, user, "screen")
        report["applied"] = len(entries)
        return report

    # ── review: query workbook ──────────────────────────────────
    def query_counts(self, scope=None):
        self._need()
        with self._one_pass():
            return collections.OrderedDict(
                (c, int(self.blank_mask(c, scope).sum())) for c in QUERY_COLUMNS)

    def build_query_workbook(self, path):
        """One worksheet per column with outstanding values, plus the two
        instruction sheets. Returns {sheet: rows}."""
        import xlsxwriter
        self._need()
        visible = [c for c in self.total.columns if not c.startswith(INTERNAL_PREFIX)
                   and c not in engine.KEY_DEFINITIONS and not c.startswith("EQ-")]
        modes = self.known_modes()
        wb = xlsxwriter.Workbook(path, {"strings_to_numbers": False, "strings_to_formulas": False,
                                        "strings_to_urls": False, "nan_inf_to_errors": True})
        head = wb.add_format({"bold": True, "bg_color": "#00857D", "font_color": "white",
                              "border": 1, "text_wrap": True, "valign": "vcenter"})
        head_in = wb.add_format({"bold": True, "bg_color": "#F2B705", "font_color": "#1F2933",
                                 "border": 1, "text_wrap": True, "valign": "vcenter"})
        cell_in = wb.add_format({"bg_color": "#FFF8DC", "border": 1, "border_color": "#E0C060",
                                 "num_format": "@"})
        text = wb.add_format({"num_format": "@"})
        money = wb.add_format({"num_format": "#,##0.00"})
        bold = wb.add_format({"bold": True, "font_size": 13, "font_color": "#00857D"})
        name_fmt = {"head": head, "head_in": head_in, "cell_in": cell_in}
        wrap = wb.add_format({"text_wrap": True, "valign": "top"})

        ws = wb.add_worksheet(SHEET_README)
        ws.set_column(0, 0, 26)
        ws.set_column(1, 1, 96)
        ws.write(0, 0, "Remittance Rebate Calculator - Query File", bold)
        lines = [
            ("Run", "%s (%s)" % (self.meta.get("name"), self.run_id)),
            ("Run reference", self.run_id),
            ("Generated", _now()),
            ("", ""),
            ("How to complete", "Each worksheet lists the transactions where one value is outstanding. "
                                "Type the value in the amber column. Leave a cell empty to skip it."),
            ("Amend the mode", "On any worksheet, type the correct mode (%s) in '%s'. The CNIC, account "
                               "and derived columns are worked out again for the new mode."
             % (", ".join(modes), ACT_MODE)),
            ("Mark as cancelled", "On any worksheet, type Y in '%s'. The transaction moves to the "
                                  "Cancelled tab and is excluded from the claim." % ACT_CANCEL),
            ("Other transactions", "To amend the mode of, or cancel, a transaction that is not listed "
                                   "here, use 'Find transactions' on the Review screen."),
            ("Do not change", "Row ID, sheet names and column headings. Everything else on a row is "
                              "shown for reference only and is ignored on upload."),
            ("Scope", "Only transactions that can still be claimed are listed. Transactions already "
                      "excluded (No Claim entity, Mode CM, below US$%g, UK pension, commercial, RDA) "
                      "need no completion."
             % engine.SBP_USD_THRESHOLD if self.query_scope() == "eligible" else
             "All transactions with an outstanding value are listed, including those already excluded."),
            ("Names", "'%s' lists names the cleansing rules changed in a way worth checking, with a "
                      "suggestion where there is one. Type Y in 'Accept Suggestion (Y)', or type the "
                      "right name in 'Use Name'. '%s' lists spellings that look like the same person "
                      "(same R.E and same counterpart): Y merges them, N keeps them apart. Name "
                      "decisions are remembered for future months." % (
                          names_review.SHEET_NAMES, names_review.SHEET_VARIANTS)),
            ("Upload", "Save the workbook and upload it on the Review screen. It can be uploaded "
                       "more than once; only cells that differ from the current data are applied."),
        ]
        for i, (k, v) in enumerate(lines, start=2):
            ws.write(i, 0, k, wb.add_format({"bold": True, "valign": "top"}))
            ws.write(i, 1, v, wrap)

        counts = collections.OrderedDict()
        used = {SHEET_README.lower(), SHEET_MODE.lower(), SHEET_CANCEL.lower()}
        with self._one_pass():
            masks = {col: self.blank_mask(col) for col in QUERY_COLUMNS}
        for col in QUERY_COLUMNS:
            m = masks[col]
            n = int(m.sum())
            if not n:
                continue
            name = xlsx_fast._safe_name(col, used)
            counts[name] = n
            part = self.total.loc[m]
            if n > QUERY_SHEET_CAP:
                self.say("Query file: '%s' has %s outstanding rows; the first %s are listed."
                         % (col, format(n, ","), format(QUERY_SHEET_CAP, ",")), "warn")
                part = part.head(QUERY_SHEET_CAP)
            cols = ["Row ID", col, ACT_MODE, ACT_CANCEL] + [c for c in visible
                                                           if c not in ("Row ID", col)]
            ws = wb.add_worksheet(name)
            ws.set_row(0, 30)
            ws.freeze_panes(1, 4)
            for j, c in enumerate(cols):
                is_in = j in (1, 2, 3)
                ws.write_string(0, j, c, head_in if is_in else head)
                if is_in:
                    ws.set_column(j, j, 22 if j == 1 else 16, cell_in)
                    continue
                ws.set_column(j, j, max(12, min(40, len(c) + 3)),
                              money if c in engine.NUMBER_FORMATS else text)
                vals = part[c].tolist()
                if c in engine.NUMBER_FORMATS:
                    for i, v in enumerate(vals, start=1):
                        if isinstance(v, (int, float)) and v == v:
                            ws.write_number(i, j, v, money)
                else:
                    for i, v in enumerate(vals, start=1):
                        v = _s(v)
                        if v:
                            ws.write_string(i, j, v)
            last = len(part)
            ws.data_validation(1, 2, last, 2, {"validate": "list", "source": modes,
                                               "ignore_blank": True})
            ws.data_validation(1, 3, last, 3, {"validate": "list", "source": ["Y"],
                                               "ignore_blank": True})
            if col == "RDA / NON RDA":
                ws.data_validation(1, 1, last, 1, {"validate": "list", "source": [
                    engine.RDA_VALUE_3RD, engine.RDA_VALUE_HBL, engine.RDA_VALUE_NON]})
            ws.autofilter(0, 0, last, len(cols) - 1)

        counts.update(names_review.write_sheets(self, self.data_dir, wb, name_fmt))
        wb.close()
        return counts

    def apply_query_workbook(self, path, user):
        """Read a completed query workbook and apply what changed."""
        self._need()
        try:
            book = pd.read_excel(path, sheet_name=None, dtype=str, engine="calamine", header=None)
        except Exception as e:
            raise RunError("The file could not be read as an Excel workbook (%s)." % e)
        readme = book.get(SHEET_README)
        ref = ""
        if readme is not None:
            for _i, r in readme.iterrows():
                if _s(r.iloc[0]) == "Run reference" and len(r) > 1:
                    ref = _s(r.iloc[1])
        if ref and ref != self.run_id:
            raise RunError("This query file belongs to run %s, not to the run that is open (%s)."
                           % (ref, self.run_id))

        rep = {"applied": collections.OrderedDict(), "mode_changes": 0, "cancelled": 0,
               "unchanged": 0, "rejected": [], "sheets": 0}
        by_name = {}
        used = set()
        for col in QUERY_COLUMNS:
            by_name[xlsx_fast._safe_name(col, used).lower()] = col
        modes_ok = set(self.known_modes())
        mode_req, cancel_req, value_req = {}, {}, []
        all_ids = set(self.total["Row ID"])

        def reject(sheet, rid, col, val, why):
            if len(rep["rejected"]) < 2000:
                rep["rejected"].append({"sheet": sheet, "row_id": rid, "column": col,
                                        "value": val, "reason": why})

        def want_mode(sheet, rid, val):
            val = _s(val).upper()
            if not val:
                return
            if val not in modes_ok:
                return reject(sheet, rid, "Mode", val, "mode must be one of " + ", ".join(sorted(modes_ok)))
            if mode_req.get(rid, val) != val:
                return reject(sheet, rid, "Mode", val,
                              "conflicts with '%s' requested on another sheet" % mode_req[rid])
            mode_req[rid] = val

        def resolve(sheet, rid, urn):
            rid, urn = _s(rid).upper(), _s(urn)
            if rid:
                if rid in all_ids:
                    return rid
                reject(sheet, rid, "Row ID", rid, "Row ID is not in TOTAL")
                return None
            if urn:
                hits = self.total.loc[self.total["URN"].pipe(engine._sv).eq(urn), "Row ID"].tolist()
                if len(hits) == 1:
                    return hits[0]
                reject(sheet, "", "URN", urn, "URN not found in TOTAL" if not hits else
                       "URN matches %d transactions - use the Row ID (%s)" % (len(hits), ", ".join(hits[:6])))
            return None

        for sheet, raw in book.items():
            key = str(sheet).strip().lower()
            if raw is None or len(raw) < 2 or key == SHEET_README.lower():
                continue
            hdr = [_s(v) for v in raw.iloc[0].tolist()]
            body = raw.iloc[1:]
            if key in (SHEET_MODE.lower(), SHEET_CANCEL.lower()):
                rep["sheets"] += 1
                for _i, r in body.iterrows():
                    vals = [_s(v) for v in r.tolist()[:3]] + ["", "", ""]
                    if not (vals[0] or vals[1]):
                        continue
                    rid = resolve(sheet, vals[0], vals[1])
                    if not rid:
                        continue
                    if key == SHEET_MODE.lower():
                        want_mode(sheet, rid, vals[2])
                    else:
                        cancel_req[rid] = vals[2]
                continue
            col = by_name.get(key)
            if col is None or "Row ID" not in hdr:
                continue
            rep["sheets"] += 1
            body = body.copy()
            body.columns = hdr[:len(body.columns)]
            rid_s = body["Row ID"].pipe(engine._sv).str.upper()
            for name, fn in ((ACT_MODE, None), (ACT_CANCEL, None)):
                if name not in body.columns:
                    body[name] = None
            if col not in body.columns:
                reject(sheet, "", col, "", "column '%s' is missing from this sheet" % col)
                continue
            vals = body[col].pipe(engine._sv)
            mreq = body[ACT_MODE].pipe(engine._sv)
            creq = body[ACT_CANCEL].pipe(engine._sv).str.upper()
            touched = vals.ne("") | mreq.ne("") | creq.ne("")
            for rid, v, mo, ca in zip(rid_s[touched], vals[touched], mreq[touched], creq[touched]):
                if rid not in all_ids:
                    reject(sheet, rid, "Row ID", rid, "Row ID is not in TOTAL")
                    continue
                if ca in ("Y", "YES", "TRUE", "1"):
                    cancel_req[rid] = "Marked in query file"
                elif ca:
                    reject(sheet, rid, ACT_CANCEL, ca, "type Y to cancel")
                if mo:
                    want_mode(sheet, rid, mo)
                if v:
                    value_req.append((sheet, rid, col, v))

        # cancellations win over everything else on the same row
        for rid in cancel_req:
            mode_req.pop(rid, None)
        value_req = [x for x in value_req if x[1] not in cancel_req]

        entries = []
        if mode_req:
            ids, labels = self._labels(list(mode_req))
            cur = dict(zip(ids, self.total.loc[labels, "Mode"].pipe(engine._sv).str.upper()))
            todo = [(r, m) for r, m in mode_req.items() if cur.get(r) != m]
            got = self._apply_modes(todo)
            rep["mode_changes"] = len(got)
            entries += got
        if value_req:
            ids, labels = self._labels([x[1] for x in value_req])
            lab = dict(zip(ids, labels))
            mode_now = self._mode()
            sets, seen = [], {}
            for sheet, rid, col, v in value_req:
                clean, why = self._clean_value(col, v, mode_now.at[lab[rid]])
                if why:
                    reject(sheet, rid, col, v, why)
                    continue
                if clean == _s(self.total.at[lab[rid], col]):
                    rep["unchanged"] += 1
                    continue
                if seen.get((rid, col), clean) != clean:
                    reject(sheet, rid, col, v, "a different value was given on another sheet")
                    continue
                if (rid, col) not in seen:
                    seen[(rid, col)] = clean
                    sets.append((rid, col, clean))
            got = self._apply_sets(sets)
            for e in got:
                rep["applied"][e["column"]] = rep["applied"].get(e["column"], 0) + 1
            entries += got
        if cancel_req:
            got = self._apply_cancel(list(cancel_req.items()))
            rep["cancelled"] = len(got)
            entries += got
        name_dec, name_fix, name_bad = names_review.read_sheets(book)
        rep["rejected"].extend(name_bad)
        rep["names"] = 0
        if name_fix:
            todo = []
            for rid, col, name in name_fix:
                if rid not in all_ids:
                    reject(names_review.SHEET_CHECK, rid, "Row ID", rid, "Row ID is not in TOTAL")
                    continue
                todo.append((rid, col, name))
            ids, labels = self._labels([x[0] for x in todo])
            lab = dict(zip(ids, labels))
            todo = [x for x in todo if x[2] != _s(self.total.at[lab[x[0]], x[1]])]
            got = self._apply_sets(todo)
            for e in got:
                rep["applied"][e["column"]] = rep["applied"].get(e["column"], 0) + 1
            entries += got
        if name_dec:
            got, bad = names_review.decide(self, self.data_dir, name_dec, user, "query file")
            for x, why in bad:
                reject(names_review.SHEET_NAMES, "", "Name", _s(x.get("name")), why)
            rep["names"] = len(got)
            entries += got
        self._commit(entries, user, "query file")
        rep["total_applied"] = len(entries)
        self.say("Query file applied by %s: %d value(s), %d mode change(s), %d cancelled, "
                 "%d name decision(s), %d rejected"
                 % (user, sum(rep["applied"].values()), rep["mode_changes"], rep["cancelled"],
                    rep["names"], len(rep["rejected"])), "ok" if not rep["rejected"] else "warn")
        if rep["names"]:
            self.suggestions = engine.commercial_suggestions(self.total)
        return rep

    # ── review: names ───────────────────────────────────────────
    def name_decide(self, decisions, user):
        self._need()
        got, bad = names_review.decide(self, self.data_dir, decisions, user, "screen")
        self._commit(got, user, "screen")
        if got:
            self.say("Name review by %s: %d decision(s), %s row(s) updated"
                     % (user, len(got), format(sum(e.get("rows", 0) for e in got), ",")))
        return {"applied": len(got), "rows": sum(e.get("rows", 0) for e in got),
                "rejected": [{"name": _s(x.get("name") or x.get("key")), "reason": why}
                             for x, why in bad]}

    def name_queue(self, selection, on, user):
        self._need()
        n = names_review.set_queue(self, self.data_dir, selection, on, user)
        if n:
            self.save_meta()
            self.say("%s %d name(s) %s the query file (Names To Check)"
                     % (user, n, "added to" if on else "removed from"))
        return {"changed": n}

    # ── review: customer types and commercial names ─────────────
    def cust_types(self):
        self._need()
        col = engine.ACCT_TYPE_COL
        if col not in self.total.columns:
            return []
        is_ac = self._mode().eq("AC")
        vc = self.total.loc[is_ac, col].pipe(engine._sv)
        vc = vc[vc.ne("")].value_counts()
        marked = {str(t).upper() for t in self.meta.get("cust_types") or []}
        return [{"type": k, "rows": int(v), "commercial": k.upper() in marked}
                for k, v in vc.items()]

    def set_cust_types(self, types, user):
        self.meta["cust_types"] = sorted({_s(t) for t in types if _s(t)})
        self._mark_stale()
        self.say("Commercial customer types set by %s: %s"
                 % (user, ", ".join(self.meta["cust_types"]) or "(none)"), "info")

    def _mark_stale(self):
        if self.meta.get("status") == "generated":
            self.meta["status"] = "processed"
            self.meta["stale"] = True
        self.save_meta()

    def decide(self, side, key, decision, user):
        if side not in ("remi", "bene") or decision not in ("approve", "reject", ""):
            raise RunError("Invalid decision.")
        dec = self.meta.setdefault("decisions", {"remi": {}, "bene": {}})
        if decision:
            dec.setdefault(side, {})[key] = decision
        else:
            dec.setdefault(side, {}).pop(key, None)
        self.meta.setdefault("decision_log", []).append(
            {"side": side, "key": key, "decision": decision or "cleared", "user": user, "at": _now()})
        self._mark_stale()

    def suggestion_list(self):
        dec = self.meta.get("decisions") or {}
        return [dict(s, decision=(dec.get(s["side"]) or {}).get(s["key"], ""))
                for s in self.suggestions]

    # ── phase 2 ─────────────────────────────────────────────────
    def generate(self, progress=lambda label, i, n: None):
        self._need()
        self.meta["status"] = "generating"
        self.save_meta()
        self._push_config()
        tee = _Tee(self.say)
        timings = [t for t in self.meta.get("timings", []) if not t.get("phase2")]
        steps = ["Rebuilding derived columns and match keys",
                 "Building SBP Claim and applying equations", "Running control checks",
                 "Writing the final report"]
        t_all = time.time()

        def run_step(i, fn):
            progress(steps[i], i, len(steps))
            t = time.time()
            with contextlib.redirect_stdout(tee):
                res = fn()
            timings.append({"stage": steps[i], "seconds": round(time.time() - t, 2), "phase2": True})
            return res

        def rebuild():
            if self.names_rev != getattr(self, "_sugg_names_rev", 0):
                self.suggestions = engine.commercial_suggestions(self.total)
                self._sugg_names_rev = self.names_rev
            df = self.total
            df = engine.generate_derived_columns(df)
            df = engine._rule_account_review(df)
            df = engine.build_match_keys(df)
            for k, frame in list(self.extra.items()):
                if "Row ID" in frame.columns and len(frame):
                    frame = engine.generate_derived_columns(frame)
                    self.extra[k] = engine.build_match_keys(frame, quiet=True)
            self.total = df
            self._pos = None
        run_step(0, rebuild)

        sbp = run_step(1, lambda: engine.build_sbp_and_equations(self.total))

        order = [engine.TOTAL_SHEET, engine.SBP_SHEET] + engine.SBP_ALWAYS_TABS + [
            engine.SPLIT_SHEET, engine.SPLIT_MAX5_SHEET, engine.ORRE_SHEET_NAME,
            engine.CANCELLED_SHEET_NAME, engine.RDA_OTHER_UNMATCH_SHEET]
        book = collections.OrderedDict()
        book[engine.TOTAL_SHEET] = self.total
        book.update(sbp)
        for k, v in self.extra.items():
            book[k] = v
        for tab in (engine.ORRE_SHEET_NAME, engine.CANCELLED_SHEET_NAME):
            if tab not in book or not len(book[tab]):
                book[tab] = engine._null_frame(self.total.columns)
        book = collections.OrderedDict(
            [(k, book[k]) for k in order if k in book]
            + [(k, v) for k, v in book.items() if k not in order])

        def check():
            # The control checks are shown on the Report screen; they are not
            # written into the workbook.
            self.checks, _summary, _audit = controls.run_checks(self, book)
        run_step(2, check)
        failed = [c for c in self.checks if c["status"] == "FAIL"]
        for c in failed:
            self.say("CONTROL FAILED - %s: %s" % (c["id"], c["detail"]), "error")

        period = re.sub(r"\W+", "_", self.meta.get("period") or "")
        name = "Remittance_Rebate_%s%s.xlsx" % (
            period + "_" if period else "", datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        path = self.p("outputs", name)

        def export():
            return self._export(book, path)
        writer = run_step(3, export)

        timings.append({"stage": "Total - report generation",
                        "seconds": round(time.time() - t_all, 2), "phase2": True})
        self.sheets = book
        size = os.path.getsize(path)
        self.meta.setdefault("outputs", []).insert(0, {
            "file": name, "at": _now(), "size": size, "writer": writer,
            "rows": {k: (0 if engine.is_null_frame(v) else int(len(v))) for k, v in book.items()},
            "failed_checks": len(failed)})
        del self.meta["outputs"][5:]
        keep = {o["file"] for o in self.meta["outputs"]}
        for f in os.listdir(self.p("outputs")):
            if f.endswith(".xlsx") and f not in keep and not f.startswith("Query"):
                with contextlib.suppress(OSError):   # may be open in a download
                    os.remove(self.p("outputs", f))
        self.meta.update(status="generated", timings=timings, stale=False, generated_at=_now(),
                         checks=self.checks)
        self.save_meta()
        progress("Report ready", len(steps), len(steps))
        self.say("Final report ready: %s (%.1f MB, %.1f s)%s"
                 % (name, size / 1e6, time.time() - t_all,
                    "" if not failed else " - %d control check(s) FAILED" % len(failed)),
                 "ok" if not failed else "warn")
        return name

    def _export(self, book, path):
        sheets = []
        for name, frame in book.items():
            cols = [c for c in frame.columns if not str(c).startswith(INTERNAL_PREFIX)]
            sheets.append((name, frame[cols]))
        cells = sum(f.shape[0] * f.shape[1] for _n, f in sheets)
        workers = int(self.settings.get("workers") or 1)
        kw = dict(number_formats=engine.NUMBER_FORMATS, date_columns=engine.DATE_COLUMNS,
                  header_color=engine.OUTPUT_HEADER_COLOR,
                  widths={"Check": 60, "Detail": 90, "Item": 34, "Value": 60})
        t = time.time()
        attempts = [("fast writer, %d processes" % workers,
                     lambda: xlsx_fast.write_workbook(path, sheets, workers=workers, **kw))]
        if workers > 1:
            attempts.append(("fast writer, single process",
                             lambda: xlsx_fast.write_workbook(path, sheets, workers=1, **kw)))
        attempts.append(("compatibility writer",
                         lambda: xlsx_fast.write_workbook_compat(path, sheets, **kw)))
        for label, fn in attempts:
            try:
                fn()
                el = max(time.time() - t, 0.01)
                print("         Workbook written with the %s: %s cells in %.1f s (%.2f M cells/s)"
                      % (label, format(cells, ","), el, cells / 1e6 / el))
                return label
            except Exception as e:
                print("         WARNING: %s failed (%s: %s) - trying the next method"
                      % (label, type(e).__name__, e))
                with contextlib.suppress(OSError):
                    os.remove(path)
        raise RunError("The final workbook could not be written.")

    # ── browsing ────────────────────────────────────────────────
    def page(self, sheet, offset=0, limit=100, q=""):
        if self.sheets is not None and sheet in self.sheets:
            frame = self.sheets[sheet]
        elif sheet == engine.TOTAL_SHEET and self.total is not None:
            frame = self.total
        elif sheet in self.extra:
            frame = self.extra[sheet]
        else:
            raise RunError("Sheet '%s' is not available." % sheet)
        cols = [c for c in frame.columns if not str(c).startswith(INTERNAL_PREFIX)]
        q = _s(q)
        if q:
            m = pd.Series(False, index=frame.index)
            for c in ("Row ID", "URN", "Remitter Name", "Beneficiary Name", "Account No",
                      "CNIC NO.", "R.E", "Check", "Item"):
                if c in frame.columns:
                    m |= frame[c].pipe(engine._sv).str.contains(re.escape(q), case=False, regex=True)
            frame = frame.loc[m]
        part = frame.iloc[offset:offset + limit]
        return {"sheet": sheet, "columns": cols, "total": int(len(frame)),
                "rows": [[_fmt(v) for v in r] for r in part[cols].itertuples(index=False, name=None)]}

    def sheet_names(self):
        if self.sheets is not None:
            return list(self.sheets)
        if self.total is None:
            return []
        return [engine.TOTAL_SHEET] + list(self.extra)

    def delete(self):
        shutil.rmtree(self.root, ignore_errors=True)


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, float):
        if v != v:
            return ""
        return format(v, ",.2f") if not v.is_integer() or abs(v) >= 1000 else str(int(v))
    return _s(v)
