#!/usr/bin/env python3
"""User administration for the Remittance Rebate Calculator.

    manage.py adduser NAME      create an administrator (add --user for a standard user)
    manage.py passwd NAME       change a password
    manage.py deluser NAME      remove a user
    manage.py list              list users
"""
import getpass
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import server


def ask_password():
    if not sys.stdin.isatty():
        pw = sys.stdin.readline().rstrip("\n")
    else:
        pw = getpass.getpass("Password (10 characters or more): ")
        if pw != getpass.getpass("Repeat password: "):
            sys.exit("The passwords do not match.")
    if len(pw) < 10:
        sys.exit("The password must be at least 10 characters.")
    return pw


def main():
    cfg = server.load_settings()
    users = server.load_users(cfg)
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    name = sys.argv[2].strip().lower() if len(sys.argv) > 2 else ""
    if cmd == "list":
        print("\n".join(sorted(users)) or "(no users)")
    elif cmd in ("adduser", "passwd") and name:
        if cmd == "adduser" and name in users:
            sys.exit("User '%s' already exists (use passwd to change the password)." % name)
        if cmd == "passwd" and name not in users:
            sys.exit("No such user: %s" % name)
        if not name.replace(".", "").replace("_", "").replace("-", "").isalnum():
            sys.exit("User names may contain letters, digits, dot, dash and underscore only.")
        role = (users.get(name) or {}).get("role") or ("user" if "--user" in sys.argv else "admin")
        users[name] = server.hash_password(ask_password(), role=role)
        server.save_users(cfg, users)
        print("Saved user '%s'." % name)
    elif cmd == "deluser" and name:
        if users.pop(name, None) is None:
            sys.exit("No such user: %s" % name)
        server.save_users(cfg, users)
        print("Removed user '%s'." % name)
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
