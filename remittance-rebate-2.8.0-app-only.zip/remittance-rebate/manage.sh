#!/bin/bash
# User administration:  ./manage.sh adduser NAME | passwd NAME | deluser NAME | list
cd "$(dirname "$(readlink -f "$0")")"
exec venv/bin/python app/manage.py "$@"
