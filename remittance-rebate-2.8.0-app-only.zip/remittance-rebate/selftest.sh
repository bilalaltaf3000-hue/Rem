#!/bin/bash
# End-to-end check on SYNTHETIC data. Optional row count for a speed
# trial, e.g.  ./selftest.sh 500000
cd "$(dirname "$(readlink -f "$0")")"
exec venv/bin/python tools/selftest.py "$@"
