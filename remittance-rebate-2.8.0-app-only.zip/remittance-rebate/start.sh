#!/bin/bash
# Start the Remittance Rebate Calculator in the background.
cd "$(dirname "$(readlink -f "$0")")"
[ -x venv/bin/python ] || { echo "Run ./setup.sh first."; exit 1; }
mkdir -p data
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then
    echo "Already running (PID $(cat data/server.pid))."; exit 0
fi
nohup venv/bin/python -u app/server.py >> data/server.log 2>&1 &
echo $! > data/server.pid
sleep 3
if kill -0 "$(cat data/server.pid)" 2>/dev/null; then
    tail -n 2 data/server.log
    echo "Started (PID $(cat data/server.pid)). Log: $(pwd)/data/server.log"
else
    echo "The server did not start. Last lines of data/server.log:"; tail -n 15 data/server.log; exit 1
fi
