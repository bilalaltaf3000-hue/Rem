#!/bin/bash
# Remittance Rebate Calculator - offline installation.
# Creates the Python environment from the bundled wheels (no internet
# needed), verifies it, and creates the first user.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
HERE="$(pwd)"

echo "== Remittance Rebate Calculator - setup =="
PY=""
for c in /usr/bin/python3.9 python3.9 python3; do
    if command -v "$c" >/dev/null 2>&1 && \
       [ "$("$c" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null)" = "3.9" ]; then
        PY="$(command -v "$c")"; break
    fi
done
if [ -z "$PY" ]; then
    echo "ERROR: Python 3.9 was not found (RHEL 9 ships it as /usr/bin/python3.9)."
    echo "       The bundled libraries are built for Python 3.9 on x86_64 Linux."
    echo "       Found: $(python3 --version 2>&1 || echo 'no python3')"
    exit 1
fi
if [ "$(uname -m)" != "x86_64" ]; then
    echo "ERROR: this package is built for x86_64; this machine is $(uname -m)."; exit 1
fi
echo "Python:   $PY ($("$PY" --version 2>&1))"
echo "Location: $HERE"

if [ ! -x venv/bin/python ]; then
    echo "Creating the virtual environment ..."
    if ! "$PY" -m venv venv 2>/dev/null; then
        rm -rf venv
        "$PY" -m venv --without-pip venv
    fi
fi
if ! venv/bin/python -m pip --version >/dev/null 2>&1; then
    echo "Bootstrapping pip from the bundled wheel ..."
    PIPWHL="$(ls wheels/pip-*.whl | head -1)"
    venv/bin/python "$PIPWHL/pip" install --quiet --no-index --find-links wheels pip
fi
echo "Installing libraries from ./wheels (offline) ..."
venv/bin/python -m pip install --quiet --disable-pip-version-check --no-index \
    --find-links wheels -r requirements.txt
venv/bin/python - <<'PY'
import numpy, pandas, python_calamine, xlsxwriter, openpyxl
print("Libraries: pandas %s, numpy %s, calamine, xlsxwriter %s, openpyxl %s"
      % (pandas.__version__, numpy.__version__, xlsxwriter.__version__, openpyxl.__version__))
PY

mkdir -p data/runs
chmod 700 data
chmod +x *.sh

if [ "$(venv/bin/python app/manage.py list)" = "(no users)" ]; then
    echo
    echo "Create the administrator account (further users are added in the browser)."
    read -r -p "User name: " U
    venv/bin/python app/manage.py adduser "$U"
fi

PORT="$(venv/bin/python -c 'import json;print(json.load(open("app/config.json"))["port"])')"
echo
echo "Setup complete."
echo "  1. Optional check on synthetic data:   ./selftest.sh"
echo "  2. Start the application:              ./start.sh"
echo "  3. Open in a browser:                  http://$(hostname -f 2>/dev/null || hostname):$PORT/"
echo "If the page does not open from another PC, allow the port (as root):"
echo "     firewall-cmd --permanent --add-port=$PORT/tcp && firewall-cmd --reload"
