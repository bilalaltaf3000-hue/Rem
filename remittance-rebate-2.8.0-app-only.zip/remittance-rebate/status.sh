#!/bin/bash
cd "$(dirname "$(readlink -f "$0")")"
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then
    echo "Running (PID $(cat data/server.pid))."; tail -n 3 data/server.log
else
    echo "Not running."
fi
