"""
Name cleansing check - runs the app's CURRENT cleansing rules on the
channel files of a run and reports what they did to the names.
Nothing in the app or the run is changed.

    python tools/name_check.py                  latest run of this installation
    python tools/name_check.py <run folder>     a specific run
    python tools/name_check.py --grs D:\\files\\grs.xlsx --rh D:\\files\\rh.txt ...
                                                files given directly
                                                (--rh --grs --fm --rimpim; any subset)

Writes name_check.xlsx next to this script and prints a summary.
"""
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "app"))

import pandas as pd
import engine

SAMPLES = 5000      # rows per category sheet, most frequent names first


def words(v):
    return re.sub(r"[^A-Z0-9]+", " ", engine._s(v).upper()).split()


def category(orig, final, link):
    o, f = words(orig), words(final)
    if not f:
        return "Empty after cleansing"
    if engine._s(orig) == engine._s(final):
        return "Unchanged"
    if o == f:
        return "Spacing / case / punctuation only"
    if link and not set(f) & set(o) and f == words(link):
        return "Replaced from LINK TITLE"
    if set(f) <= set(o):
        return "Words removed"
    return "Word cut or changed"


def suspicious(final):
    f = words(final)
    why = []
    if any(ch.isdigit() for ch in engine._s(final)):
        why.append("contains digits")
    if len(f) == 1:
        why.append("single word")
    if f and len("".join(f)) <= 3:
        why.append("3 letters or fewer")
    if any(len(w) == 1 for w in f[:1]):
        why.append("starts with a single letter")
    return ", ".join(why)


def inputs(run):
    def pick(slot):
        d = os.path.join(run, "inputs", slot)
        files = [f for f in os.listdir(d) if not f.endswith(".part")] if os.path.isdir(d) else []
        if not files:
            return None
        return os.path.join(d, files[0]) if len(files) == 1 else d
    return {k: pick(k) for k in ("rh", "fm", "grs", "rimpim")}


def main():
    direct = {}
    args = sys.argv[1:]
    while args and args[0].startswith("--"):
        if len(args) < 2 or args[0][2:] not in ("rh", "fm", "grs", "rimpim"):
            sys.exit("Use --rh, --grs, --fm or --rimpim followed by a file path.")
        if not os.path.exists(args[1]):
            sys.exit("File not found: " + args[1])
        direct[args[0][2:]] = args[1]
        args = args[2:]
    if direct:
        run = None
    elif args:
        run = args[0]
    else:
        runs = os.path.join(HERE, "..", "data", "runs")
        names = sorted(d for d in os.listdir(runs) if os.path.isdir(os.path.join(runs, d)))
        if not names:
            sys.exit("No run found - upload the channel files in the app first.")
        run = os.path.join(runs, names[-1])
    src = {k: direct.get(k) for k in ("rh", "fm", "grs", "rimpim")} if direct else inputs(run)
    print("Run:", os.path.abspath(run) if run else "(files given directly)")
    for k, v in src.items():
        print("  %-7s %s" % (k, v or "(not uploaded)"))

    engine.NAME_WORKERS = max(1, (os.cpu_count() or 2) // 2)
    t = time.time()
    df = engine.consolidate(rh_path=src["rh"], fm_path=src["fm"], grs_path=src["grs"],
                            rimpim_path=src["rimpim"], output_path=None)
    df = engine.cleanse(df)
    print("\nConsolidate + cleanse: %.0f s, %s rows" % (time.time() - t, format(len(df), ",")))

    rows = []
    for col in ("Remitter Name", "Beneficiary Name"):
        flag_col = "_flag " + col if "_flag " + col in df.columns else col + " Flag"
        g = pd.DataFrame({
            "Original": df[engine.COMM_ORIG_PREFIX + col].pipe(engine._sv),
            "Cleansed": df[col].pipe(engine._sv),
            "LINK TITLE": df["LINK TITLE"].pipe(engine._sv) if col == "Beneficiary Name"
            and "LINK TITLE" in df.columns else "",
            "Flag": df[flag_col].pipe(engine._sv) if flag_col in df.columns else "",
            "Channel": df["Channel"].pipe(engine._sv),
        })
        g = (g.groupby(["Original", "Cleansed", "LINK TITLE", "Flag"], sort=False)
              .agg(Rows=("Channel", "size"),
                   Channels=("Channel", lambda s: ", ".join(sorted(set(s)))))
              .reset_index())
        g.insert(0, "Side", col.split()[0])
        rows.append(g)
    names = pd.concat(rows, ignore_index=True)
    names = names[names["Original"].ne("") | names["Cleansed"].ne("")]
    names["Category"] = [category(o, f, l) for o, f, l in
                         zip(names["Original"], names["Cleansed"], names["LINK TITLE"])]
    names["Suspicious"] = names["Cleansed"].map(suspicious)
    names = names.sort_values("Rows", ascending=False)

    order = ["Unchanged", "Spacing / case / punctuation only", "Words removed",
             "Word cut or changed", "Replaced from LINK TITLE", "Empty after cleansing"]
    summ = (names.groupby(["Side", "Category"])
                 .agg(Distinct_names=("Rows", "size"), Transactions=("Rows", "sum"))
                 .reset_index())
    summ["Category"] = pd.Categorical(summ["Category"], order, ordered=True)
    summ = summ.sort_values(["Side", "Category"])
    extra = pd.DataFrame([
        {"Side": side, "Category": label, "Distinct_names": int(m.sum()),
         "Transactions": int(names.loc[m, "Rows"].sum())}
        for side in ("Remitter", "Beneficiary")
        for label, m in (
            ("(any) still flagged for review", (names["Side"] == side) & names["Flag"].ne("")),
            ("(any) suspicious result", (names["Side"] == side) & names["Suspicious"].ne("")))])
    summ = pd.concat([summ, extra], ignore_index=True)

    print("\n%-12s %-36s %14s %14s" % ("Side", "What cleansing did", "Distinct names", "Transactions"))
    for r in summ.itertuples(index=False):
        print("%-12s %-36s %14s %14s" % (r.Side, r.Category, format(r.Distinct_names, ","),
                                          format(r.Transactions, ",")))

    out = os.path.join(HERE, "name_check.xlsx")
    cols = ["Side", "Original", "Cleansed", "Rows", "Channels", "Suspicious", "Flag", "LINK TITLE"]
    with pd.ExcelWriter(out, engine="xlsxwriter") as w:
        summ.to_excel(w, sheet_name="Summary", index=False)
        for sheet, part in (
                ("Word cut or changed", names[names["Category"] == "Word cut or changed"]),
                ("Words removed", names[names["Category"] == "Words removed"]),
                ("Suspicious result", names[names["Suspicious"].ne("")]),
                ("Still flagged", names[names["Flag"].ne("")]),
                ("Replaced from LINK", names[names["Category"] == "Replaced from LINK TITLE"]),
                ("Punctuation only", names[names["Category"] == "Spacing / case / punctuation only"])):
            part[cols].head(SAMPLES).to_excel(w, sheet_name=sheet, index=False)
            w.sheets[sheet].freeze_panes(1, 0)
            w.sheets[sheet].set_column(1, 2, 42)
            w.sheets[sheet].set_column(4, 7, 22)
        w.sheets["Summary"].set_column(0, 1, 36)
    print("\nDetails: " + out)
    print("Each sheet lists the most frequent names first (up to %s)." % format(SAMPLES, ","))


if __name__ == "__main__":
    main()
