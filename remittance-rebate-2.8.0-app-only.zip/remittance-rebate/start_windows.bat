@echo off
rem Test start on a Windows PC (the VM uses setup.sh / start.sh instead).
rem Needs Python 3.9+ with pandas, python-calamine, XlsxWriter and openpyxl installed.
rem Create a user first:  python app\manage.py adduser NAME
cd /d "%~dp0"
python app\server.py
pause
