#!/bin/bash
# Stop the Remittance Rebate Calculator. Work in progress is kept: the
# run is restored from disk the next time the application starts.
cd "$(dirname "$(readlink -f "$0")")"
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then
    kill "$(cat data/server.pid)"; sleep 1
    kill -0 "$(cat data/server.pid)" 2>/dev/null && kill -9 "$(cat data/server.pid)"
    echo "Stopped."
else
    echo "Not running."
fi
rm -f data/server.pid
