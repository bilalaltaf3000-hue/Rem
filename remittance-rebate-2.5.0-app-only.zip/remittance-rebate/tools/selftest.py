#!/usr/bin/env python3
"""End-to-end self-test on SYNTHETIC data (no real customer data needed).

    python tools/selftest.py [ROWS] [--keep]

Builds a full synthetic input set, runs both phases through the same code
the web application uses, exercises the review features, and verifies the
result. ROWS (default 3000) can be raised for a speed trial, e.g. 500000.
"""
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "app"))
sys.path.insert(0, HERE)


def main():
    import pandas as pd
    import engine
    import pipeline
    import make_test_data

    rows = next((int(a) for a in sys.argv[1:] if a.isdigit()), 3000)
    base = os.path.abspath(os.path.join(HERE, "..", "data", "selftest"))
    shutil.rmtree(base, ignore_errors=True)
    src, runs = os.path.join(base, "inputs"), os.path.join(base, "runs")
    os.makedirs(runs)
    cfg = {}
    cfg_path = os.path.join(HERE, "..", "app", "config.json")
    if os.path.exists(cfg_path):
        cfg = json.load(open(cfg_path))
    workers = int(cfg.get("workers") or 0) or min(8, max(1, (os.cpu_count() or 2) // 2))
    fails = []

    def check(name, ok, detail=""):
        print("  [%s] %s%s" % ("ok" if ok else "FAIL", name, (" - " + str(detail)) if detail and not ok else ""))
        if not ok:
            fails.append(name)

    print("1. Generating synthetic inputs (%s rows)..." % format(rows, ","))
    argv, sys.argv = sys.argv, ["make_test_data", src, str(rows)]
    make_test_data.main()
    sys.argv = argv

    print("2. Processing (%d worker process(es))..." % workers)
    run = pipeline.Run.create(runs, "Self-test", "selftest", {"workers": workers})
    single = {"rh": "rh.txt", "grs": "grs.xlsx", "fm": "fm.xlsx", "rimpim": "rimpim.xlsx",
              "entity_list": "entity_list.xlsx", "refunds": "refunds.xlsx",
              "rda_other": "RDA-Other.xlsx", "cnic_oc": "7122.xlsx", "ac_cnic": "DL1534.xlsx"}
    for slot, f in single.items():
        p = os.path.join(src, f)
        with open(p, "rb") as fh:
            run.add_file(slot, f, fh, os.path.getsize(p), "selftest")
    with open(os.path.join(src, "rh_part2.txt"), "rb") as fh:
        run.add_file("rh", "rh_part2.txt", fh, os.path.getsize(os.path.join(src, "rh_part2.txt")), "selftest")
    for slot, d in (("itrs", "ITRS"), ("rda_hbl", "RDA-HBL"), ("commercial", "Commercial")):
        for f in os.listdir(os.path.join(src, d)):
            p = os.path.join(src, d, f)
            with open(p, "rb") as fh:
                run.add_file(slot, f, fh, os.path.getsize(p), "selftest")
    run.meta["usd_rate"] = 280.4673
    run.save_meta()
    run.process()
    n_total = len(run.total)
    check("processing produced a TOTAL sheet", n_total > 0)
    cnt = json.load(open(os.path.join(src, "counts.json")))
    check("every part was read (2 RH files, 2 GRS sheets, a sheet without headings)",
          run.stats["consolidated_rows"] == cnt["rows"]
          and abs(run.stats["consolidated_amount"] - cnt["amount"]) < 1,
          (run.stats["consolidated_rows"], cnt["rows"]))
    n_all = sum(run.query_counts("all").values())
    n_elig = sum(run.query_counts("eligible").values())
    check("review scope 'eligible' leaves out already-excluded transactions",
          0 < n_elig < n_all, (n_elig, n_all))

    print("3. Review features...")
    exp = json.load(open(os.path.join(src, "expected.json")))
    by_tag = {v["tag"]: u for u, v in exp.items()}

    def rid(urn):
        return run.total.loc[run.total["URN"] == urn, "Row ID"].iloc[0]

    def cell(urn, col):
        return engine._s(run.total.loc[run.total["URN"] == urn, col].iloc[0])

    u_cnic = by_tag["OC, CNIC missing -> query file"]
    u_acct = by_tag["AC, bad account length -> query file"]
    u_7122 = by_tag["OC, CNIC from 7122"]
    check("CNIC back-filled from 7122", len(cell(u_7122, "CNIC NO.")) == 13)
    check("missing CNIC is outstanding", cell(u_cnic, "CNIC NO.") == "")
    check("bad account number was blanked", cell(u_acct, "Account No") == "")
    sug = run.suggestion_list()
    check("near-match commercial name is offered for approval",
          any("ZENITH" in s["name"] for s in sug), sug)

    # query file round trip, filled in with openpyxl as a user would in Excel
    import openpyxl
    qpath = os.path.join(base, "query.xlsx")
    counts = run.build_query_workbook(qpath)
    check("query file has a CNIC NO. sheet", "CNIC NO." in counts, counts)
    u_mode = by_tag["clean claim"]
    u_cancel = by_tag["below 200"]
    if rows > 20000:
        # openpyxl needs minutes to re-save a query file this large, so for
        # speed trials write only the touched rows (same layout).
        import xlsxwriter
        book = pd.read_excel(qpath, sheet_name=None, header=None, dtype=str, engine="calamine")
        wbx = xlsxwriter.Workbook(qpath)
        for name, raw in book.items():
            w = wbx.add_worksheet(name)
            if name in ("CNIC NO.", "Account No"):
                keep = raw[raw[0].isin(["Row ID", rid(u_cnic), rid(u_acct)]) | (raw.index == 2)]
            else:
                keep = raw.head(12 if name == pipeline.SHEET_README else 1)
            for i, r in enumerate(keep.itertuples(index=False, name=None)):
                for j, v in enumerate(r):
                    if isinstance(v, str):
                        w.write_string(i, j, v)
        wbx.close()
    wb = openpyxl.load_workbook(qpath)
    ws = wb["CNIC NO."]
    for r in ws.iter_rows(min_row=2):
        if r[0].value == rid(u_cnic):
            r[1].value = "42101-1234567-1"
        elif r[0].value:
            r[1].value = "12345"                      # invalid: must be rejected
    ws = wb["Account No"]
    for r in ws.iter_rows(min_row=2):
        if r[0].value == rid(u_acct):
            r[1].value = "PK36HABB0000421234567890"   # 24 characters -> right 14
    if "Name Review" in wb.sheetnames:
        ws = wb["Name Review"]
        nh = [c.value for c in ws[1]]
        for r in ws.iter_rows(min_row=2):
            if r[nh.index("Original")].value == "Tahir MehmoodMuhammad Butt":
                r[nh.index("Accept Suggestion (Y)")].value = "Y"
    wb[pipeline.SHEET_MODE].append([None, u_mode, "OC"])
    wb[pipeline.SHEET_CANCEL].append([rid(u_cancel), None, "duplicate of another payment"])
    wb.save(qpath)
    rep = run.apply_query_workbook(qpath, "selftest")
    check("CNIC from the query file applied", cell(u_cnic, "CNIC NO.") == "4210112345671", rep)
    check("derived 'Account No / CNIC' follows the new CNIC",
          cell(u_cnic, "Account No / CNIC") in ("", "CNIC - 4210112345671"))
    check("24-character account reduced to 14", cell(u_acct, "Account No") == "00421234567890")
    check("invalid CNIC rejected", any(x["column"] == "CNIC NO." for x in rep["rejected"]), rep["rejected"][:3])
    check("mode amended via 'Change of Mode' sheet", cell(u_mode, "Mode") == "OC")
    check("mode change cleared CNIC-A/C", cell(u_mode, "CNIC-A/C") == "")
    check("row marked cancelled left TOTAL", not (run.total["URN"] == u_cancel).any())
    canc = run.extra[engine.CANCELLED_SHEET_NAME]
    check("cancel reason recorded",
          "duplicate" in engine._s(canc.loc[canc["URN"] == u_cancel, engine.CANCEL_REASON_COL].iloc[0]))

    # on-screen edit, cancel and restore
    r = run.edit(rid(u_mode), {"Mode": "AC"}, "selftest")
    check("mode amended on screen (back to AC) re-ran the account lookup",
          cell(u_mode, "Mode") == "AC" and r["applied"] == 1)
    rr = rid(by_tag["mode CM"])
    run.edit(rr, {"_cancel": True, "_reason": "test"}, "selftest")
    run.edit(rr, {"_restore": True}, "selftest")
    check("cancel then restore returns the row to TOTAL", (run.total["Row ID"] == rr).any()
          and len(run.total) == n_total - 1)

    # everything above must survive a restart
    before = run.total.drop(columns=[c for c in run.total.columns if c.startswith("_")]).astype(str)
    again = pipeline.Run.load(run.root, {"workers": workers})
    after = again.total.drop(columns=[c for c in again.total.columns if c.startswith("_")]).astype(str)
    check("state is identical after a restart (snapshot + journal replay)",
          before.reset_index(drop=True).equals(after.reset_index(drop=True)))
    run = again

    print("3b. Name review...")
    u_abu, u_amp = by_tag["name: Abu Bakar"], by_tag["name: joint with &"]
    u_join = by_tag["name: joined words"]
    u_v1 = by_tag["variant spelling MUHAMMAD ASLAM TESTER"]
    u_v2 = by_tag["variant spelling MOHAMMAD ASLAM TESTER"]
    check("ABU kept at the start of a name", cell(u_abu, "Remitter Name") == "ABU BAKAR SIDDIQ",
          cell(u_abu, "Remitter Name"))
    check("'&' kept as AND", cell(u_amp, "Beneficiary Name") == "BILAL AND RABIA",
          cell(u_amp, "Beneficiary Name"))
    import names_review
    for raw, want in (("FAISAL HABIB MUHAMMAD HABIB", "FAISAL HABIB MUHAMMAD HABIB"),
                      ("MUHAMMAD MOIN FAZAL HABIB", "MUHAMMAD MOIN FAZAL HABIB"),
                      ("HAZRAT BILAL HABIB UL HASSAN", "HAZRAT BILAL HABIB UL HASSAN"),
                      ("MUHAMMAD AFZAL BARAKAT ALI", "MUHAMMAD AFZAL BARAKAT ALI"),
                      ("BABARHANIF MUHAMMAD HANIF", "BABARHANIF MUHAMMAD HANIF"),
                      ("ALI KHAN BANK AL HABIB LTD", "ALI KHAN"),
                      ("FAYSAL KHAN", "FAYSAL KHAN"),
                      ("Farhad Farhad khan", "FARHAD KHAN"),
                      ("MUHAMMAD MUHAMMAD ASLAM", "MUHAMMAD ASLAM"),
                      ("ALI KHAN ALI KHAN", "ALI KHAN"),
                      ("FARZAND ALI", "FARZAND ALI"),
                      ("ALI FARZAND AHMED", "ALI AHMED")):
        got = engine._clean_single_name(raw)
        check("name rule: %s -> %s" % (raw, want), got == want, got)
    if rows <= 20000:
        check("joined words split via the query file (Accept Suggestion = Y)",
              cell(u_join, "Remitter Name") == "TAHIR MEHMOOD MUHAMMAD BUTT",
              cell(u_join, "Remitter Name"))
    else:
        it = [x for x in names_review.items(run, run.data_dir) if x["original"] == "Tahir MehmoodMuhammad Butt"]
        check("joined words detected", it and it[0]["suggestion"] == "TAHIR MEHMOOD MUHAMMAD BUTT", it)
        run.name_decide([{"kind": "name", "key": it[0]["original"], "name": it[0]["suggestion"]}], "selftest")
    cats = {x["original"]: x["cat"] for x in names_review.items(run, run.data_dir)}
    check("name the rules emptied is listed separately", cats.get("NO LAST NAME") == "emptied",
          cats.get("NO LAST NAME"))
    u_link = by_tag["name: joint name replaced from LINK TITLE"]
    check("joint name replaced from LINK TITLE is filed as such",
          cats.get("LIAQUAT ALI KHAN AND HUMERA") == "link", cats.get("LIAQUAT ALI KHAN AND HUMERA"))
    check("a plain joint name is not 'flagged'", cats.get("Bilal & Rabia") != "flagged", cats.get("Bilal & Rabia"))
    run.name_decide([{"kind": "name", "key": "LIAQUAT ALI KHAN AND HUMERA", "name": "@ORIGINAL"}], "selftest")
    check("'Revert to original' restores the name as written",
          cell(u_link, "Beneficiary Name") == "LIAQUAT ALI KHAN AND HUMERA", cell(u_link, "Beneficiary Name"))
    run.name_decide([{"kind": "name", "key": "LIAQUAT ALI KHAN AND HUMERA", "name": "@LINK"}], "selftest")
    check("'Use LINK TITLE' takes the row's account title",
          cell(u_link, "Beneficiary Name") == "LIAQAT /HUMERA", cell(u_link, "Beneficiary Name"))
    u_junk = by_tag["name: garbage, to check in the system"]
    junk = [x for x in names_review.items(run, run.data_dir) if x["original"] == "XXXXX"]
    r = run.name_queue([{"side": "Beneficiary", "key": "XXXXX"}], True, "selftest")
    check("a name can be sent to the query file", r["changed"] == 1 and
          [x["cat"] for x in names_review.items(run, run.data_dir) if x["original"] == "XXXXX"] == ["queued"],
          (junk, r))
    q2 = os.path.join(base, "query2.xlsx")
    run.build_query_workbook(q2)
    wb2 = openpyxl.load_workbook(q2)
    check("query file lists its transactions on 'Names To Check'", "Names To Check" in wb2.sheetnames, wb2.sheetnames)
    if "Names To Check" in wb2.sheetnames:
        ws2 = wb2["Names To Check"]
        hdr = [c.value for c in ws2[1]]
        for rr in ws2.iter_rows(min_row=2):
            if rr[0].value == rid(u_junk):
                rr[hdr.index("Correct Name")].value = "Zahida Parveen"
        wb2.save(q2)
        rep2 = run.apply_query_workbook(q2, "selftest")
        check("the corrected name from 'Names To Check' is applied",
              cell(u_junk, "Beneficiary Name") == "ZAHIDA PARVEEN", (cell(u_junk, "Beneficiary Name"), rep2["rejected"][:3]))
    var = [p for p in names_review.variants(run, run.data_dir) if "ASLAM TESTER" in p["name"]]
    check("spelling variants of the same sender detected", len(var) == 1, var)
    if var:
        r = run.name_decide([{"kind": "variant", "name": var[0]["name"], "to": var[0]["canonical"]}],
                            "selftest")
        check("merging the spellings updated both transactions' names",
              cell(u_v1, "Remitter Name") == cell(u_v2, "Remitter Name") and r["rows"] >= 1, r)
    bad = run.name_decide([{"kind": "name", "key": "X", "name": "<script>"}], "selftest")
    check("an invalid typed name is refused", bad["rejected"] and not bad["applied"], bad)

    print("4. Generating the final report...")
    run.set_cust_types(["CORPORATE"], "selftest")
    run.generate()
    first = {k: v for k, v in run.meta["outputs"][0]["rows"].items()}
    u_near = by_tag["near-match remitter (needs approval)"]
    key = next(s["key"] for s in run.suggestion_list() if "ZENITH" in s["name"])
    run.decide("remi", key, "approve", "selftest")
    name = run.generate()
    out = run.p("outputs", name)

    where = {}
    for sheet, f in run.sheets.items():
        if sheet != "TOTAL" and "URN" in f.columns:
            for u in f["URN"]:
                where.setdefault(str(u), sheet)
    exp[u_cancel]["sheet"] = "Cancelled"
    exp[u_near]["sheet"] = "Reme Comm"
    v_tabs = sorted([where.get(u_v1), where.get(u_v2)])
    check("after the merge, the repeat is caught by the name key", v_tabs == ["SBP Claim", "SPLIT"], v_tabs)
    exp.pop(u_v1)
    exp.pop(u_v2)
    wrong = [(v["tag"], v["sheet"], where.get(u)) for u, v in exp.items() if where.get(u) != v["sheet"]]
    check("all %d designed transactions landed on the expected tab" % len(exp), not wrong, wrong)
    check("approving the near match moved it to Reme Comm",
          run.meta["outputs"][0]["rows"]["Reme Comm"] == first["Reme Comm"] + 1)
    failed = [c for c in run.checks if c["status"] == "FAIL"]
    check("all control checks pass", not failed, failed)

    print("4b. Name decisions are remembered...")
    again = pipeline.Run.load(run.root, {"workers": workers})
    check("name decisions survive a restart",
          again.total.loc[again.total["URN"] == u_join, "Remitter Name"].iloc[0] == "TAHIR MEHMOOD MUHAMMAD BUTT")
    run2 = pipeline.Run.create(runs, "Next month", "selftest", {"workers": workers})
    for slot in ("rh", "grs", "fm", "rimpim", "entity_list"):
        for f in run.files(slot):
            with open(os.path.join(run.slot_dir(slot), f), "rb") as fh:
                run2.add_file(slot, f, fh, os.path.getsize(os.path.join(run.slot_dir(slot), f)), "selftest")
    run2.meta["usd_rate"] = 280.4673
    run2.process()
    n2 = lambda u: engine._s(run2.total.loc[run2.total["URN"] == u, "Remitter Name"].iloc[0])
    check("a new run applies the reviewed names during cleansing",
          n2(u_join) == "TAHIR MEHMOOD MUHAMMAD BUTT" and n2(u_v1) == n2(u_v2), (n2(u_join), n2(u_v1), n2(u_v2)))
    names = pd.ExcelFile(qpath, engine="calamine").sheet_names
    check("query file has Name Review and Spelling Variants sheets",
          "Name Review" in names and "Spelling Variants" in names, names)

    print("5. Reading the workbook back...")
    import zipfile
    small = os.path.getsize(out) < 150e6
    if small:
        check("zip structure is intact", zipfile.ZipFile(out).testzip() is None)
    names = pd.ExcelFile(out, engine="calamine").sheet_names
    need = ["TOTAL", "SBP Claim", "No Claim", "CM", "Below US$200", "Bene Comm", "Reme Comm",
            "HBL UK WORKER PENSION", "RDA", "SPLIT", "MAX 5 SPLIT", "ORRE", "Cancelled",
            "Control Summary", "Audit Trail"]
    check("all tabs present", all(n in names for n in need), names)
    back = pd.read_excel(out, sheet_name="SBP Claim", engine="calamine")
    check("SBP Claim row count matches", len(back) == len(run.sheets["SBP Claim"]))
    check("amounts are numbers", str(back["Amount"].dtype).startswith(("float", "int")))
    check("amount total matches", abs(back["Amount"].sum() - pd.to_numeric(run.sheets["SBP Claim"]["Amount"]).sum()) < 0.5)
    check("dates are real dates", "datetime" in str(back["Upload Date"].dtype), back["Upload Date"].dtype)
    check("long references kept as exact text", back["URN"].astype(str).str.len().max() >= 16
          and not back["URN"].astype(str).str.contains("e\\+", case=False).any())
    check("internal columns not exported", not any(str(c).startswith("_") for c in back.columns))

    print("\nTimings")
    for t in run.meta["timings"]:
        print("  %-48s %8.1f s" % (t["stage"], t["seconds"]))
    print("  writer: %s; file %.1f MB" % (run.meta["outputs"][0]["writer"], os.path.getsize(out) / 1e6))
    if "--keep" not in sys.argv:
        shutil.rmtree(base, ignore_errors=True)
    else:
        print("  kept: " + out)
    print("\nSELF-TEST %s" % ("PASSED" if not fails else "FAILED: " + "; ".join(fails)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
