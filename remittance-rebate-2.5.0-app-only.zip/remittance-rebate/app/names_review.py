"""
Name review: what the cleansing rules did to each distinct name, possible
spelling variants of the same person, and the reviewer's decisions.

Decisions are kept in data/names.json and apply to every run from then
on (the engine applies them during cleansing), so a name is reviewed
once, not every month:

  overrides  original name -> name to use        ("use this name")
  variants   cleansed name -> canonical spelling ("same person as")
  rejected   variant pairs judged NOT the same person

AI suggestions (vLLM) are advisory and checked: an AI-cleaned name is
only offered if it was made by deleting junk or splitting joined words
(engine.ai_name_valid) - it can never change a spelling.
"""
import collections
import datetime
import difflib
import json
import os
import re
import threading

import pandas as pd

import engine

_s = engine._s
NAME_COLS = ["Remitter Name", "Beneficiary Name"]
SIDE = {"Remitter Name": "Remitter", "Beneficiary Name": "Beneficiary"}
COL_OF = {v: k for k, v in SIDE.items()}

CATEGORIES = [
    ("emptied", "Emptied by the rules", "The rules removed every word, so the original name was put back (tidied for case and spacing)"),
    ("cut", "Word cut or changed", "A word in the result is not in the original - most likely a rule mistake"),
    ("removed", "Words removed", "A real word was removed (digits, titles and tags are not counted)"),
    ("joined", "Joined words", "Two names written without a space"),
    ("flagged", "Flagged by the rules", "Joint name, too short, or very long word"),
    ("suspicious", "Suspicious result", "Single word, 3 letters or fewer, or digits"),
    ("link", "Replaced from LINK TITLE", "Beneficiary name taken from the account title (LINK TITLE) because the name was missing or flagged, e.g. a joint name"),
    ("minor", "Minor clean-up", "Only digits, titles, tags or punctuation removed"),
    ("queued", "Sent to query file", "Listed in the query file (sheet Names To Check) to be checked against the system"),
    ("reviewed", "Reviewed", "A decision is recorded for this name"),
]
CAT_LABEL = {k: v for k, v, _d in CATEGORIES}
MINOR_WORDS = {"MR", "MRS", "MS", "MISS", "DR", "SO", "DO", "WO", "CO", "S", "O", "D", "W", "C",
               "BIN", "BINT", "BNT", "IBN", "UMM", "NO", "NAME", "LAST", "FIRST", "CUSTOMER",
               "AC", "ACCOUNT", "ASAAN", "NA", "N", "A", "AA", "NAA", "PH", "MYSELF", "MY",
               "OLD", "SAVING", "SAVINGS", "REMITTANCE", "MIDDLE", "SURNAME", "SINGLE", "JAN",
               "JI", "G", "SONOF", "WIFEOF", "DAUGHTEROF", "SON", "WIFE", "DAUGHTER", "OF"}
AI_NAME_LIMIT = 3000
AI_PAIR_LIMIT = 1000
QUERY_CAP = 20000
_lock = threading.Lock()


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _words(v):
    return re.sub(r"[^A-Z0-9]+", " ", _s(v).upper().replace("&", " AND ")).split()


USE_ORIGINAL = "@ORIGINAL"
USE_LINK = "@LINK"
SPECIAL = {USE_ORIGINAL: "Original name", USE_LINK: "LINK TITLE"}


def clean_input(v):
    """A name typed by a reviewer, in the form the data uses."""
    if _s(v) in SPECIAL:
        return _s(v), None
    v = re.sub(r"\s+", " ", _s(v).upper()).strip()
    if not v:
        return None, "empty"
    if not re.fullmatch(r"[A-Z0-9 .'\-/]+", v):
        return None, "letters, digits, spaces and . ' - / only"
    if len(v) > 120:
        return None, "too long"
    return v, None


# ── the shared decision file ─────────────────────────────────────
def path(data_dir):
    return os.path.join(data_dir, "names.json")


def load(data_dir):
    try:
        with open(path(data_dir), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        d = {}
    for k in ("overrides", "variants", "rejected"):
        d.setdefault(k, {})
    return d


def save(data_dir, d):
    import pipeline
    os.makedirs(data_dir, exist_ok=True)
    tmp = path(data_dir) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, indent=1, ensure_ascii=False)
    pipeline.replace_file(tmp, path(data_dir))


def push(d):
    engine.NAME_OVERRIDES = {k: v["name"] for k, v in d["overrides"].items() if v.get("name")}
    engine.NAME_VARIANTS = {k: v["to"] for k, v in d["variants"].items() if v.get("to")}


def ai_cache_path(data_dir):
    return os.path.join(data_dir, "cache", "ai_names.json")


def load_ai(data_dir):
    try:
        with open(ai_cache_path(data_dir), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        d = {}
    d.setdefault("clean", {})
    d.setdefault("pairs", {})
    return d


def save_ai(data_dir, d):
    import pipeline
    os.makedirs(os.path.dirname(ai_cache_path(data_dir)), exist_ok=True)
    tmp = ai_cache_path(data_dir) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False)
    pipeline.replace_file(tmp, ai_cache_path(data_dir))


# ── analysis ─────────────────────────────────────────────────────
def _vocabulary(total):
    """How often each word occurs in the cleansed names of this run."""
    vc = collections.Counter()
    for col in NAME_COLS:
        if col in total.columns:
            for name, n in total[col].pipe(engine._sv).value_counts().items():
                for w in name.split():
                    vc[w] += int(n)
    return vc


def split_joined(name, vocab, min_freq=30):
    """'TAHIR MEHMOODMUHAMMAD BUTT' -> 'TAHIR MEHMOOD MUHAMMAD BUTT' when
    both halves are common words in this month's names and the joined
    word itself is rare. None when nothing is split."""
    out, changed = [], False
    for w in _s(name).split():
        best = None
        if len(w) >= 8 and vocab.get(w, 0) < 5 and w.isalpha():
            for i in range(3, len(w) - 2):
                a, b = w[:i], w[i:]
                fa, fb = vocab.get(a, 0), vocab.get(b, 0)
                if fa >= min_freq and fb >= min_freq:
                    score = min(fa, fb)
                    if best is None or score > best[0]:
                        best = (score, a + " " + b)
        if best:
            out.append(best[1])
            changed = True
        else:
            out.append(w)
    return " ".join(out) if changed else None


def _category(orig, rule, cur, flag, reviewed, joined, source="", emptied="", queued=False):
    if reviewed:
        return "reviewed"
    if queued:
        return "queued"
    if emptied == "Y":
        return "emptied"
    if source == "LINK TITLE":
        return "link"
    o, r = _words(orig), _words(rule)
    if not r:
        return "suspicious"
    if o != r:
        if not set(r) <= set(o):
            return "link" if not set(r) & set(o) else "cut"
        gone = [w for w in o if w not in set(r)]
        if any(not (w.isdigit() or w in MINOR_WORDS) for w in gone):
            return "removed"
    if joined:
        return "joined"
    # a joint name (X AND Y, X / Y) is a genuine name, not a problem
    if [f for f in _s(flag).split(", ") if f and not f.startswith("Joint name")]:
        return "flagged"
    if any(ch.isdigit() for ch in rule) or len(r) == 1 or len("".join(r)) <= 3:
        return "suspicious"
    return "minor" if o != r else None


_build = threading.RLock()


def _key(run):
    return (getattr(run, "total_ver", 0), run.names_rev)


def items(run, data_dir):
    """Distinct names with their rule result and review category."""
    cache = getattr(run, "_names_cache", None)
    if cache and cache[0] == _key(run):
        return cache[1]
    with _build:
        cache = getattr(run, "_names_cache", None)
        if cache and cache[0] == _key(run):
            return cache[1]
        return _build_items(run, data_dir)


def _build_items(run, data_dir):
    key = _key(run)
    vocab = _vocabulary(run.total)
    rows = _item_rows(run, data_dir, vocab)
    rows.sort(key=lambda x: -x["rows"])
    run._names_vocab = vocab
    run._names_cache = (key, rows)
    return rows


def queue_of(run):
    return run.meta.setdefault("name_queue", {})


def _item_rows(run, data_dir, vocab, only=None):
    """Review items for all rows, or (only={column: mask}) for some."""
    dec = load(data_dir)
    ai = load_ai(data_dir)["clean"]
    queue = queue_of(run)
    rows = []
    for col in NAME_COLS:
        oc = engine.COMM_ORIG_PREFIX + col
        if col not in run.total.columns or oc not in run.total.columns:
            continue
        t = run.total if only is None else run.total.loc[only[col]]
        if not len(t):
            continue
        g = pd.DataFrame({
            "o": t[oc].pipe(engine._sv),
            "r": (t["_rule " + col] if "_rule " + col in t.columns else t[col]).pipe(engine._sv),
            "c": t[col].pipe(engine._sv),
            "f": (t["_flag " + col] if "_flag " + col in t.columns else
                  pd.Series("", index=t.index)).pipe(engine._sv),
            "l": (t["_src " + col] if "_src " + col in t.columns else
                  pd.Series("", index=t.index)).pipe(engine._sv),
            "e": (t["_emptied " + col] if "_emptied " + col in t.columns else
                  pd.Series("", index=t.index)).pipe(engine._sv)})
        keys6 = ["o", "r", "c", "f", "l", "e"]
        if col == "Beneficiary Name" and "LINK TITLE" in t.columns:
            g["lt"] = engine._clean_names_series(t["LINK TITLE"]).pipe(engine._sv)
        else:
            g["lt"] = ""
        g = g[g["o"].ne("") | g["c"].ne("")]
        n_rows = g.groupby(keys6, sort=False).size().rename("n")
        lt = g[g["lt"].ne("")].drop_duplicates(keys6 + ["lt"])
        lt_first = lt.groupby(keys6, sort=False)["lt"].first().rename("lt")
        lt_n = lt.groupby(keys6, sort=False)["lt"].size().rename("lt_n")
        g = pd.concat([n_rows, lt_first, lt_n], axis=1).reset_index()
        g["lt"] = g["lt"].fillna("")
        g["lt_n"] = g["lt_n"].fillna(0).astype(int)
        for o, r, c, f, l, e, n, ltv, ltn in g[keys6 + ["n", "lt", "lt_n"]].itertuples(
                index=False, name=None):
            k = engine.name_key(o)
            reviewed = k in dec["overrides"] or (r != c and r in dec["variants"])
            joined = split_joined(r, vocab) if not reviewed else None
            cat = _category(o, r, c, f, reviewed, joined, l, e,
                            (SIDE[col] + "|" + k) in queue)
            if cat is None:
                continue
            a = ai.get(k)
            sugg, by = (joined, "word split") if joined else (None, "")
            ai_note = ""
            if a and a.get("rule") == r:
                if a.get("status") == "differs":
                    sugg, by = a["name"], "AI"
                ai_note = {"agrees": "AI agrees", "differs": "AI suggests a change",
                           "rejected": "AI answer rejected (it changed the spelling)"}.get(
                    a.get("status"), "")
            rows.append({"side": SIDE[col], "key": k, "original": o, "rule": r, "current": c,
                         "flag": f, "source": l, "emptied": e, "rows": int(n), "cat": cat,
                         "link": ltv, "links": int(ltn), "suggestion": sugg or "",
                         "by": by, "ai": ai_note,
                         "decision": (dec["overrides"].get(k) or {}).get("name", "")})
    return rows


def _alike(a, b):
    """Same words apart from spacing, or the same number of words with
    every word spelled nearly the same (MUHAMMAD/MOHAMMAD yes,
    ASLAM/SALEEM no)."""
    if a.replace(" ", "") == b.replace(" ", ""):
        return True
    wa, wb = a.split(), b.split()
    if len(wa) != len(wb):
        return False
    for x, y in zip(wa, wb):
        if x != y and difflib.SequenceMatcher(None, x, y).ratio() < 0.75:
            return False
    return True


def variants(run, data_dir):
    """Possible spelling variants of the same person: names that sound
    alike AND appear with the same R.E and the same counterpart (the
    other side's name). The more frequent spelling is proposed."""
    cache = getattr(run, "_variants_cache", None)
    if cache and cache[0] == _key(run):
        return cache[1]
    with _build:
        cache = getattr(run, "_variants_cache", None)
        if cache and cache[0] == _key(run):
            return cache[1]
        return _build_variants(run, data_dir)


def _build_variants(run, data_dir):
    key = _key(run)
    dec = load(data_dir)
    ai = load_ai(data_dir)["pairs"]
    t = run.total
    re_name = t["R.E Name"].pipe(engine._sv) if "R.E Name" in t.columns else ""
    freq = collections.Counter()
    for col in NAME_COLS:
        freq.update({k: int(v) for k, v in t[col].pipe(engine._sv).value_counts().items()})
    words = _vocabulary(t)
    pairs = {}
    for col, other in (("Remitter Name", "Beneficiary Name"), ("Beneficiary Name", "Remitter Name")):
        if col not in t.columns or other not in t.columns:
            continue
        n = t[col].pipe(engine._sv)
        o = t[other].pipe(engine._sv)
        d = pd.DataFrame({"n": n, "c": re_name + "|" + o})[n.ne("") & o.ne("")].drop_duplicates()
        d = d[d.groupby("c")["n"].transform("size") >= 2]
        d["s"] = d["n"].pipe(engine._mu, engine.name_skeleton)
        d = d[d["s"].str.len() >= 3]
        d = d[d.groupby(["c", "s"])["n"].transform("nunique") >= 2]
        for (_c, _s2), names in d.groupby(["c", "s"])["n"]:
            names = sorted(set(names), key=lambda x: (-freq[x], -sum(words.get(w, 0)
                                                                     for w in x.split()), x))
            canon = names[0]
            for v in names[1:]:
                if not _alike(canon, v):
                    continue
                pk = v + "|" + canon
                if pk in dec["rejected"] or v in dec["variants"]:
                    continue
                p = pairs.setdefault(pk, {"side": SIDE[col], "name": v, "canonical": canon,
                                          "rows": freq[v], "canonical_rows": freq[canon],
                                          "contexts": 0})
                p["contexts"] += 1
    out = sorted(pairs.values(), key=lambda p: (-p["contexts"], -p["rows"]))
    for p in out:
        a = ai.get(p["name"] + "|" + p["canonical"])
        p["ai"] = (a or {}).get("same", "")
        p["ai_reason"] = (a or {}).get("reason", "")
    run._variants_cache = (key, out)
    return out


def summary(run, data_dir):
    it = items(run, data_dir)
    counts = collections.Counter(x["cat"] for x in it)
    rows = collections.Counter()
    for x in it:
        rows[x["cat"]] += x["rows"]
    var = variants(run, data_dir)
    dec = load(data_dir)
    return {"categories": [{"id": k, "label": v, "hint": h, "names": counts.get(k, 0),
                            "rows": rows.get(k, 0)} for k, v, h in CATEGORIES],
            "variants": len(var), "variant_rows": sum(p["rows"] for p in var),
            "dictionary": {"overrides": len(dec["overrides"]), "variants": len(dec["variants"])},
            "ai_pending": sum(1 for x in it if x["cat"] not in ("reviewed", "minor") and not x["ai"])}


SORTS = {
    "rows": lambda x: -x.get("rows", 0),
    "rows_asc": lambda x: x.get("rows", 0),
    "sugg": lambda x: (0 if x.get("suggestion") else 1, -x.get("rows", 0)),
    "sugg_last": lambda x: (1 if x.get("suggestion") else 0, -x.get("rows", 0)),
    "ai": lambda x: (0 if x.get("by") == "AI" else 1 if x.get("ai") else 2, -x.get("rows", 0)),
    "ai_last": lambda x: (2 if x.get("by") == "AI" else 1 if x.get("ai") else 0, -x.get("rows", 0)),
    "name": lambda x: x.get("original") or x.get("name", ""),
}
FILTERS = {
    "all": lambda x: True,
    "sugg": lambda x: bool(x.get("suggestion")),
    "nosugg": lambda x: not x.get("suggestion"),
    "ai": lambda x: x.get("by") == "AI",
    "split": lambda x: x.get("by") == "word split",
    "ai_agrees": lambda x: x.get("ai") == "AI agrees",
    "ai_rejected": lambda x: "rejected" in x.get("ai", ""),
    "link": lambda x: bool(x.get("link")),
    "nolink": lambda x: not x.get("link"),
    "remitter": lambda x: x.get("side") == "Remitter",
    "beneficiary": lambda x: x.get("side") == "Beneficiary",
    "ai_yes": lambda x: x.get("ai") == "yes",
    "ai_no": lambda x: x.get("ai") == "no",
}


def page(run, data_dir, cat, offset, limit, q="", sort="rows", filt="all"):
    q = _s(q).upper()
    if cat == "variants":
        rows = variants(run, data_dir)
        if q:
            rows = [p for p in rows if q in p["name"] or q in p["canonical"]]
    else:
        rows = [x for x in items(run, data_dir) if x["cat"] == cat]
        if q:
            rows = [x for x in rows if q in x["original"].upper() or q in x["current"]
                    or q in x.get("link", "")]
    f = FILTERS.get(filt)
    if f and filt != "all":
        rows = [x for x in rows if f(x)]
    if sort in SORTS and sort != "rows":
        rows = sorted(rows, key=SORTS[sort])
    return {"cat": cat, "total": len(rows), "rows": rows[offset:offset + limit]}


# ── applying decisions to the open run ──────────────────────────
def recompute(run, mask):
    """Re-derive the name columns of the masked rows from the original
    name, the rule result and the current decisions."""
    n = 0
    for col in NAME_COLS:
        oc, rc = engine.COMM_ORIG_PREFIX + col, "_rule " + col
        if col not in run.total.columns or oc not in run.total.columns:
            continue
        m = mask if not isinstance(mask, dict) else mask[col]
        if not m.any():
            continue
        rule = run.total.loc[m, rc] if rc in run.total.columns else run.total.loc[m, col]
        link = None
        if col == "Beneficiary Name" and "LINK TITLE" in run.total.columns:
            link = engine._clean_names_series(run.total.loc[m, "LINK TITLE"])
        new = engine.apply_name_dictionary(run.total.loc[m, oc], rule, link)
        n += int(new.pipe(engine._sv).ne(run.total.loc[m, col].pipe(engine._sv)).sum())
        run.total.loc[m, col] = new
        run.total.loc[m, "_flag " + col] = engine._flag_names(new)
    return n


def affected(run, keys=(), names=()):
    keys, names = set(keys), set(names)
    masks = {}
    for col in NAME_COLS:
        oc, rc = engine.COMM_ORIG_PREFIX + col, "_rule " + col
        m = pd.Series(False, index=run.total.index)
        if keys and oc in run.total.columns:
            m |= run.total[oc].pipe(engine._mu, engine.name_key).isin(keys)
        if names:
            m |= run.total[col].pipe(engine._sv).isin(names)
            if rc in run.total.columns:
                m |= run.total[rc].pipe(engine._sv).isin(names)
        masks[col] = m
    return masks


def decide(run, data_dir, decisions, user, source):
    """decisions: list of
         {"kind": "name", "key": k, "name": "..."}         use this name
         {"kind": "name", "key": k, "name": None}          undo
         {"kind": "variant", "name": v, "to": c}           same person
         {"kind": "variant", "name": v, "to": None}        undo
         {"kind": "reject", "name": v, "to": c}            not the same person
    Returns (applied journal entries, rejected [(decision, reason)])."""
    with _lock:
        d = load(data_dir)
        keys, names, entries, bad = set(), set(), [], []
        stamp = _now()
        for x in decisions:
            kind = x.get("kind")
            if kind == "name":
                k = engine.name_key(x.get("key"))
                if not k:
                    bad.append((x, "no original name"))
                    continue
                if x.get("name") in (None, ""):
                    if d["overrides"].pop(k, None) is None:
                        continue
                    new = None
                else:
                    new, why = clean_input(x["name"])
                    if why:
                        bad.append((x, why))
                        continue
                    if (d["overrides"].get(k) or {}).get("name") == new:
                        continue
                    d["overrides"][k] = {"name": new, "by": user, "at": stamp, "source": source}
                keys.add(k)
                entries.append({"action": "names", "kind": "name", "key": k, "new": new,
                                "column": "Name", "old": x.get("rule", ""), "row_id": "",
                                "urn": "", "rows": 0})
            elif kind in ("variant", "reject"):
                v, c = _s(x.get("name")).upper(), _s(x.get("to")).upper()
                if not v:
                    continue
                if kind == "reject":
                    d["rejected"][v + "|" + c] = {"by": user, "at": stamp}
                    entries.append({"action": "names", "kind": "reject", "key": v, "new": c,
                                    "column": "Spelling", "old": v, "row_id": "", "urn": "",
                                    "rows": 0})
                    continue
                if not c:
                    if d["variants"].pop(v, None) is None:
                        continue
                    names.add(v)
                else:
                    c = (d["variants"].get(c) or {}).get("to") or c       # no chains
                    if c == v:
                        continue
                    d["variants"][v] = {"to": c, "by": user, "at": stamp, "source": source}
                    for other, rec in d["variants"].items():
                        if rec.get("to") == v:
                            rec["to"] = c
                    names.update({v, c})
                entries.append({"action": "names", "kind": "variant", "key": v, "new": c or None,
                                "column": "Spelling", "old": v, "row_id": "", "urn": "",
                                "rows": 0})
        save(data_dir, d)
        push(d)
    masks = affected(run, keys, names) if (keys or names) else {}
    n = recompute(run, masks) if masks else 0
    if entries:
        entries[-1]["rows"] = n
    if any(e["kind"] == "variant" and not e["new"] for e in entries):
        run._variants_stale = True          # an undone merge may bring a pair back
    _patch(run, d, masks)
    return entries, bad


def set_queue(run, data_dir, selection, on, user):
    """Add names to (on=True) or take them off (on=False) the query
    file's Names To Check sheet. selection: [{"side", "key"}] or
    {"cat": category} for a whole list. Returns how many changed."""
    q = queue_of(run)
    if isinstance(selection, dict) and selection.get("cat"):
        chosen = [(x["side"], x["key"]) for x in items(run, data_dir)
                  if x["cat"] == selection["cat"]]
    else:
        chosen = [(_s(x.get("side")), engine.name_key(x.get("key"))) for x in selection or []]
    n = 0
    stamp = _now()
    for side, k in chosen:
        if side not in COL_OF or not k:
            continue
        tag = side + "|" + k
        if on and tag not in q:
            q[tag] = {"by": user, "at": stamp}
            n += 1
        elif not on and q.pop(tag, None) is not None:
            n += 1
    if n:
        keys_by_side = collections.defaultdict(set)
        for side, k in chosen:
            keys_by_side[COL_OF.get(side)].add(k)
        masks = {}
        for col in NAME_COLS:
            oc = engine.COMM_ORIG_PREFIX + col
            ks = keys_by_side.get(col)
            masks[col] = (run.total[oc].pipe(engine._mu, engine.name_key).isin(ks)
                          if ks and oc in run.total.columns
                          else pd.Series(False, index=run.total.index))
        _patch(run, load(data_dir), masks)
    return n


def _patch(run, d, masks):
    """Bring the cached lists up to date after decisions, without
    rebuilding them from the whole dataset (which takes seconds on a
    full month): the items of the rows involved are rebuilt and swapped
    in. Spelling variants are rebuilt only when a merge is undone."""
    with _build:
        old = _key(run)
        run.names_rev += 1
        new = _key(run)
        ic = getattr(run, "_names_cache", None)
        vocab = getattr(run, "_names_vocab", None)
        if ic and ic[0] == old and vocab is not None and masks:
            touched = set()
            for col, m in masks.items():
                oc = engine.COMM_ORIG_PREFIX + col
                if m.any() and oc in run.total.columns:
                    touched |= {(SIDE[col], k) for k in
                                run.total.loc[m, oc].pipe(engine._mu, engine.name_key).unique()}
            fresh = _item_rows(run, run.data_dir, vocab, masks) if touched else []
            rows = [x for x in ic[1] if (x["side"], x["key"]) not in touched] + fresh
            rows.sort(key=lambda x: -x["rows"])
            run._names_cache = (new, rows)
        elif ic and ic[0] == old:
            run._names_cache = (new, ic[1])
        vc = getattr(run, "_variants_cache", None)
        if vc and vc[0] == old and not getattr(run, "_variants_stale", False):
            merged = set(d["variants"])
            pairs = [p for p in vc[1] if p["name"] not in merged and p["canonical"] not in merged
                     and (p["name"] + "|" + p["canonical"]) not in d["rejected"]]
            run._variants_cache = (new, pairs)
        run._variants_stale = False

def replay(run, entries):
    """After a restart: re-apply name decisions recorded in the journal."""
    keys = {e["key"] for e in entries if e.get("kind") == "name"}
    names = set()
    for e in entries:
        if e.get("kind") == "variant":
            names.add(e["key"])
            if e.get("new"):
                names.add(e["new"])
    if keys or names:
        recompute(run, affected(run, keys, names))
    run.names_rev += 1


# ── AI check ─────────────────────────────────────────────────────
NAME_PROMPT = (
    "You clean person names from Pakistani remittance records. For each line you get the "
    "ORIGINAL text and the result of the bank's cleaning rules. Return the correct clean "
    "name: upper case; remove only junk (digits, phone or account numbers, bank or account "
    "words, 'S/O', 'D/O', 'W/O', titles like MR/MRS/DR, placeholder text like NO LAST NAME); "
    "split words that were joined without a space (MEHMOODMUHAMMAD -> MEHMOOD MUHAMMAD); keep "
    "every real name word, including ABU, SYED, MALIK, BIBI, KHAN; keep joint names with AND. "
    "NEVER change the spelling of a word and never add a word. If the rule result is already "
    "right, return it unchanged. Answer ONLY with a JSON array, same order: "
    '{"n": <number>, "name": "<clean name>"}')

PAIR_PROMPT = (
    "Each line has two spellings of a name seen on remittances from the same sender to the "
    "same receiver. Say whether they are the SAME person written differently (typo, spacing, "
    "common spelling variant such as MUHAMMAD / MOHAMMAD) or DIFFERENT people (a different "
    "name, e.g. FAISAL vs FAZAL, or a different family name). Answer ONLY with a JSON array, "
    'same order: {"n": <number>, "same": "yes" | "no" | "unsure", "reason": "<max 10 words>"}')


def _parse(text):
    m = re.search(r"\[.*\]", text, flags=re.S)
    try:
        return {int(i.get("n", 0)): i for i in json.loads(m.group(0) if m else text)}
    except Exception:
        return {}


def ai_check(run, data_dir, settings, progress=lambda label, i, n: None):
    """Ask the model about the names still to review and the spelling
    variants. Results are cached across runs (data/cache/ai_names.json)."""
    import concurrent.futures as cf
    import ai_assist
    st = ai_assist.status(settings)
    if not st["available"]:
        raise RuntimeError(st["detail"])
    cache = load_ai(data_dir)
    todo, seen = [], set()
    for x in items(run, data_dir):
        if x["cat"] in ("reviewed", "minor") or x["key"] in seen:
            continue
        a = cache["clean"].get(x["key"])
        if a and a.get("rule") == x["rule"]:
            continue
        seen.add(x["key"])
        todo.append(x)
        if len(todo) >= AI_NAME_LIMIT:
            break
    pairs = [p for p in variants(run, data_dir)
             if (p["name"] + "|" + p["canonical"]) not in cache["pairs"]][:AI_PAIR_LIMIT]
    blocks = [("names", todo[i:i + 25]) for i in range(0, len(todo), 25)]
    blocks += [("pairs", pairs[i:i + 25]) for i in range(0, len(pairs), 25)]
    if not blocks:
        return 0, 0

    def ask(block):
        kind, part = block
        if kind == "names":
            prompt = "\n".join('%d. ORIGINAL: "%s"  RULE RESULT: "%s"' % (i + 1, x["original"], x["rule"])
                               for i, x in enumerate(part))
            return kind, part, _parse(ai_assist.chat(settings, NAME_PROMPT, prompt,
                                                     max_tokens=40 * len(part) + 100))
        prompt = "\n".join('%d. "%s"  |  "%s"' % (i + 1, p["name"], p["canonical"])
                           for i, p in enumerate(part))
        return kind, part, _parse(ai_assist.chat(settings, PAIR_PROMPT, prompt,
                                                 max_tokens=40 * len(part) + 100))

    done_n = done_p = errors = 0
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(ask, b) for b in blocks]
        for i, f in enumerate(cf.as_completed(futs)):
            progress("Asking the model about names (%d of %d batches)" % (i + 1, len(blocks)),
                     i, len(blocks))
            try:
                kind, part, got = f.result()
            except Exception:
                errors += 1
                continue
            for j, x in enumerate(part):
                item = got.get(j + 1) or {}
                if kind == "names":
                    name = re.sub(r"\s+", " ", _s(item.get("name")).upper()).strip()
                    if not name:
                        continue
                    status = ("agrees" if name == x["rule"] else
                              "differs" if engine.ai_name_valid(x["original"], name) else "rejected")
                    cache["clean"][x["key"]] = {"rule": x["rule"], "name": name, "status": status}
                    done_n += 1
                else:
                    same = _s(item.get("same")).lower()
                    cache["pairs"][x["name"] + "|" + x["canonical"]] = {
                        "same": same if same in ("yes", "no", "unsure") else "unsure",
                        "reason": _s(item.get("reason"))[:120]}
                    done_p += 1
            if (i + 1) % 20 == 0:
                save_ai(data_dir, cache)
    save_ai(data_dir, cache)
    run.names_rev += 1
    if errors and not (done_n or done_p):
        raise RuntimeError("The model did not answer any request.")
    return done_n, done_p


# ── query file sheets ───────────────────────────────────────────
SHEET_NAMES = "Name Review"
SHEET_VARIANTS = "Spelling Variants"
SHEET_CHECK = "Names To Check"
USE_CHOICES = {"ORIGINAL": USE_ORIGINAL, "LINK TITLE": USE_LINK}
NAME_HEAD = ["Side", "Original", "Rule Result", "LINK TITLE", "Suggestion", "Suggested By",
             "Category", "Transactions", "Accept Suggestion (Y)", "Use Original / LINK TITLE",
             "Use Name"]
NAME_AMBER = 8
VAR_HEAD = ["Side", "Name", "Same Person As", "Transactions", "Seen Together", "AI Opinion",
            "Same Person? (Y/N)"]
CHECK_INFO = ["URN", "R.E Name", "Amount", "Upload Date", "Mode", "Account No", "CNIC NO.",
              "CNIC-A/C", "Remitter ID", "Channel"]
CHECK_HEAD = ["Row ID", "Side", "Original", "Current Name", "LINK TITLE"] + CHECK_INFO + ["Correct Name"]
CHECK_CAP = 200000


def write_sheets(run, data_dir, wb, fmt):
    """Add the name sheets to the query workbook (xlsxwriter)."""
    rows = [x for x in items(run, data_dir)
            if x["cat"] not in ("reviewed", "minor", "queued", "none")][:QUERY_CAP]
    ws = wb.add_worksheet(SHEET_NAMES)
    ws.freeze_panes(1, 3)
    ws.set_row(0, 30)
    for j, h in enumerate(NAME_HEAD):
        amber = j >= NAME_AMBER
        ws.write_string(0, j, h, fmt["head_in"] if amber else fmt["head"])
        ws.set_column(j, j, 34 if j in (1, 2, 3, 4) else 18 if amber else 13,
                      fmt["cell_in"] if amber else None)
    for i, x in enumerate(rows, start=1):
        link = x.get("link", "") + (" (+%d more)" % (x["links"] - 1) if x.get("links", 0) > 1 else "")
        vals = [x["side"], x["original"], x["rule"], link, x["suggestion"], x["by"] or x["ai"],
                CAT_LABEL.get(x["cat"], x["cat"])]
        for j, v in enumerate(vals):
            if v:
                ws.write_string(i, j, v)
        ws.write_number(i, 7, x["rows"])
    if rows:
        ws.autofilter(0, 0, len(rows), len(NAME_HEAD) - 1)
        ws.data_validation(1, NAME_AMBER, len(rows), NAME_AMBER, {"validate": "list", "source": ["Y"]})
        ws.data_validation(1, NAME_AMBER + 1, len(rows), NAME_AMBER + 1,
                           {"validate": "list", "source": list(USE_CHOICES)})
    var = variants(run, data_dir)[:QUERY_CAP]
    ws = wb.add_worksheet(SHEET_VARIANTS)
    ws.freeze_panes(1, 3)
    ws.set_row(0, 30)
    for j, h in enumerate(VAR_HEAD):
        amber = j == 6
        ws.write_string(0, j, h, fmt["head_in"] if amber else fmt["head"])
        ws.set_column(j, j, 34 if j in (1, 2) else 18 if amber else 13, fmt["cell_in"] if amber else None)
    for i, p in enumerate(var, start=1):
        for j, v in enumerate([p["side"], p["name"], p["canonical"]]):
            ws.write_string(i, j, v)
        ws.write_number(i, 3, p["rows"])
        ws.write_number(i, 4, p["contexts"])
        if p["ai"]:
            ws.write_string(i, 5, p["ai"] + (" - " + p["ai_reason"] if p["ai_reason"] else ""))
    if var:
        ws.autofilter(0, 0, len(var), len(VAR_HEAD) - 1)
        ws.data_validation(1, 6, len(var), 6, {"validate": "list", "source": ["Y", "N"]})
    out = {SHEET_NAMES: len(rows), SHEET_VARIANTS: len(var)}

    # every transaction of the names sent for checking, one row each
    q = queue_of(run)
    if q:
        t = run.total
        parts = []
        for col in NAME_COLS:
            oc = engine.COMM_ORIG_PREFIX + col
            ks = {tag.split("|", 1)[1] for tag in q if tag.split("|", 1)[0] == SIDE[col]}
            if not ks or oc not in t.columns:
                continue
            m = t[oc].pipe(engine._mu, engine.name_key).isin(ks)
            if not m.any():
                continue
            sub = t.loc[m]
            part = pd.DataFrame({"Row ID": sub["Row ID"], "Side": SIDE[col],
                                 "Original": sub[oc].pipe(engine._sv),
                                 "Current Name": sub[col].pipe(engine._sv),
                                 "LINK TITLE": (sub["LINK TITLE"].pipe(engine._sv)
                                                if col == "Beneficiary Name" and "LINK TITLE" in sub
                                                else "")})
            for c in CHECK_INFO:
                part[c] = sub[c] if c in sub.columns else None
            parts.append(part)
        if parts:
            chk = pd.concat(parts, ignore_index=True).sort_values(["Side", "Original", "Row ID"])
            if len(chk) > CHECK_CAP:
                run.say("Query file: %s transactions to check - the first %s are listed."
                        % (format(len(chk), ","), format(CHECK_CAP, ",")), "warn")
                chk = chk.head(CHECK_CAP)
            ws = wb.add_worksheet(SHEET_CHECK)
            ws.freeze_panes(1, 4)
            ws.set_row(0, 30)
            last = len(CHECK_HEAD) - 1
            for j, h in enumerate(CHECK_HEAD):
                amber = j == last
                ws.write_string(0, j, h, fmt["head_in"] if amber else fmt["head"])
                ws.set_column(j, j, 30 if h in ("Original", "Current Name", "LINK TITLE")
                              else 34 if amber else 14, fmt["cell_in"] if amber else None)
            cols = CHECK_HEAD[:-1]
            for i, r in enumerate(chk[cols].itertuples(index=False, name=None), start=1):
                for j, v in enumerate(r):
                    if cols[j] == "Amount" and isinstance(v, (int, float)) and v == v:
                        ws.write_number(i, j, v)
                    else:
                        v = _s(v)
                        if v:
                            ws.write_string(i, j, v)
            ws.autofilter(0, 0, len(chk), last)
            out[SHEET_CHECK] = len(chk)
    return out


def read_sheets(book):
    """Decisions found in an uploaded query workbook (calamine frames,
    header=None). Returns (decisions, row corrections, rejected rows);
    a row correction is (row_id, column, typed name)."""
    out, fixes, bad = [], [], []
    for sheet, head in ((SHEET_NAMES, NAME_HEAD), (SHEET_VARIANTS, VAR_HEAD),
                        (SHEET_CHECK, CHECK_HEAD)):
        raw = book.get(sheet)
        if raw is None or len(raw) < 2:
            continue
        hdr = [_s(v) for v in raw.iloc[0].tolist()]
        col = {h: hdr.index(h) for h in head if h in hdr}
        need = head if sheet != SHEET_CHECK else ["Row ID", "Side", "Correct Name"]
        if any(h not in col for h in need):
            bad.append({"sheet": sheet, "row_id": "", "column": "", "value": "",
                        "reason": "headings were changed - sheet ignored"})
            continue
        for r in raw.iloc[1:].itertuples(index=False, name=None):
            g = lambda h: _s(r[col[h]]) if h in col and col[h] < len(r) else ""
            if sheet == SHEET_NAMES:
                use, acc = g("Use Name"), g("Accept Suggestion (Y)").upper()
                pick = g("Use Original / LINK TITLE").upper()
                if pick:
                    if pick not in USE_CHOICES:
                        bad.append({"sheet": sheet, "row_id": "", "column": "Use Original / LINK TITLE",
                                    "value": pick, "reason": "choose ORIGINAL or LINK TITLE"})
                        continue
                    out.append({"kind": "name", "key": g("Original"), "name": USE_CHOICES[pick],
                                "rule": g("Rule Result")})
                    continue
                if not use and acc not in ("Y", "YES"):
                    if acc:
                        bad.append({"sheet": sheet, "row_id": "", "column": "Accept Suggestion (Y)",
                                    "value": acc, "reason": "type Y to accept"})
                    continue
                name = use or g("Suggestion")
                if not name:
                    bad.append({"sheet": sheet, "row_id": "", "column": "Accept Suggestion (Y)",
                                "value": g("Original"), "reason": "there is no suggestion to accept"})
                    continue
                out.append({"kind": "name", "key": g("Original"), "name": name, "rule": g("Rule Result")})
            elif sheet == SHEET_VARIANTS:
                yn = g("Same Person? (Y/N)").upper()
                if yn in ("Y", "YES"):
                    out.append({"kind": "variant", "name": g("Name"), "to": g("Same Person As")})
                elif yn in ("N", "NO"):
                    out.append({"kind": "reject", "name": g("Name"), "to": g("Same Person As")})
                elif yn:
                    bad.append({"sheet": sheet, "row_id": "", "column": "Same Person? (Y/N)",
                                "value": yn, "reason": "type Y or N"})
            else:
                v = g("Correct Name")
                if not v:
                    continue
                name, why = clean_input(v)
                side_col = COL_OF.get(g("Side"))
                if why or name in SPECIAL or not side_col:
                    bad.append({"sheet": sheet, "row_id": g("Row ID"), "column": "Correct Name",
                                "value": v, "reason": why or "type the name (or fix the Side column)"})
                    continue
                fixes.append((g("Row ID").upper(), side_col, name))
    return out, fixes, bad


def data_dir_of(run):
    return run.data_dir


def prebuild(run, data_dir):
    """Build both lists ahead of time (during processing, or in the
    background after a restart) so the Review screen opens at once."""
    try:
        items(run, data_dir)
        variants(run, data_dir)
    except Exception:
        pass
