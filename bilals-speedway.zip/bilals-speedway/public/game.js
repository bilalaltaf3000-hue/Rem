/* Bilal's Speedway - browser client */
import * as THREE from './vendor/three.module.min.js';
import { createRenderer3D } from './render3d.js';

(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const FLAG = { GRASS: 1, DRIFT: 2, NITRO: 4, AIR: 8, CRASHED: 16, GHOST: 32, WRONGWAY: 64, FINISHED: 128, SPIN: 256 };
  const IN = { UP: 1, DOWN: 2, LEFT: 4, RIGHT: 8, NITRO: 16, DRIFT: 32 };
  const VEH = { car: { L: 36, W: 19 }, bike: { L: 30, W: 10 } };
  const KMH = 0.36;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const ordinal = (n) => n + (['th', 'st', 'nd', 'rd'][(n % 100 - 20) % 10] || ['th', 'st', 'nd', 'rd'][n % 100] || 'th');
  const fmtTime = (ms) => {
    if (!ms && ms !== 0) return '--';
    const m = Math.floor(ms / 60000), s = (ms % 60000) / 1000;
    return m + ':' + (s < 10 ? '0' : '') + s.toFixed(2);
  };

  function loadProfile() {
    try { return Object.assign({ name: '', kind: 'car', color: '#e63946' }, JSON.parse(localStorage.getItem('speedway.profile') || '{}')); } catch (e) { return { name: '', kind: 'car', color: '#e63946' }; }
  }
  function saveProfile() { try { localStorage.setItem('speedway.profile', JSON.stringify(S.profile)); } catch (e) { /* */ } }

  const S = {
    ws: null, id: null, you: null, tracks: [], colors: [], rooms: [],
    profile: loadProfile(),
    create: { track: 'seaview', laps: 3, bots: 3 },
    room: null, members: new Map(), track: null, screen: 'home',
    phase: 'lobby', laps: 3, snaps: [], offset: null,
    countEnd: 0, lastCount: null, goUntil: 0, graceEnd: 0,
    hof: null, hofTab: 'week', results: null, resultsEnd: 0,
    keys: new Set(), touchBits: 0, lastBits: -1,
    camMode: (() => { try { return localStorage.getItem('speedway.cam') || 'chase'; } catch (e) { return 'chase'; } })(),
  };

  // =====================================================================
  // Networking
  // =====================================================================
  let reconnectTimer = null;
  function connect() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const w = new WebSocket(`${proto}://${location.host}/ws`);
    S.ws = w;
    w.onopen = () => { hideToast(); send({ t: 'hello', ...S.profile }); };
    w.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } onMsg(m); };
    w.onclose = () => {
      if (S.ws !== w) return;
      S.ws = null;
      toast('Connection lost. Reconnecting…', true, 0);
      goHome();
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connect, 2000);
    };
  }
  function send(o) { if (S.ws && S.ws.readyState === 1) S.ws.send(JSON.stringify(o)); }

  function onMsg(m) {
    switch (m.t) {
      case 'welcome':
        S.id = m.id; S.tracks = m.tracks; S.colors = m.colors; S.rooms = m.rooms;
        renderHome();
        break;
      case 'lobby': S.rooms = m.rooms; renderRoomList(); break;
      case 'joined':
        S.you = m.you; S.track = prepTrack(m.track); S.snaps = [];
        S.chat = [];
        show('room');
        break;
      case 'track': S.track = prepTrack(m.track); renderRoom(); break;
      case 'room':
        S.room = m;
        S.members = new Map(m.members.map((x) => [x.id, x]));
        S.phase = m.phase;
        renderRoom();
        renderChat(m.chat);
        break;
      case 'chat': addChat(m.msg); break;
      case 'phase': onPhase(m); break;
      case 's': onState(m); break;
      case 'ev': onEvents(m.list); break;
      case 'grace': S.graceEnd = performance.now() + m.ms; break;
      case 'results': showResults(m.results, m.ms); break;
      case 'commentary': if (S.results) { S.results.commentary = m.text; $('resComment').textContent = '🎙️ ' + m.text; } break;
      case 'error': toast(m.msg, true); break;
      case 'left': goHome(); break;
      default: break;
    }
  }

  // =====================================================================
  // Screens & home
  // =====================================================================
  function show(name) {
    S.screen = name;
    for (const id of ['home', 'room', 'game']) $(id).classList.toggle('hidden', id !== name);
    if (name === 'home') { loadHof(); renderRoomList(); }
    if (name === 'game') resize();
    if (name !== 'game') Snd.engineOff();
  }

  function goHome() {
    S.room = null; S.you = null; S.snaps = [];
    $('results').classList.add('hidden');
    show('home');
  }

  function renderHome() {
    $('nameInput').value = S.profile.name;
    renderKind();
    renderSwatches($('swatches'));
    renderTrackPick($('createTracks'), S.create.track, true, (id) => { S.create.track = id; renderHome(); });
    $('cLaps').textContent = S.create.laps;
    $('cBots').textContent = S.create.bots;
    renderRoomList();
    loadHof();
  }

  function renderKind() {
    document.querySelectorAll('.kind').forEach((b) => {
      b.classList.toggle('on', b.dataset.kind === S.profile.kind);
      const c = b.querySelector('canvas');
      if (c && !c.dataset.color || (c && c.dataset.color !== S.profile.color)) {
        c.dataset.color = S.profile.color;
        const g = c.getContext('2d');
        g.clearRect(0, 0, c.width, c.height);
        g.save(); g.translate(c.width / 2, c.height / 2); g.scale(2, 2);
        drawVehicle(g, b.dataset.kind, S.profile.color, 0, 0, 0, 0, 0, 0);
        g.restore();
      }
    });
  }

  function renderSwatches(el) {
    el.innerHTML = '';
    for (const c of S.colors) {
      const b = document.createElement('button');
      b.style.background = c;
      b.title = c;
      if (c.toLowerCase() === S.profile.color.toLowerCase()) b.classList.add('on');
      b.onclick = () => { S.profile.color = c; profileChanged(); };
      el.appendChild(b);
    }
  }

  function profileChanged() {
    saveProfile();
    send({ t: 'profile', ...S.profile });
    renderKind();
    renderSwatches($('swatches'));
    renderSwatches($('roomSwatches'));
  }

  function renderRoomList() {
    const el = $('roomList');
    if (!el) return;
    const players = S.rooms.reduce((a, r) => a + r.players, 0);
    $('onlineCount').textContent = players ? `● ${players} racing now` : '';
    if (!S.rooms.length) { el.innerHTML = '<div class="empty">No races yet. Create one below and invite your colleagues!</div>'; return; }
    el.innerHTML = S.rooms.map((r) => `
      <div class="room-card">
        <div class="code">${esc(r.code)}</div>
        <div class="info"><b>${esc(r.trackName)} · ${r.laps} lap${r.laps > 1 ? 's' : ''}</b>${r.players} racer${r.players !== 1 ? 's' : ''} · host ${esc(r.host)}</div>
        <span class="badge ${r.phase === 'lobby' ? 'lobby' : 'racing'}">${r.phase === 'lobby' ? 'Waiting' : r.phase === 'results' ? 'Results' : 'Racing'}</span>
        <button class="btn" data-join="${esc(r.code)}">Join</button>
      </div>`).join('');
    el.querySelectorAll('[data-join]').forEach((b) => { b.onclick = () => joinRoom(b.dataset.join); });
  }

  function ensureName() {
    if (!S.profile.name.trim()) {
      $('nameInput').focus();
      toast('Enter your racer name first', true);
      return false;
    }
    return true;
  }
  function joinRoom(code) { if (!ensureName()) return; Snd.init(); send({ t: 'join', code }); }

  function renderTrackPick(el, selected, editable, onPick) {
    if (!S.tracks.length) return;
    if (el.dataset.built !== '1') {
      el.innerHTML = S.tracks.map((t) => `<button class="track-card" data-id="${t.id}"><canvas width="160" height="100"></canvas><b>${esc(t.name)}</b><small>${t.lengthKm} km</small></button>`).join('');
      el.querySelectorAll('.track-card').forEach((b) => {
        const t = S.tracks.find((x) => x.id === b.dataset.id);
        drawOutline(b.querySelector('canvas'), t);
      });
      el.dataset.built = '1';
    }
    el.querySelectorAll('.track-card').forEach((b) => {
      b.classList.toggle('on', b.dataset.id === selected);
      b.disabled = !editable;
      b.onclick = editable ? () => onPick(b.dataset.id) : null;
      b.title = S.tracks.find((x) => x.id === b.dataset.id)?.desc || '';
    });
  }

  function drawOutline(c, t) {
    const g = c.getContext('2d');
    const b = t.bounds;
    const s = Math.min(c.width / b.w, c.height / b.h) * 1.1;
    g.clearRect(0, 0, c.width, c.height);
    g.save();
    g.translate(c.width / 2, c.height / 2);
    g.scale(s, s);
    g.translate(-(b.x + b.w / 2), -(b.y + b.h / 2));
    g.beginPath();
    t.outline.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])));
    g.closePath();
    g.lineJoin = 'round';
    g.strokeStyle = '#0d0f14'; g.lineWidth = 26 / s; g.stroke();
    g.strokeStyle = '#ffd23f'; g.lineWidth = 9 / s; g.stroke();
    g.fillStyle = '#fff';
    g.beginPath(); g.arc(t.outline[0][0], t.outline[0][1], 9 / s, 0, 7); g.fill();
    g.restore();
  }

  // ---------- hall of fame ----------
  function loadHof() {
    fetch('/api/halloffame').then((r) => r.json()).then((h) => { S.hof = h; renderHof(); }).catch(() => {});
  }
  function renderHof() {
    const h = S.hof, el = $('hofBody');
    if (!h) { el.innerHTML = '<div class="empty">Loading…</div>'; return; }
    const list = (arr, fn, empty) => (arr && arr.length ? '<ol>' + arr.map((x) => '<li>' + fn(x) + '</li>').join('') + '</ol>' : `<div class="empty">${empty}</div>`);
    const icon = (k) => (k === 'bike' ? '🏍️' : '🚗');
    let html = '';
    if (S.hofTab === 'week') {
      if (h.lastChampion) html += `<div class="champ">👑 Last week's champion: <b>${esc(h.lastChampion.name)}</b> (${h.lastChampion.points} pts)</div>`;
      html += `<h4>Week ${esc(h.week.split('-W')[1])} points</h4>`;
      html += list(h.thisWeek, (x) => `<span>${esc(x.name)}</span><span>${x.points} pts · ${x.wins}🏆</span>`, 'No races this week yet. Be the first!');
      html += '<p class="hint">Points every race: last place = 1, each place above +1.</p>';
    } else if (S.hofTab === 'all') {
      html += list(h.topWins, (x) => `<span>${esc(x.name)}</span><span>${x.wins}🏆 · ${x.podiums} podiums · ${x.races} races</span>`, 'No races yet.');
    } else if (S.hofTab === 'laps') {
      for (const t of S.tracks) {
        html += `<h4>${esc(t.name)}</h4>`;
        html += list((h.bestLaps[t.id] || []).slice(0, 5), (x) => `<span>${icon(x.kind)} ${esc(x.name)}</span><span>${fmtTime(x.time)}</span>`, 'No lap record yet');
      }
    } else {
      html += '<h4>💥 Demolition kings (total rams)</h4>' + list(h.demolition, (x) => `<span>${esc(x.name)}</span><span>${x.hits} rams</span>`, 'Nobody has rammed anyone… yet.');
      html += '<h4>⚡ Top speed</h4>' + list(h.speed, (x) => `<span>${esc(x.name)}</span><span>${x.topSpeed} km/h</span>`, 'No data yet');
      html += '<h4>🏁 Recent races</h4>' + list(h.recent, (x) => `<span>${esc(x.track)}</span><span>${x.podium.map((p, i) => ['🥇', '🥈', '🥉'][i] + esc(p.name)).join(' ')}</span>`, 'No races yet');
    }
    el.innerHTML = html;
  }

  // =====================================================================
  // Room screen
  // =====================================================================
  function isHost() { return S.room && S.room.host === S.you; }

  function renderRoom() {
    if (!S.room) return;
    const r = S.room, host = isHost(), st = r.settings;
    $('roomCode').textContent = r.code;
    renderTrackPick($('roomTracks'), st.track, host && r.phase === 'lobby', (id) => send({ t: 'settings', track: id }));
    $('rLaps').textContent = st.laps;
    $('rBots').textContent = st.bots;
    document.querySelectorAll('[data-rstep]').forEach((b) => { b.disabled = !host; b.style.visibility = host ? '' : 'hidden'; });
    document.querySelectorAll('#botLevel button').forEach((b) => { b.classList.toggle('on', b.dataset.v === st.botLevel); b.disabled = !host; });
    const ct = $('collToggle');
    ct.textContent = st.collisions ? '💥 Bumping: ON' : '👻 Bumping: OFF';
    ct.classList.toggle('off', !st.collisions);
    ct.disabled = !host;
    const hostName = S.members.get(r.host)?.name || '';
    $('hostHint').textContent = host ? 'You are the host: pick the track and settings, then start the race.' : `${hostName} (host) picks the track and starts the race.`;

    const members = [...S.members.values()].filter((m) => !m.bot);
    $('racerCount').textContent = `(${members.length}${st.bots ? ' + ' + st.bots + ' bots' : ''})`;
    $('racerList').innerHTML = members.map((m) => `
      <li><span class="dot" style="background:${esc(m.color)}"></span>
      <span class="nm ${m.id === S.you ? 'me' : ''}">${m.kind === 'bike' ? '🏍️' : '🚗'} ${esc(m.name)}${m.id === S.you ? ' (you)' : ''}</span>
      <span class="tag">${m.id === r.host ? '👑 host' : ''}${m.spectating ? ' watching' : ''}</span></li>`).join('') +
      (st.bots ? `<li><span class="dot" style="background:#666"></span><span class="nm">🤖 ${st.bots} bot${st.bots > 1 ? 's' : ''}</span><span class="tag">${st.botLevel}</span></li>` : '');
    const sb = $('startBtn');
    sb.style.display = host ? '' : 'none';
    sb.disabled = r.phase !== 'lobby';
    $('waitHint').textContent = r.phase !== 'lobby' ? 'A race is in progress. You will join the next one.' : host ? '' : 'Waiting for the host to start…';
    document.querySelectorAll('.my-ride .kind').forEach((b) => b.classList.toggle('on', b.dataset.kind === S.profile.kind));
    renderSwatches($('roomSwatches'));
  }

  function renderChat(list) {
    const el = $('chatLog');
    el.innerHTML = '';
    (list || []).forEach((m) => addChat(m, true));
    el.scrollTop = el.scrollHeight;
  }
  function addChat(m, silent) {
    const el = $('chatLog');
    const d = document.createElement('div');
    d.className = 'm' + (m.from ? '' : ' sys');
    d.innerHTML = m.from ? `<b style="color:${esc(m.color || '#fff')}">${esc(m.from)}:</b> ${esc(m.text)}` : esc(m.text);
    el.appendChild(d);
    while (el.children.length > 60) el.removeChild(el.firstChild);
    el.scrollTop = el.scrollHeight;
    if (!silent && S.screen === 'game') addFeed(m.from ? `💬 <b style="color:${esc(m.color)}">${esc(m.from)}</b>: ${esc(m.text)}` : esc(m.text), 6000);
  }

  // =====================================================================
  // Track preparation (pre-rendered world canvas)
  // =====================================================================
  const trackCache = {};
  function prepTrack(t) {
    if (trackCache[t.id]) return trackCache[t.id];
    const T = Object.assign({}, t);
    T.tan = t.pts.map((p, i) => {
      const a = t.pts[(i - 1 + t.N) % t.N], b = t.pts[(i + 1) % t.N];
      const l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
      return [(b[0] - a[0]) / l, (b[1] - a[1]) / l];
    });
    trackCache[t.id] = T;
    return T;
  }

  function genDecor(T) {
    if (T.decor) return;
    const b = T.bounds;
    const limit = T.half + T.runoff + 34;
    const farEnough = (x, y, extra) => {
      for (let i = 0; i < T.N; i += 3) {
        const p = T.pts[i];
        if (Math.abs(p[0] - x) < limit + extra && Math.abs(p[1] - y) < limit + extra && Math.hypot(p[0] - x, p[1] - y) < limit + extra) return false;
      }
      return true;
    };
    T.decor = [];
    const n = Math.floor((b.w * b.h) / 26000);
    for (let i = 0; i < n; i++) {
      const x = b.x + Math.random() * b.w, y = b.y + Math.random() * b.h;
      if (T.theme === 'city' && Math.random() < 0.55) {
        if (!farEnough(x, y, 40)) continue;
        T.decor.push({ type: 'building', x, y, w: 40 + Math.random() * 50, h: 40 + Math.random() * 50, hgt: 40 + Math.random() * 140, color: ['#c9c2b8', '#b5aca1', '#d8cfc0', '#a39a90', '#9fb0c0'][i % 5] });
      } else if (T.theme === 'mountain' && Math.random() < 0.3) {
        if (!farEnough(x, y, 20)) continue;
        T.decor.push({ type: 'rock', x, y, r: 10 + Math.random() * 18, color: ['#8d8d8d', '#7a7a7a', '#9b9488'][i % 3] });
      } else {
        if (!farEnough(x, y, 20)) continue;
        const greens = T.theme === 'mountain' ? ['#245c2a', '#2b6b30', '#1f5225'] : T.theme === 'coast' ? ['#2f7d3a', '#3b8f3f', '#4a9a2f'] : ['#3c7a35', '#2f6b2c'];
        T.decor.push({ type: 'tree', x, y, r: 14 + Math.random() * 16, color: greens[i % greens.length] });
      }
    }
  }

  function buildTrackCanvas(T) {
    if (T.canvas) return;
    T.canvas = drawTrackCanvas(T, false);
    // skid layer at half resolution
    const b = T.bounds;
    const sk = document.createElement('canvas');
    sk.width = Math.ceil(b.w / 2); sk.height = Math.ceil(b.h / 2);
    T.skid = sk; T.skidCtx = sk.getContext('2d');
  }

  function ensureMinimap(T) {
    if (T.mm) return;
    const b = T.bounds;
    const mmc = $('minimap');
    const s = Math.min((mmc.width - 20) / (b.w - 500), (mmc.height - 20) / (b.h - 500));
    T.mm = { s, ox: mmc.width / 2 - (b.x + b.w / 2) * s, oy: mmc.height / 2 - (b.y + b.h / 2) * s };
  }

  function drawTrackCanvas(T, flat3d) {
    const b = T.bounds;
    const c = document.createElement('canvas');
    c.width = Math.ceil(b.w); c.height = Math.ceil(b.h);
    const g = c.getContext('2d');
    g.translate(-b.x, -b.y);
    const theme = {
      coast: { grass: '#5ea94a', grass2: '#559a42', run: '#7cc261' },
      mountain: { grass: '#4a8a3a', grass2: '#3f7a31', run: '#69a656' },
      city: { grass: '#6f9a58', grass2: '#638d4e', run: '#8db574' },
    }[T.theme] || { grass: '#5ea94a', grass2: '#559a42', run: '#7cc261' };

    T.bg = theme.grass;
    g.fillStyle = theme.grass;
    g.fillRect(b.x, b.y, b.w, b.h);
    // grass texture
    for (let i = 0; i < (b.w * b.h) / 900; i++) {
      g.fillStyle = Math.random() < 0.5 ? theme.grass2 : 'rgba(255,255,255,0.05)';
      g.fillRect(b.x + Math.random() * b.w, b.y + Math.random() * b.h, 3 + Math.random() * 4, 2 + Math.random() * 3);
    }
    genDecor(T);
    for (const d of T.decor) {
      if (d.type === 'building') {
        g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(d.x - d.w / 2 + 6, d.y - d.h / 2 + 6, d.w, d.h);
        if (!flat3d) {
          g.fillStyle = d.color; g.fillRect(d.x - d.w / 2, d.y - d.h / 2, d.w, d.h);
          g.fillStyle = 'rgba(0,0,0,0.12)'; g.fillRect(d.x - d.w / 2 + 6, d.y - d.h / 2 + 6, d.w - 12, d.h - 12);
        }
      } else {
        g.fillStyle = 'rgba(0,0,0,0.25)'; g.beginPath(); g.arc(d.x + (flat3d ? 3 : 5), d.y + (flat3d ? 3 : 5), d.r * (flat3d ? 0.9 : 1), 0, 7); g.fill();
        if (!flat3d) {
          g.fillStyle = d.color; g.beginPath(); g.arc(d.x, d.y, d.r, 0, 7); g.fill();
          g.fillStyle = 'rgba(255,255,255,0.13)'; g.beginPath(); g.arc(d.x - d.r * 0.3, d.y - d.r * 0.35, d.r * 0.5, 0, 7); g.fill();
        }
      }
    }

    const path = new Path2D();
    T.pts.forEach((p, i) => (i ? path.lineTo(p[0], p[1]) : path.moveTo(p[0], p[1])));
    path.closePath();
    g.lineJoin = 'round'; g.lineCap = 'round';
    const W = (T.half + T.runoff) * 2;
    // tyre barrier
    g.strokeStyle = '#1b1b1d'; g.lineWidth = W + 18; g.stroke(path);
    g.setLineDash([16, 16]); g.strokeStyle = '#d63031'; g.lineWidth = W + 18; g.stroke(path); g.setLineDash([]);
    g.strokeStyle = '#1b1b1d'; g.lineWidth = W + 6; g.stroke(path);
    // runoff
    g.strokeStyle = theme.run; g.lineWidth = W; g.stroke(path);
    // curbs
    g.strokeStyle = '#f1f1f1'; g.lineWidth = T.half * 2 + 16; g.stroke(path);
    g.setLineDash([20, 20]); g.strokeStyle = '#e03131'; g.stroke(path); g.setLineDash([]);
    // asphalt
    g.strokeStyle = '#47484f'; g.lineWidth = T.half * 2; g.stroke(path);
    g.strokeStyle = 'rgba(255,255,255,0.025)'; g.lineWidth = T.half * 1.1; g.stroke(path);
    g.strokeStyle = 'rgba(0,0,0,0.08)'; g.lineWidth = T.half * 0.5; g.stroke(path);
    // edge lines
    g.strokeStyle = 'rgba(255,255,255,0.7)'; g.lineWidth = T.half * 2 - 6; g.stroke(path);
    g.strokeStyle = '#47484f'; g.lineWidth = T.half * 2 - 12; g.stroke(path);
    g.strokeStyle = 'rgba(0,0,0,0.06)'; g.lineWidth = T.half * 0.5; g.stroke(path);
    // centre dashes
    g.setLineDash([28, 34]); g.strokeStyle = 'rgba(255,255,255,0.45)'; g.lineWidth = 3; g.stroke(path); g.setLineDash([]);

    // start/finish + grid
    const p0 = T.pts[0], t0 = T.tan[0];
    g.save(); g.translate(p0[0], p0[1]); g.rotate(Math.atan2(t0[1], t0[0]));
    const sq = 10;
    for (let row = 0; row < 3; row++) {
      for (let y = -T.half, k = 0; y < T.half; y += sq, k++) {
        g.fillStyle = (k + row) % 2 ? '#111' : '#fff';
        g.fillRect(-row * sq, y, sq, Math.min(sq, T.half - y));
      }
    }
    g.restore();
    const rowGap = Math.round(48 / T.spacing);
    for (let i = 0; i < 8; i++) {
      const row = Math.floor(i / 2);
      const lane = (i % 2 === 0 ? -1 : 1) * T.half * 0.42;
      const idx = (T.N - 3 - row * rowGap - (i % 2) * 2 + T.N) % T.N;
      const p = T.pts[idx], t = T.tan[idx];
      g.save(); g.translate(p[0] - t[1] * lane, p[1] + t[0] * lane); g.rotate(Math.atan2(t[1], t[0]));
      g.strokeStyle = 'rgba(255,255,255,0.6)'; g.lineWidth = 3;
      g.beginPath(); g.moveTo(10, -16); g.lineTo(26, -16); g.lineTo(26, 16); g.lineTo(10, 16); g.stroke();
      g.restore();
    }

    // hazards
    for (const h of T.hazards) {
      g.save(); g.translate(h.x, h.y); g.rotate(h.a);
      if (h.type === 'boost') {
        g.fillStyle = 'rgba(20,20,30,0.85)'; roundRect(g, -30, -22, 60, 44, 8); g.fill();
        g.strokeStyle = '#3fa7ff'; g.lineWidth = 2; roundRect(g, -30, -22, 60, 44, 8); g.stroke();
        for (let k = 0; k < 3; k++) {
          g.strokeStyle = ['#ffd23f', '#ff9f1a', '#ff4757'][k]; g.lineWidth = 6; g.lineCap = 'round';
          g.beginPath(); g.moveTo(-18 + k * 14, -12); g.lineTo(-8 + k * 14, 0); g.lineTo(-18 + k * 14, 12); g.stroke();
        }
      } else if (h.type === 'oil') {
        g.fillStyle = 'rgba(10,10,14,0.88)';
        for (const [ox, oy, r] of [[0, 0, 24], [16, 8, 15], [-14, 10, 14], [8, -16, 13], [-16, -10, 11]]) { g.beginPath(); g.arc(ox, oy, r, 0, 7); g.fill(); }
        const gr = g.createLinearGradient(-15, -15, 15, 15);
        gr.addColorStop(0, 'rgba(160,80,255,0.35)'); gr.addColorStop(0.5, 'rgba(60,200,255,0.25)'); gr.addColorStop(1, 'rgba(255,220,80,0.2)');
        g.fillStyle = gr; g.beginPath(); g.ellipse(-4, -4, 12, 7, 0.6, 0, 7); g.fill();
      } else if (h.type === 'bump') {
        g.fillStyle = '#ffd23f'; g.fillRect(-8, -T.half, 16, T.half * 2);
        g.fillStyle = '#1b1b1b';
        for (let y = -T.half; y < T.half; y += 24) g.fillRect(-8, y, 16, 12);
        g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(8, -T.half, 4, T.half * 2);
      }
      g.restore();
    }
    return c;
  }

  function roundRect(g, x, y, w, h, r) {
    g.beginPath();
    g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r);
    g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r);
    g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y);
    g.closePath();
  }

  // =====================================================================
  // Vehicle drawing
  // =====================================================================
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    r = clamp(Math.round(r + amt), 0, 255); g = clamp(Math.round(g + amt), 0, 255); b = clamp(Math.round(b + amt), 0, 255);
    return `rgb(${r},${g},${b})`;
  }

  function drawVehicle(g, kind, color, x, y, a, flags, air, t) {
    const spec = VEH[kind] || VEH.car;
    const L = spec.L, W = spec.W;
    const lift = flags & FLAG.AIR ? Math.sin(Math.PI * clamp(air / 100, 0, 1)) : 0;
    const scale = 1 + lift * 0.35;
    g.save();
    g.translate(x, y);
    if (flags & FLAG.GHOST) g.globalAlpha = 0.4 + 0.25 * Math.sin((t || 0) / 60);
    // shadow
    g.save();
    g.translate(4 + lift * 14, 5 + lift * 16);
    g.rotate(a);
    g.fillStyle = `rgba(0,0,0,${0.35 - lift * 0.15})`;
    if (kind === 'bike') { g.beginPath(); g.ellipse(0, 0, L / 2, W / 2 + 2, 0, 0, 7); g.fill(); }
    else { roundRect(g, -L / 2, -W / 2, L, W, 6); g.fill(); }
    g.restore();

    g.rotate(a);
    g.scale(scale, scale);
    // nitro flame
    if (flags & FLAG.NITRO) {
      const f = 10 + Math.random() * 12;
      const gr = g.createLinearGradient(-L / 2, 0, -L / 2 - f, 0);
      gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.3, '#7fd3ff'); gr.addColorStop(0.7, '#a46bff'); gr.addColorStop(1, 'rgba(164,107,255,0)');
      g.fillStyle = gr;
      const ys = kind === 'bike' ? [0] : [-W * 0.25, W * 0.25];
      for (const yy of ys) { g.beginPath(); g.moveTo(-L / 2 + 1, yy - 4); g.lineTo(-L / 2 - f, yy); g.lineTo(-L / 2 + 1, yy + 4); g.fill(); }
    }

    if (kind === 'bike') {
      if (flags & FLAG.CRASHED) {
        // bike on its side + rider tumbling
        g.save(); g.rotate(Math.PI / 2.2);
        drawBikeBody(g, color, L, W);
        g.restore();
        g.fillStyle = shade(color, -60); g.beginPath(); g.arc(-14, 16, 6, 0, 7); g.fill();
        g.fillStyle = color; g.beginPath(); g.arc(-18, 20, 4.5, 0, 7); g.fill();
      } else {
        drawBikeBody(g, color, L, W);
        // rider
        g.fillStyle = shade(color, -70); g.beginPath(); g.ellipse(-3, 0, 7, 6.5, 0, 0, 7); g.fill();
        g.fillStyle = color; g.beginPath(); g.arc(4, 0, 5.2, 0, 7); g.fill();
        g.fillStyle = 'rgba(20,30,50,0.9)'; g.beginPath(); g.arc(5.5, 0, 3.4, -1.1, 1.1); g.fill();
        g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.arc(2.5, -2, 1.6, 0, 7); g.fill();
      }
    } else {
      // wheels
      g.fillStyle = '#111';
      for (const wx of [L * 0.28, -L * 0.3]) { g.fillRect(wx - 5, -W / 2 - 2, 10, 5); g.fillRect(wx - 5, W / 2 - 3, 10, 5); }
      // body
      const gr = g.createLinearGradient(0, -W / 2, 0, W / 2);
      gr.addColorStop(0, shade(color, 40)); gr.addColorStop(0.5, color); gr.addColorStop(1, shade(color, -50));
      g.fillStyle = gr;
      roundRect(g, -L / 2, -W / 2, L, W, 6); g.fill();
      g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineWidth = 1; roundRect(g, -L / 2, -W / 2, L, W, 6); g.stroke();
      // stripe
      g.fillStyle = 'rgba(255,255,255,0.55)';
      g.fillRect(L * 0.22, -W * 0.09, L * 0.26, W * 0.18);
      g.fillRect(-L / 2 + 2, -W * 0.09, L * 0.14, W * 0.18);
      // cabin
      g.fillStyle = 'rgba(10,20,40,0.85)'; roundRect(g, -L * 0.2, -W * 0.36, L * 0.42, W * 0.72, 4); g.fill();
      g.fillStyle = shade(color, -25); roundRect(g, -L * 0.13, -W * 0.3, L * 0.24, W * 0.6, 3); g.fill();
      g.fillStyle = 'rgba(160,210,255,0.35)'; g.fillRect(L * 0.13, -W * 0.3, L * 0.06, W * 0.6);
      // lights
      g.fillStyle = '#fff6c4'; g.fillRect(L / 2 - 3, -W / 2 + 2, 3, 4); g.fillRect(L / 2 - 3, W / 2 - 6, 3, 4);
      g.fillStyle = '#ff3040'; g.fillRect(-L / 2, -W / 2 + 2, 2, 4); g.fillRect(-L / 2, W / 2 - 6, 2, 4);
      if (flags & FLAG.CRASHED) { g.fillStyle = 'rgba(0,0,0,0.4)'; roundRect(g, -L / 2, -W / 2, L, W, 6); g.fill(); }
    }
    g.restore();
  }

  function drawBikeBody(g, color, L, W) {
    g.fillStyle = '#111';
    g.beginPath(); g.ellipse(L * 0.36, 0, 5.5, 2.6, 0, 0, 7); g.fill();
    g.beginPath(); g.ellipse(-L * 0.36, 0, 5.5, 3, 0, 0, 7); g.fill();
    g.fillStyle = color;
    g.beginPath(); g.ellipse(0, 0, L * 0.3, W * 0.38, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.4)'; g.beginPath(); g.ellipse(L * 0.08, -W * 0.12, L * 0.12, W * 0.1, 0, 0, 7); g.fill();
    g.strokeStyle = '#ccc'; g.lineWidth = 1.6;
    g.beginPath(); g.moveTo(L * 0.24, -W * 0.75); g.lineTo(L * 0.24, W * 0.75); g.stroke();
    g.fillStyle = '#fff6c4'; g.beginPath(); g.arc(L * 0.47, 0, 1.6, 0, 7); g.fill();
  }

  // =====================================================================
  // Game: phases, snapshots, events
  // =====================================================================
  function enterGame() {
    if (!S.track) return;
    ensureMinimap(S.track);
    if (S.track.skidCtx) S.track.skidCtx.clearRect(0, 0, S.track.skid.width, S.track.skid.height);
    if (R3) { R3.setTrack(S.track); R3.resetCamera(); }
    S.was3d = null;
    particles.length = 0;
    prevWheels.clear();
    $('feed').innerHTML = '';
    $('results').classList.add('hidden');
    $('centerMsg').textContent = '';
    $('subMsg').textContent = '';
    for (const k of Object.keys(hudCache)) delete hudCache[k];
    stuckT = 0;
    cam.init = false;
    S.graceEnd = 0;
    show('game');
  }

  function onPhase(m) {
    S.phase = m.phase;
    if (m.laps) S.laps = m.laps;
    if (m.phase === 'countdown') {
      S.snaps = [];
      S.offset = null;
      enterGame();
      S.countEnd = performance.now() + m.ms;
      S.lastCount = null;
      S.spectating = !!m.spectating;
    } else if (m.phase === 'race') {
      if (S.screen !== 'game') { enterGame(); S.spectating = !!m.spectating; }
      else { S.goUntil = performance.now() + 900; showCenter('GO!', 900, 'pop'); Snd.beep(880, 0.45, 0.35); }
      S.countEnd = 0;
    } else if (m.phase === 'lobby') {
      $('results').classList.add('hidden');
      S.results = null;
      if (S.room) show('room');
    }
  }

  function onState(m) {
    const off = Date.now() - m.st;
    S.offset = S.offset == null ? off : Math.min(off, S.offset + 0.4);
    const v = new Map();
    for (const a of m.v) v.set(a[0], a);
    S.snaps.push({ st: m.st, rt: m.rt, v });
    if (S.snaps.length > 40) S.snaps.shift();
  }

  function interp() {
    const sn = S.snaps;
    if (!sn.length) return null;
    const rt = Date.now() - S.offset - 75;
    let a = sn[0], b = sn[0];
    if (rt >= sn[sn.length - 1].st) { a = b = sn[sn.length - 1]; }
    else {
      for (let i = sn.length - 2; i >= 0; i--) {
        if (sn[i].st <= rt) { a = sn[i]; b = sn[i + 1]; break; }
      }
    }
    const span = b.st - a.st;
    const k = span > 0 ? clamp((rt - a.st) / span, 0, 1) : 1;
    const out = [];
    for (const [id, vb] of b.v) {
      const va = a.v.get(id) || vb;
      let da = vb[3] - va[3];
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      out.push({
        id, x: va[1] + (vb[1] - va[1]) * k, y: va[2] + (vb[2] - va[2]) * k, a: va[3] + da * k,
        spd: va[4] + (vb[4] - va[4]) * k, f: vb[5], lap: vb[6], place: vb[7], nitro: vb[8],
        air: vb[9] ? va[9] + (vb[9] - va[9]) * k : 0, best: vb[10], last: vb[11], rcd: vb[12],
      });
    }
    return { list: out, rt: a.rt + (b.rt - a.rt) * k };
  }

  function nameOf(id) { return S.members.get(id)?.name || '???'; }
  function colorOf(id) { return S.members.get(id)?.color || '#ccc'; }
  function kindOf(id) { return S.members.get(id)?.kind || 'car'; }
  function nm(id) { return `<b style="color:${esc(colorOf(id))}">${esc(nameOf(id))}</b>`; }

  let lastView = null; // last interpolated vehicles (for event positions)
  function vehPos(id) { const v = lastView && lastView.list.find((x) => x.id === id); return v ? [v.x, v.y] : [cam.x, cam.y]; }
  function distVol(x, y) { return clamp(1 - Math.hypot(x - cam.x, y - cam.y) / 900, 0, 1); }

  const recentCrashFeed = new Map();
  function onEvents(list) {
    for (const e of list) {
      const mine = e.id === S.you || e.a === S.you || e.b === S.you;
      switch (e.k) {
        case 'hit': {
          sparks(e.x, e.y, 10 + Math.min(30, e.p / 15), e.r === 'bump' ? '#ffd23f' : '#ff9f1a');
          Snd.crash(clamp(e.p / 500, 0.15, 1) * (mine ? 1 : distVol(e.x, e.y) * 0.7));
          if (mine) shake(Math.min(14, e.p / 30));
          const verb = e.r === 'crash' ? 'knocked {b} off their bike! 🏍️💥' : e.r === 'spin' ? 'sent {b} spinning! 🌀' : 'bumped {b}';
          if (e.r !== 'bump' || mine) addFeed(`💥 ${nm(e.a)} ${verb.replace('{b}', nm(e.b))}`);
          if (e.r === 'crash') recentCrashFeed.set(e.b, performance.now());
          if (e.a === S.you && e.r !== 'bump') popText(e.r === 'crash' ? 'TAKEDOWN!' : 'NICE HIT!');
          break;
        }
        case 'wall':
          sparks(e.x, e.y, 8, '#ffe08a');
          if (e.id === S.you) { shake(Math.min(10, e.p / 40)); Snd.thud(clamp(e.p / 400, 0.2, 0.9)); }
          break;
        case 'crash': {
          debris(e.x, e.y, colorOf(e.id));
          const t = recentCrashFeed.get(e.id);
          if (!t || performance.now() - t > 500) addFeed(`🤕 ${nm(e.id)} wiped out!`);
          if (e.id === S.you) { shake(12); popText('WIPEOUT!'); }
          break;
        }
        case 'boost': if (e.id === S.you) { Snd.whoosh(); } break;
        case 'oil': if (e.id === S.you) { Snd.squish(); popText('OIL!'); } break;
        case 'bump': if (e.id === S.you) { Snd.thunk(); shake(5); } else { const p = vehPos(e.id); if (distVol(p[0], p[1]) > 0.5) Snd.thunk(0.3); } break;
        case 'lap':
          if (e.id === S.you) {
            const next = e.lap + 1;
            if (next <= S.laps) showCenter(next === S.laps ? 'FINAL LAP!' : `LAP ${next}`, 1400, 'pop');
            const lapMsg = `Lap time ${fmtTime(e.t)}`;
            setText('subMsg', lapMsg);
            clearTimeout(subTimer); subTimer = setTimeout(() => { if (hudCache.subMsg === lapMsg) setText('subMsg', ''); }, 2200);
            Snd.ding();
          }
          break;
        case 'finish':
          addFeed(`🏁 ${nm(e.id)} finishes ${ordinal(e.place)}!`, 7000);
          if (e.id === S.you) { showCenter(ordinal(e.place).toUpperCase() + '!', 2500, 'pop'); Snd.fanfare(e.place); }
          break;
        case 'honk': {
          honks.set(e.id, performance.now() + 700);
          const p = vehPos(e.id);
          Snd.horn(e.id === S.you ? 0.6 : distVol(p[0], p[1]) * 0.6);
          break;
        }
        case 'respawn': { const p = vehPos(e.id); puff(p[0], p[1]); break; }
        default: break;
      }
    }
  }

  let subTimer = null, centerTimer = null;
  function showCenter(text, ms, cls) {
    const el = $('centerMsg');
    el.className = 'center-msg';
    void el.offsetWidth;
    if (cls) el.classList.add(cls);
    el.textContent = text;
    clearTimeout(centerTimer);
    if (ms) centerTimer = setTimeout(() => { if (el.textContent === text) el.textContent = ''; }, ms);
  }
  function popText(text) {
    floatTexts.push({ text, t: performance.now() });
  }

  function addFeed(html, ms) {
    const el = $('feed');
    const d = document.createElement('div');
    d.className = 'feed-item';
    d.innerHTML = html;
    el.appendChild(d);
    while (el.children.length > 6) el.removeChild(el.firstChild);
    setTimeout(() => { d.style.opacity = '0'; setTimeout(() => d.remove(), 700); }, ms || 5000);
  }

  // ---------- results ----------
  function showResults(r, ms) {
    S.results = r;
    S.resultsEnd = performance.now() + ms;
    $('resTrack').textContent = `${r.trackName} · ${r.laps} lap${r.laps > 1 ? 's' : ''}`;
    $('resComment').textContent = '🎙️ ' + (r.commentary || 'The commentator is catching their breath…');
    const medals = ['🥇', '🥈', '🥉'];
    $('resBody').innerHTML = r.list.map((x) => `
      <tr class="${x.id === S.you ? 'me' : ''}">
        <td class="medal">${medals[x.place - 1] || x.place}</td>
        <td><span class="dot" style="background:${esc(x.color)}"></span>${x.kind === 'bike' ? '🏍️' : '🚗'} ${esc(x.name)}${x.bot ? '<span class="bot">BOT</span>' : ''}</td>
        <td>${x.finished ? fmtTime(x.time) : 'DNF'}</td><td>${fmtTime(x.bestLap)}</td><td>${x.hits}</td><td>${x.topSpeed}</td>
      </tr>`).join('');
    const awards = [];
    const fl = r.list.filter((x) => x.bestLap).sort((a, b) => a.bestLap - b.bestLap)[0];
    if (fl) awards.push(['⏱️', 'Fastest lap', fl.name, fmtTime(fl.bestLap)]);
    const ram = r.list.slice().sort((a, b) => b.hits - a.hits)[0];
    if (ram && ram.hits > 0) awards.push(['💥', 'Demolition king', ram.name, `${ram.hits} rams`]);
    const mag = r.list.slice().sort((a, b) => (b.crashes * 3 + b.wallHits) - (a.crashes * 3 + a.wallHits))[0];
    if (mag && mag.crashes * 3 + mag.wallHits >= 3) awards.push(['🧲', 'Crash magnet', mag.name, `${mag.crashes} wipeouts · ${mag.wallHits} walls`]);
    const sp = r.list.slice().sort((a, b) => b.topSpeed - a.topSpeed)[0];
    if (sp) awards.push(['⚡', 'Speed demon', sp.name, `${sp.topSpeed} km/h`]);
    $('resAwards').innerHTML = awards.map((a) => `<div class="award"><div class="ic">${a[0]}</div><small>${a[1]}</small><b>${esc(a[2])}</b><small>${esc(a[3])}</small></div>`).join('');
    $('againBtn').textContent = isHost() ? 'Back to room (everyone)' : 'Back to room';
    $('results').classList.remove('hidden');
    Snd.engineOff();
  }

  // =====================================================================
  // Rendering
  // =====================================================================
  const cv = $('cv'), ctx = cv.getContext('2d');
  const cv3 = $('cv3');
  let R3 = null;
  try {
    R3 = createRenderer3D(THREE, cv3, {
      kindOf: (id) => kindOf(id), colorOf: (id) => colorOf(id), nameOf: (id) => nameOf(id),
      groundCanvas: (T) => drawTrackCanvas(T, true),
    });
  } catch (e) { console.warn('3D unavailable', e); R3 = null; }
  if (!R3 || !R3.ok) { R3 = null; if (S.camMode !== 'top') S.camMode = 'top'; }
  const mm = $('minimap'), mctx = mm.getContext('2d');
  const cam = { x: 0, y: 0, z: 1, init: false, shake: 0 };
  const particles = [];
  const prevWheels = new Map();
  const honks = new Map();
  const floatTexts = [];
  let W = 0, H = 0, DPR = 1;

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
    if (R3 && R3.ok) R3.resize(W, H, Math.min(DPR, 1.5));
  }
  window.addEventListener('resize', resize);

  function shake(n) { cam.shake = Math.max(cam.shake, n); }
  function sparks(x, y, n, color) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = 120 + Math.random() * 380;
      particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.25 + Math.random() * 0.35, max: 0.6, type: 'spark', color });
    }
  }
  function debris(x, y, color) {
    for (let i = 0; i < 14; i++) {
      const a = Math.random() * Math.PI * 2, s = 60 + Math.random() * 220;
      particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.8 + Math.random() * 0.6, max: 1.4, type: 'chunk', color: i % 3 ? color : '#333', rot: Math.random() * 6, vr: (Math.random() - 0.5) * 20 });
    }
    puff(x, y);
  }
  function puff(x, y) {
    for (let i = 0; i < 10; i++) {
      const a = Math.random() * Math.PI * 2, s = 20 + Math.random() * 60;
      particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.6 + Math.random() * 0.5, max: 1.1, type: 'smoke', size: 10 + Math.random() * 10, color: '220,220,220' });
    }
  }

  let lastFrame = performance.now();
  let boardTimer = 0, stuckT = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - lastFrame) / 1000);
    lastFrame = now;
    if (S.screen !== 'game' || !S.track) return;
    const T = S.track;
    const use3d = S.camMode !== 'top' && R3 && R3.ok;
    if (!use3d && !T.canvas) buildTrackCanvas(T);
    if (use3d !== S.was3d) { S.was3d = use3d; cv3.style.display = use3d ? 'block' : 'none'; if (use3d) { R3.setTrack(T); R3.resetCamera(); } }
    const view = interp();
    lastView = view;
    const list = view ? view.list : [];
    const me = list.find((v) => v.id === S.you);
    S.spectating = !me;
    let focus = me;
    if (!focus && list.length) focus = list.slice().sort((a, b) => a.place - b.place)[0];

    // camera
    if (focus) {
      const look = 0.22;
      const tx = focus.x + Math.cos(focus.a) * focus.spd * look;
      const ty = focus.y + Math.sin(focus.a) * focus.spd * look;
      if (!cam.init) { cam.x = tx; cam.y = ty; cam.init = true; }
      cam.x += (tx - cam.x) * Math.min(1, dt * 6);
      cam.y += (ty - cam.y) * Math.min(1, dt * 6);
      const base = clamp(Math.min(W, H) / 680, 0.6, 1.5);
      const tz = base * (1 - 0.2 * clamp(focus.spd / 720, 0, 1));
      cam.z += (tz - cam.z) * Math.min(1, dt * 2);
    } else if (!cam.init) {
      const p = T.pts[0]; cam.x = p[0]; cam.y = p[1]; cam.z = clamp(Math.min(W, H) / 680, 0.6, 1.5);
    }
    cam.shake *= Math.exp(-8 * dt);
    const sx = (Math.random() - 0.5) * cam.shake, sy = (Math.random() - 0.5) * cam.shake;

    // world
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (use3d) ctx.clearRect(0, 0, cv.width, cv.height);
    else {
      ctx.fillStyle = T.bg || '#5ea94a';
      ctx.fillRect(0, 0, cv.width, cv.height);
      const z = cam.z * DPR;
      ctx.setTransform(z, 0, 0, z, cv.width / 2 - (cam.x + sx) * z, cv.height / 2 - (cam.y + sy) * z);
      ctx.drawImage(T.canvas, T.bounds.x, T.bounds.y);
    }

    // skid marks
    const sk = T.skidCtx;
    for (const v of list) {
      const skidding = (v.f & (FLAG.DRIFT | FLAG.SPIN | FLAG.CRASHED)) && !(v.f & FLAG.AIR) && v.spd > 40;
      const spec = VEH[kindOf(v.id)];
      const ca = Math.cos(v.a), sa = Math.sin(v.a);
      const bx = v.x - ca * spec.L * 0.32, by = v.y - sa * spec.L * 0.32;
      const wheels = kindOf(v.id) === 'bike' ? [[bx, by]] : [[bx - sa * spec.W * 0.4, by + ca * spec.W * 0.4], [bx + sa * spec.W * 0.4, by - ca * spec.W * 0.4]];
      const prev = prevWheels.get(v.id);
      if (skidding && prev && !use3d) {
        sk.strokeStyle = v.f & FLAG.GRASS ? 'rgba(60,40,20,0.35)' : 'rgba(15,15,15,0.4)';
        sk.lineWidth = kindOf(v.id) === 'bike' ? 1.5 : 2.2;
        sk.lineCap = 'round';
        sk.beginPath();
        wheels.forEach((w, i) => {
          if (!prev[i]) return;
          sk.moveTo((prev[i][0] - T.bounds.x) / 2, (prev[i][1] - T.bounds.y) / 2);
          sk.lineTo((w[0] - T.bounds.x) / 2, (w[1] - T.bounds.y) / 2);
        });
        sk.stroke();
      }
      prevWheels.set(v.id, skidding ? wheels : null);

      // ambient particles
      if ((v.f & FLAG.GRASS) && v.spd > 90 && Math.random() < 0.5) {
        particles.push({ x: bx, y: by, vx: (Math.random() - 0.5) * 50 - ca * 40, vy: (Math.random() - 0.5) * 50 - sa * 40, life: 0.6, max: 0.6, type: 'smoke', size: 8, color: '140,110,60' });
      }
      if ((v.f & FLAG.NITRO) && Math.random() < 0.6) {
        particles.push({ x: bx - ca * 8, y: by - sa * 8, vx: -ca * 60 + (Math.random() - 0.5) * 30, vy: -sa * 60 + (Math.random() - 0.5) * 30, life: 0.5, max: 0.5, type: 'smoke', size: 7, color: '180,200,255' });
      }
      if ((v.f & FLAG.DRIFT) && Math.random() < 0.35 && !(v.f & FLAG.GRASS)) {
        particles.push({ x: bx, y: by, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 30, life: 0.7, max: 0.7, type: 'smoke', size: 9, color: '230,230,230' });
      }
    }
    if (!use3d) ctx.drawImage(T.skid, T.bounds.x, T.bounds.y, T.skid.width * 2, T.skid.height * 2);

    // particles (under vehicles: smoke)
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= Math.exp(-3 * dt); p.vy *= Math.exp(-3 * dt);
      if (p.type === 'smoke' && !use3d) {
        const k = p.life / p.max;
        ctx.fillStyle = `rgba(${p.color},${0.35 * k})`;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1.8 - k), 0, 7); ctx.fill();
      }
    }
    if (particles.length > 900) particles.splice(0, particles.length - 900);

    if (use3d) {
      R3.render({ list, focusId: focus ? focus.id : null, youId: S.you, dt, now, mode: S.camMode, particles, shake: cam.shake, F: FLAG, honks, T });
    } else {
    // vehicles (airborne last)
    const sorted = list.slice().sort((a, b) => ((a.f & FLAG.AIR) ? 1 : 0) - ((b.f & FLAG.AIR) ? 1 : 0));
    for (const v of sorted) drawVehicle(ctx, kindOf(v.id), colorOf(v.id), v.x, v.y, v.a, v.f, v.air, now);

    // sparks/chunks on top
    for (const p of particles) {
      const k = p.life / p.max;
      if (p.type === 'spark') {
        ctx.strokeStyle = p.color; ctx.globalAlpha = Math.min(1, k * 2); ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03); ctx.stroke();
        ctx.globalAlpha = 1;
      } else if (p.type === 'chunk') {
        p.rot += p.vr * dt;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = Math.min(1, k * 2);
        ctx.fillStyle = p.color; ctx.fillRect(-3, -2, 6, 4); ctx.restore();
      }
    }

    // name tags + horn bubbles
    const inv = 1 / cam.z;
    ctx.textAlign = 'center';
    for (const v of list) {
      const isMe = v.id === S.you;
      ctx.save();
      ctx.translate(v.x, v.y - 26);
      ctx.scale(inv, inv);
      if (!isMe) {
        ctx.font = 'bold 12px Segoe UI, Arial, sans-serif';
        const label = `${v.place}. ${nameOf(v.id)}`;
        const w = ctx.measureText(label).width + 12;
        ctx.fillStyle = 'rgba(0,0,0,0.55)'; roundRect(ctx, -w / 2, -10, w, 18, 9); ctx.fill();
        ctx.fillStyle = colorOf(v.id); ctx.fillRect(-w / 2 + 4, -3, 4, 4);
        ctx.fillStyle = '#fff'; ctx.fillText(label, 3, 3);
      } else {
        ctx.fillStyle = '#ffd23f';
        ctx.beginPath(); ctx.moveTo(-6, -4); ctx.lineTo(6, -4); ctx.lineTo(0, 4); ctx.fill();
      }
      const hk = honks.get(v.id);
      if (hk && hk > now) {
        ctx.font = 'bold 16px Impact, Arial Black, sans-serif';
        ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 4;
        ctx.strokeText('BEEP BEEP!', 0, -18); ctx.fillText('BEEP BEEP!', 0, -18);
      }
      ctx.restore();
    }

    }

    // floating pop texts (screen space)
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    for (let i = floatTexts.length - 1; i >= 0; i--) {
      const ft = floatTexts[i];
      const age = (now - ft.t) / 1000;
      if (age > 1.2) { floatTexts.splice(i, 1); continue; }
      ctx.globalAlpha = 1 - age / 1.2;
      ctx.font = `${28 + age * 10}px Impact, Arial Black, sans-serif`;
      ctx.textAlign = 'center';
      ctx.lineWidth = 5; ctx.strokeStyle = '#000'; ctx.fillStyle = '#ff9f1a';
      ctx.strokeText(ft.text, W / 2, H * 0.42 - age * 60);
      ctx.fillText(ft.text, W / 2, H * 0.42 - age * 60);
      ctx.globalAlpha = 1;
    }

    drawMinimap(T, list);
    updateHud(now, view, me, list, dt);
  }

  function drawMinimap(T, list) {
    const g = mctx, m = T.mm;
    g.clearRect(0, 0, mm.width, mm.height);
    g.save();
    g.translate(m.ox, m.oy); g.scale(m.s, m.s);
    g.beginPath();
    T.pts.forEach((p, i) => (i % 3 === 0 ? (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])) : 0));
    g.closePath();
    g.lineJoin = 'round';
    g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 9 / m.s; g.stroke();
    g.strokeStyle = '#3d3f47'; g.lineWidth = 5 / m.s; g.stroke();
    const p0 = T.pts[0];
    g.fillStyle = '#fff'; g.fillRect(p0[0] - 4 / m.s, p0[1] - 4 / m.s, 8 / m.s, 8 / m.s);
    const sorted = list.slice().sort((a, b) => (a.id === S.you) - (b.id === S.you));
    for (const v of sorted) {
      const me = v.id === S.you;
      g.fillStyle = colorOf(v.id);
      g.strokeStyle = me ? '#fff' : '#000';
      g.lineWidth = (me ? 2.5 : 1) / m.s;
      g.beginPath(); g.arc(v.x, v.y, (me ? 6 : 4) / m.s, 0, 7); g.fill(); g.stroke();
    }
    g.restore();
  }

  const hudCache = {};
  function setText(id, val) { if (hudCache[id] !== val) { hudCache[id] = val; $(id).textContent = val; } }

  function updateHud(now, view, me, list, dt) {
    // countdown
    if (S.countEnd) {
      const left = S.countEnd - now;
      const n = Math.ceil(left / 1000);
      if (n !== S.lastCount) {
        S.lastCount = n;
        if (n > 3) showCenter('GET READY', 0, 'pop');
        else if (n >= 1) { showCenter(String(n), 0, 'pop'); Snd.beep(440, 0.25, 0.3); }
      }
    }
    const banner = $('banner');
    if (S.graceEnd && S.phase === 'race') {
      const s = Math.max(0, Math.ceil((S.graceEnd - now) / 1000));
      banner.textContent = `🏁 Race ends in ${s}s`;
      banner.classList.add('show');
    } else banner.classList.remove('show');

    setText('hPosOf', '/ ' + list.length);
    const SPEC = '👀 Spectating. You will join the next race.';
    if (me && hudCache.subMsg === SPEC) setText('subMsg', '');
    if (me) {
      setText('hPos', String(me.place || '-'));
      setText('hLap', `${clamp(me.lap + 1, 1, S.laps)}/${S.laps}`);
      setText('hSpeed', String(Math.round(me.spd * KMH)));
      setText('hBest', me.best ? fmtTime(me.best) : '--');
      $('hNitro').style.width = me.nitro + '%';
      if (me.f & FLAG.FINISHED) {
        setText('subMsg', `Finished ${ordinal(me.place)}! Waiting for the others…`);
      } else if (me.f & FLAG.WRONGWAY) {
        if ($('centerMsg').textContent !== 'WRONG WAY!') showCenter('WRONG WAY!', 0, 'warn');
      } else if ($('centerMsg').textContent === 'WRONG WAY!') showCenter('', 0);
      if (S.phase === 'race' && !(me.f & FLAG.FINISHED) && me.spd < 30 && !(me.f & FLAG.CRASHED)) stuckT += dt; else stuckT = 0;
      if (stuckT > 2.5 && !hudCache.subMsg) setText('subMsg', 'Stuck? Press R to respawn');
      else if (stuckT === 0 && hudCache.subMsg === 'Stuck? Press R to respawn') setText('subMsg', '');
      Snd.engine(me.spd, !!(me.f & FLAG.NITRO), S.phase === 'race' && !(me.f & FLAG.FINISHED) || !!S.countEnd);
    } else {
      setText('hPos', '-'); setText('hLap', '-'); setText('hSpeed', '0');
      if ((S.phase === 'race' || S.phase === 'countdown') && S.snaps.length) setText('subMsg', SPEC);
      Snd.engineOff();
    }
    setText('hTime', fmtTime(view && S.phase === 'race' ? Math.max(0, view.rt) : 0));

    boardTimer -= dt;
    if (boardTimer <= 0) {
      boardTimer = 0.25;
      const rows = list.slice().sort((a, b) => a.place - b.place).map((v) =>
        `<div class="${v.id === S.you ? 'me' : ''}"><span class="p">${v.place}</span><i style="background:${esc(colorOf(v.id))}"></i>${esc(nameOf(v.id))}${v.f & FLAG.FINISHED ? ' 🏁' : ''}</div>`).join('');
      if (hudCache.board !== rows) { hudCache.board = rows; $('board').innerHTML = rows; }
    }
    if (!$('results').classList.contains('hidden') && S.resultsEnd) {
      setText('resTimer', `Back to the room in ${Math.max(0, Math.ceil((S.resultsEnd - now) / 1000))}s`);
    }
  }

  requestAnimationFrame(frame);

  // =====================================================================
  // Input
  // =====================================================================
  const KEYMAP = {
    ArrowUp: IN.UP, KeyW: IN.UP, ArrowDown: IN.DOWN, KeyS: IN.DOWN,
    ArrowLeft: IN.LEFT, KeyA: IN.LEFT, ArrowRight: IN.RIGHT, KeyD: IN.RIGHT,
    Space: IN.NITRO, ShiftLeft: IN.DRIFT, ShiftRight: IN.DRIFT,
  };
  function bits() {
    let b = S.touchBits;
    for (const k of S.keys) b |= KEYMAP[k] || 0;
    return b;
  }
  function sendInput(force) {
    if (S.screen !== 'game') return;
    const b = bits();
    if (force || b !== S.lastBits) { S.lastBits = b; send({ t: 'i', k: b }); }
  }
  setInterval(() => sendInput(true), 120);

  const typing = () => document.activeElement && document.activeElement.tagName === 'INPUT';
  window.addEventListener('keydown', (e) => {
    Snd.init();
    if (S.screen !== 'game') return;
    if (e.code === 'Enter') {
      const f = $('gameChat');
      if (f.classList.contains('hidden')) { e.preventDefault(); f.classList.remove('hidden'); S.keys.clear(); sendInput(true); $('gameChatInput').focus(); }
      return;
    }
    if (e.code === 'Escape' && typing()) { $('gameChat').classList.add('hidden'); $('gameChatInput').blur(); return; }
    if (typing()) return;
    if (KEYMAP[e.code]) { e.preventDefault(); S.keys.add(e.code); sendInput(); }
    if (e.repeat) return;
    if (e.code === 'KeyR') send({ t: 'respawn' });
    if (e.code === 'KeyH') send({ t: 'honk' });
    if (e.code === 'KeyM') toggleMute();
    if (e.code === 'KeyC') cycleCam();
  });
  window.addEventListener('keyup', (e) => { if (KEYMAP[e.code]) { S.keys.delete(e.code); sendInput(); } });
  window.addEventListener('blur', () => { S.keys.clear(); S.touchBits = 0; sendInput(true); });

  $('gameChat').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('gameChatInput').value.trim();
    if (v) send({ t: 'chat', text: v });
    $('gameChatInput').value = '';
    $('gameChat').classList.add('hidden');
    $('gameChatInput').blur();
  });

  // touch controls
  const isTouch = ('ontouchstart' in window || navigator.maxTouchPoints > 0) && window.matchMedia('(pointer: coarse)').matches;
  if (isTouch) $('touch').classList.add('show');
  document.querySelectorAll('#touch button').forEach((b) => {
    const k = Number(b.dataset.k);
    const down = (e) => { e.preventDefault(); Snd.init(); b.classList.add('down'); S.touchBits |= k; sendInput(); };
    const up = (e) => { e.preventDefault(); b.classList.remove('down'); S.touchBits &= ~k; sendInput(); };
    b.addEventListener('pointerdown', down);
    b.addEventListener('pointerup', up);
    b.addEventListener('pointercancel', up);
    b.addEventListener('pointerleave', up);
  });

  // =====================================================================
  // UI wiring
  // =====================================================================
  $('nameInput').addEventListener('input', (e) => { S.profile.name = e.target.value.slice(0, 16); saveProfile(); });
  $('nameInput').addEventListener('change', () => profileChanged());
  document.querySelectorAll('.kind').forEach((b) => {
    b.onclick = () => { S.profile.kind = b.dataset.kind; profileChanged(); if (S.room) renderRoom(); };
  });
  document.querySelectorAll('[data-step]').forEach((b) => {
    b.onclick = () => {
      const [k, d] = b.dataset.step.split(':');
      const lim = k === 'laps' ? [1, 9] : [0, 7];
      S.create[k] = clamp(S.create[k] + Number(d), lim[0], lim[1]);
      $('cLaps').textContent = S.create.laps; $('cBots').textContent = S.create.bots;
    };
  });
  document.querySelectorAll('[data-rstep]').forEach((b) => {
    b.onclick = () => {
      if (!S.room) return;
      const [k, d] = b.dataset.rstep.split(':');
      send({ t: 'settings', [k]: S.room.settings[k] + Number(d) });
    };
  });
  document.querySelectorAll('#botLevel button').forEach((b) => { b.onclick = () => send({ t: 'settings', botLevel: b.dataset.v }); });
  $('collToggle').onclick = () => S.room && send({ t: 'settings', collisions: !S.room.settings.collisions });
  $('createBtn').onclick = () => {
    if (!ensureName()) return;
    Snd.init();
    send({ t: 'profile', ...S.profile });
    send({ t: 'create', ...S.create });
  };
  $('joinCodeBtn').onclick = () => { const c = $('codeInput').value.trim().toUpperCase(); if (c.length === 4) joinRoom(c); };
  $('codeInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('joinCodeBtn').click(); });
  $('leaveBtn').onclick = () => send({ t: 'leave' });
  $('startBtn').onclick = () => { Snd.init(); send({ t: 'start' }); };
  $('chatForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('chatInput').value.trim();
    if (v) send({ t: 'chat', text: v });
    $('chatInput').value = '';
  });
  $('againBtn').onclick = () => {
    if (isHost()) send({ t: 'again' });
    else { $('results').classList.add('hidden'); show('room'); }
  };
  $('muteBtn').onclick = () => toggleMute();
  $('exitBtn').onclick = () => { if (confirmLeave()) send({ t: 'leave' }); };
  function confirmLeave() { return S.phase !== 'race' || window.confirm('Leave the race?'); }
  document.querySelectorAll('#hofTabs button').forEach((b) => {
    b.onclick = () => {
      S.hofTab = b.dataset.tab;
      document.querySelectorAll('#hofTabs button').forEach((x) => x.classList.toggle('on', x === b));
      renderHof();
    };
  });
  const CAM_NAMES = { chase: '🎥 Chase cam', hood: '🎥 Driver cam', top: '🎥 Top view' };
  function cycleCam() {
    const order = R3 ? ['chase', 'hood', 'top'] : ['top'];
    S.camMode = order[(order.indexOf(S.camMode) + 1) % order.length];
    try { localStorage.setItem('speedway.cam', S.camMode); } catch (e) { /* */ }
    popText(CAM_NAMES[S.camMode]);
  }
  $('camBtn').onclick = () => cycleCam();
  function toggleMute() { Snd.setMuted(!Snd.muted); $('muteBtn').textContent = Snd.muted ? '🔇' : '🔊'; }

  let toastTimer = null;
  function toast(msg, err, ms) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast' + (err ? ' err' : '');
    clearTimeout(toastTimer);
    if (ms !== 0) toastTimer = setTimeout(hideToast, ms || 3000);
  }
  function hideToast() { $('toast').classList.add('hidden'); }

  // =====================================================================
  // Sound (WebAudio, all synthesized - no files needed)
  // =====================================================================
  const Snd = {
    ctx: null, master: null, muted: localStorage.getItem('speedway.muted') === '1', eng: null, noise: null,
    init() {
      if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      try { this.ctx = new AC(); } catch (e) { return; }
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.7;
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    },
    setMuted(m) {
      this.muted = m;
      try { localStorage.setItem('speedway.muted', m ? '1' : '0'); } catch (e) { /* */ }
      if (this.master) this.master.gain.value = m ? 0 : 0.7;
    },
    engine(speed, nitro, on) {
      if (!this.ctx || !on) { this.engineOff(); return; }
      if (!this.eng) {
        const c = this.ctx;
        const o1 = c.createOscillator(), o2 = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
        o1.type = 'sawtooth'; o2.type = 'square';
        f.type = 'lowpass'; f.frequency.value = 600;
        g.gain.value = 0;
        o1.connect(f); o2.connect(f); f.connect(g); g.connect(this.master);
        o1.start(); o2.start();
        this.eng = { o1, o2, f, g };
      }
      const t = this.ctx.currentTime;
      const base = 38 + speed * 0.19 + (nitro ? 30 : 0);
      this.eng.o1.frequency.setTargetAtTime(base, t, 0.05);
      this.eng.o2.frequency.setTargetAtTime(base * 0.5 + 1.5, t, 0.05);
      this.eng.f.frequency.setTargetAtTime(400 + speed * 1.6 + (nitro ? 900 : 0), t, 0.08);
      this.eng.g.gain.setTargetAtTime(0.05 + Math.min(0.05, speed / 9000), t, 0.1);
    },
    engineOff() {
      if (!this.eng) return;
      const e = this.eng; this.eng = null;
      try { e.g.gain.setTargetAtTime(0, this.ctx.currentTime, 0.05); setTimeout(() => { e.o1.stop(); e.o2.stop(); }, 400); } catch (err) { /* */ }
    },
    tone(type, f0, f1, dur, vol, delay) {
      if (!this.ctx || vol <= 0.01) return;
      const c = this.ctx, t = c.currentTime + (delay || 0);
      const o = c.createOscillator(), g = c.createGain();
      o.type = type; o.frequency.setValueAtTime(f0, t);
      if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.connect(g); g.connect(this.master); o.start(t); o.stop(t + dur + 0.05);
    },
    noiseBurst(dur, vol, freq, q) {
      if (!this.ctx || vol <= 0.01) return;
      const c = this.ctx, t = c.currentTime;
      const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      s.buffer = this.noise; f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q || 0.8;
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      s.connect(f); f.connect(g); g.connect(this.master); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
    },
    beep(f, dur, vol) { this.tone('square', f, 0, dur, vol || 0.25); },
    crash(v) { this.noiseBurst(0.35, 0.6 * v, 900, 0.6); this.tone('sawtooth', 160, 50, 0.25, 0.25 * v); },
    thud(v) { this.noiseBurst(0.2, 0.5 * v, 300, 1); this.tone('sine', 120, 40, 0.2, 0.4 * v); },
    thunk(v) { this.tone('sine', 180, 60, 0.18, v == null ? 0.5 : v); },
    squish() { this.noiseBurst(0.3, 0.35, 2500, 2); this.tone('sine', 600, 200, 0.3, 0.12); },
    whoosh() {
      if (!this.ctx) return;
      const c = this.ctx, t = c.currentTime;
      const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      s.buffer = this.noise; f.type = 'bandpass'; f.Q.value = 3;
      f.frequency.setValueAtTime(300, t); f.frequency.exponentialRampToValueAtTime(3000, t + 0.5);
      g.gain.setValueAtTime(0.4, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
      s.connect(f); f.connect(g); g.connect(this.master); s.start(t); s.stop(t + 0.65);
    },
    horn(v) {
      if (v <= 0.02) return;
      this.tone('square', 392, 0, 0.32, 0.18 * v); this.tone('square', 494, 0, 0.32, 0.14 * v);
      this.tone('square', 392, 0, 0.25, 0.18 * v, 0.38); this.tone('square', 494, 0, 0.25, 0.14 * v, 0.38);
    },
    ding() { this.tone('sine', 1320, 0, 0.5, 0.25); this.tone('sine', 1760, 0, 0.6, 0.15, 0.08); },
    fanfare(place) {
      const notes = place === 1 ? [523, 659, 784, 1047] : place <= 3 ? [523, 659, 784] : [392, 523];
      notes.forEach((n, i) => this.tone('square', n, 0, 0.3, 0.18, i * 0.14));
    },
  };

  // =====================================================================
  connect();
})();
