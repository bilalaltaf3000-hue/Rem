// Bilal's Speedway - 3D renderer (three.js). The server simulates a flat 2D world;
// here 2D (x, y) becomes three.js (x, z) with y pointing up.

export function createRenderer3D(THREE, canvas, H) {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  } catch (e) {
    return { ok: false };
  }
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const maxAniso = renderer.capabilities.getMaxAnisotropy();
  const maxTex = renderer.capabilities.maxTextureSize;

  const scene = new THREE.Scene();
  const SKY = new THREE.Color('#8fc8ff');
  scene.background = SKY;
  scene.fog = new THREE.Fog(SKY, 700, 2600);
  const camera = new THREE.PerspectiveCamera(68, 16 / 9, 2, 6000);
  scene.add(new THREE.HemisphereLight('#dff1ff', '#4a6b2f', 1.6));
  const sun = new THREE.DirectionalLight('#fff4dc', 1.8);
  sun.position.set(0.5, 1, 0.3);
  scene.add(sun);

  const trackGroup = new THREE.Group();
  scene.add(trackGroup);
  let trackId = null;
  const vehicles = new Map();
  const cam = { h: 0, init: false, pos: new THREE.Vector3(), look: new THREE.Vector3(), fov: 68 };
  const tmpV = new THREE.Vector3();

  // ---------- helpers ----------
  const canvasTex = (c, repeat) => {
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = maxAniso;
    if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
    return t;
  };
  const roundTex = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d');
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.6)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    return canvasTex(c);
  })();
  const shadowTex = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d');
    const gr = g.createRadialGradient(32, 32, 4, 32, 32, 32);
    gr.addColorStop(0, 'rgba(0,0,0,0.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    return canvasTex(c);
  })();
  const lam = (color, extra) => new THREE.MeshLambertMaterial(Object.assign({ color }, extra || {}));

  function disposeGroup(g) {
    g.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        const ms = Array.isArray(o.material) ? o.material : [o.material];
        ms.forEach((m) => { if (m.map && m.map !== roundTex && m.map !== shadowTex) m.map.dispose(); m.dispose(); });
      }
    });
    while (g.children.length) g.remove(g.children[0]);
  }

  // ---------- track ----------
  function setTrack(T) {
    if (trackId === T.id) return;
    trackId = T.id;
    disposeGroup(trackGroup);
    for (const v of vehicles.values()) removeVehicle(v);
    vehicles.clear();
    cam.init = false;
    const b = T.bounds;

    // far ground
    const far = new THREE.Mesh(new THREE.PlaneGeometry(30000, 30000), lam(T.bg || '#5ea94a'));
    far.rotation.x = -Math.PI / 2;
    far.position.set(b.x + b.w / 2, -0.6, b.y + b.h / 2);
    trackGroup.add(far);

    // textured ground (track, curbs, hazards painted on)
    let gc = H.groundCanvas(T);
    if (gc.width > maxTex || gc.height > maxTex) {
      const s = maxTex / Math.max(gc.width, gc.height);
      const c2 = document.createElement('canvas');
      c2.width = Math.floor(gc.width * s); c2.height = Math.floor(gc.height * s);
      c2.getContext('2d').drawImage(gc, 0, 0, c2.width, c2.height);
      gc = c2;
    }
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(b.w, b.h), new THREE.MeshLambertMaterial({ map: canvasTex(gc) }));
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(b.x + b.w / 2, 0, b.y + b.h / 2);
    trackGroup.add(ground);

    // tyre walls along both edges
    const stripe = document.createElement('canvas'); stripe.width = 64; stripe.height = 16;
    const sg = stripe.getContext('2d');
    sg.fillStyle = '#e8e8e8'; sg.fillRect(0, 0, 32, 16); sg.fillStyle = '#d63031'; sg.fillRect(32, 0, 32, 16);
    sg.fillStyle = 'rgba(0,0,0,0.25)'; sg.fillRect(0, 12, 64, 4);
    const wallMat = new THREE.MeshLambertMaterial({ map: canvasTex(stripe, true), side: THREE.DoubleSide });
    for (const side of [-1, 1]) {
      const off = (T.half + T.runoff + 4) * side;
      const pos = [], uv = [], idx = [];
      let dist = 0;
      for (let i = 0; i <= T.N; i++) {
        const k = i % T.N, p = T.pts[k], t = T.tan[k];
        if (i > 0) { const q = T.pts[(i - 1) % T.N]; dist += Math.hypot(p[0] - q[0], p[1] - q[1]); }
        const x = p[0] - t[1] * off, z = p[1] + t[0] * off;
        pos.push(x, 0, z, x, 15, z);
        uv.push(dist / 48, 0, dist / 48, 1);
        if (i > 0) { const a = (i - 1) * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
      geo.setIndex(idx);
      geo.computeVertexNormals();
      trackGroup.add(new THREE.Mesh(geo, wallMat));
    }

    // decorations
    const dummy = new THREE.Object3D();
    const trees = T.decor.filter((d) => d.type === 'tree');
    const rocks = T.decor.filter((d) => d.type === 'rock');
    const blds = T.decor.filter((d) => d.type === 'building');
    if (trees.length) {
      const pine = T.theme === 'mountain';
      const crownGeo = pine ? new THREE.ConeGeometry(1, 2.4, 8) : new THREE.IcosahedronGeometry(1, 1);
      const crowns = new THREE.InstancedMesh(crownGeo, lam('#ffffff', { flatShading: true }), trees.length);
      const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.18, 0.25, 1, 6), lam('#6b4a2b'), trees.length);
      const col = new THREE.Color();
      trees.forEach((d, i) => {
        const r = d.r;
        dummy.position.set(d.x, r * 0.6, d.y); dummy.scale.set(r * 0.5, r * 1.2, r * 0.5); dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix(); trunks.setMatrixAt(i, dummy.matrix);
        dummy.position.set(d.x, pine ? r * 2.2 : r * 1.9, d.y);
        dummy.scale.set(r, r * (pine ? 1.1 : 0.9), r);
        dummy.rotation.set(0, d.x % 6, 0);
        dummy.updateMatrix(); crowns.setMatrixAt(i, dummy.matrix);
        crowns.setColorAt(i, col.set(d.color));
      });
      trackGroup.add(crowns, trunks);
    }
    if (rocks.length) {
      const rm = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1, 0), lam('#ffffff', { flatShading: true }), rocks.length);
      const col = new THREE.Color();
      rocks.forEach((d, i) => {
        dummy.position.set(d.x, d.r * 0.3, d.y); dummy.scale.set(d.r, d.r * 0.7, d.r * 0.9); dummy.rotation.set(d.x % 3, d.y % 3, 0);
        dummy.updateMatrix(); rm.setMatrixAt(i, dummy.matrix); rm.setColorAt(i, col.set(d.color));
      });
      trackGroup.add(rm);
    }
    if (blds.length) {
      const bm = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), lam('#ffffff'), blds.length);
      const col = new THREE.Color();
      blds.forEach((d, i) => {
        const h = d.hgt;
        dummy.position.set(d.x, h / 2, d.y); dummy.scale.set(d.w, h, d.h); dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix(); bm.setMatrixAt(i, dummy.matrix); bm.setColorAt(i, col.set(d.color));
      });
      trackGroup.add(bm);
    }

    // start gantry
    const p0 = T.pts[0], t0 = T.tan[0];
    const gantry = new THREE.Group();
    const postMat = lam('#30343f');
    const span = T.half + 22;
    for (const s of [-1, 1]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(6, 80, 6), postMat);
      post.position.set(0, 40, s * span);
      gantry.add(post);
    }
    const bc = document.createElement('canvas'); bc.width = 1024; bc.height = 128;
    const bg = bc.getContext('2d');
    bg.fillStyle = '#14161c'; bg.fillRect(0, 0, 1024, 128);
    for (let x = 0; x < 1024; x += 16) for (let y = 0; y < 2; y++) { bg.fillStyle = ((x / 16 + y) % 2) ? '#fff' : '#111'; bg.fillRect(x, y * 16, 16, 16); bg.fillRect(x, 96 + y * 16, 16, 16); }
    bg.font = 'italic 64px Impact, Arial Black, sans-serif'; bg.textAlign = 'center'; bg.textBaseline = 'middle';
    bg.fillStyle = '#ffd23f'; bg.fillText("BILAL'S SPEEDWAY", 512, 66);
    const textMat = new THREE.MeshLambertMaterial({ map: canvasTex(bc) });
    const darkMat = lam('#14161c');
    // box face order: +x, -x, +y, -y, +z, -z. Local x runs along the track, so the text goes on the x faces.
    const banner = new THREE.Mesh(new THREE.BoxGeometry(4, 22, span * 2 + 6), [textMat, textMat, darkMat, darkMat, darkMat, darkMat]);
    banner.position.set(0, 72, 0);
    gantry.add(banner);
    gantry.position.set(p0[0], 0, p0[1]);
    gantry.rotation.y = -Math.atan2(t0[1], t0[0]);
    trackGroup.add(gantry);

    // distant hills (no fog so they read as a horizon)
    const hillMat = new THREE.MeshLambertMaterial({ color: T.theme === 'city' ? '#9fb4c8' : T.theme === 'mountain' ? '#7c9a8c' : '#8fb39a', fog: false, flatShading: true });
    const cx = b.x + b.w / 2, cz = b.y + b.h / 2, R = Math.max(b.w, b.h) * 1.1 + 900;
    const hills = new THREE.InstancedMesh(new THREE.ConeGeometry(1, 1, 6), hillMat, 36);
    for (let i = 0; i < 36; i++) {
      const a = (i / 36) * Math.PI * 2 + (i % 3) * 0.05;
      const h = (T.theme === 'mountain' ? 650 : 300) + ((i * 97) % 7) * 70;
      const w = 500 + ((i * 53) % 5) * 120;
      dummy.position.set(cx + Math.cos(a) * R, h / 2 - 20, cz + Math.sin(a) * R);
      dummy.scale.set(w, h, w); dummy.rotation.set(0, i, 0); dummy.updateMatrix();
      hills.setMatrixAt(i, dummy.matrix);
    }
    trackGroup.add(hills);
  }

  // ---------- vehicles ----------
  function shade(hex, amt) {
    const c = new THREE.Color(hex);
    const hsl = {}; c.getHSL(hsl);
    c.setHSL(hsl.h, hsl.s, Math.max(0, Math.min(1, hsl.l + amt)));
    return c;
  }

  function buildCar(color) {
    const g = new THREE.Group();
    const L = 36, W = 19;
    const paint = new THREE.MeshLambertMaterial({ color });
    const dark = lam(shade(color, -0.25));
    const glass = lam('#1a2433');
    const black = lam('#151515');
    const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); g.add(m); return m; };
    add(new THREE.BoxGeometry(L, 4, W + 0.5), dark, 0, 4.5, 0);
    add(new THREE.BoxGeometry(L, 5, W), paint, 0, 8.5, 0);
    add(new THREE.BoxGeometry(L * 0.28, 1.2, W * 0.75), paint, L * 0.3, 11.4, 0); // bonnet bulge
    add(new THREE.BoxGeometry(L * 0.46, 6, W * 0.84), glass, -L * 0.06, 13.8, 0);
    add(new THREE.BoxGeometry(L * 0.36, 1.2, W * 0.8), paint, -L * 0.08, 17.2, 0);
    add(new THREE.BoxGeometry(L * 0.5, 0.4, W * 0.18), lam('#ffffff'), L * 0.25, 11.1, 0);
    add(new THREE.BoxGeometry(3, 1.2, W + 1), dark, -L / 2 + 2, 16, 0); // spoiler
    add(new THREE.BoxGeometry(1, 4, 1), dark, -L / 2 + 2, 13, -W * 0.3);
    add(new THREE.BoxGeometry(1, 4, 1), dark, -L / 2 + 2, 13, W * 0.3);
    const hl = new THREE.MeshBasicMaterial({ color: '#fff6c4' });
    const tl = new THREE.MeshBasicMaterial({ color: '#ff2030' });
    add(new THREE.BoxGeometry(0.6, 2, 3.5), hl, L / 2 + 0.2, 8.5, -W * 0.33);
    add(new THREE.BoxGeometry(0.6, 2, 3.5), hl, L / 2 + 0.2, 8.5, W * 0.33);
    add(new THREE.BoxGeometry(0.6, 2, 4), tl, -L / 2 - 0.2, 9, -W * 0.32);
    add(new THREE.BoxGeometry(0.6, 2, 4), tl, -L / 2 - 0.2, 9, W * 0.32);
    const wheelGeo = new THREE.CylinderGeometry(4.2, 4.2, 3.6, 14); wheelGeo.rotateX(Math.PI / 2);
    const hubGeo = new THREE.CylinderGeometry(1.8, 1.8, 3.8, 8); hubGeo.rotateX(Math.PI / 2);
    const wheels = [];
    for (const [x, z] of [[L * 0.3, W / 2], [L * 0.3, -W / 2], [-L * 0.3, W / 2], [-L * 0.3, -W / 2]]) {
      const w = new THREE.Group();
      w.add(new THREE.Mesh(wheelGeo, black));
      w.add(new THREE.Mesh(hubGeo, lam('#9aa0a8')));
      w.position.set(x, 4.2, z);
      g.add(w); wheels.push(w);
    }
    return { g, wheels, L, W, radius: 4.2, flameX: -L / 2 - 1, flameZ: [W * 0.25, -W * 0.25], flameY: 6 };
  }

  function buildBike(color) {
    const g = new THREE.Group();
    const L = 30;
    const paint = new THREE.MeshLambertMaterial({ color });
    const suit = lam(shade(color, -0.3));
    const black = lam('#151515');
    const add = (geo, mat, x, y, z, parent) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); (parent || g).add(m); return m; };
    const wheelGeo = new THREE.CylinderGeometry(5, 5, 2.4, 14); wheelGeo.rotateX(Math.PI / 2);
    const wheels = [];
    for (const x of [L * 0.36, -L * 0.36]) { const w = add(wheelGeo, black, x, 5, 0); wheels.push(w); }
    add(new THREE.BoxGeometry(L * 0.62, 5, 4), lam('#333'), 0, 9, 0);
    add(new THREE.BoxGeometry(L * 0.34, 6, 6.5), paint, L * 0.16, 12, 0);
    add(new THREE.BoxGeometry(L * 0.22, 3, 5), paint, -L * 0.2, 12.5, 0);
    add(new THREE.BoxGeometry(1.2, 1.2, 12), lam('#bbbbbb'), L * 0.26, 16, 0);
    add(new THREE.BoxGeometry(0.6, 2, 2.5), new THREE.MeshBasicMaterial({ color: '#fff6c4' }), L * 0.34 + 0.3, 12, 0);
    add(new THREE.BoxGeometry(0.6, 1.5, 2.5), new THREE.MeshBasicMaterial({ color: '#ff2030' }), -L * 0.32, 13, 0);
    const rider = new THREE.Group();
    add(new THREE.BoxGeometry(8, 10, 7), suit, 0, 19, 0, rider).rotation.z = -0.5;
    add(new THREE.SphereGeometry(4.3, 12, 10), paint, 3.5, 25.5, 0, rider);
    add(new THREE.BoxGeometry(2, 2.6, 5.2), lam('#1a2433'), 6.8, 25.6, 0, rider);
    add(new THREE.BoxGeometry(3, 3, 9), suit, 2, 14, 0, rider);
    g.add(rider);
    return { g, wheels, rider, L, W: 10, radius: 5, flameX: -L / 2, flameZ: [0], flameY: 9, bike: true };
  }

  function makeLabel(text, color) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 64;
    const g = c.getContext('2d');
    g.font = 'bold 30px Segoe UI, Arial, sans-serif';
    const w = Math.min(250, g.measureText(text).width + 34);
    g.fillStyle = 'rgba(0,0,0,0.6)';
    const x = (256 - w) / 2;
    g.beginPath(); g.moveTo(x + 18, 8); g.lineTo(x + w - 18, 8); g.arc(x + w - 18, 32, 24, -Math.PI / 2, Math.PI / 2); g.lineTo(x + 18, 56); g.arc(x + 18, 32, 24, Math.PI / 2, Math.PI * 1.5); g.fill();
    g.fillStyle = color; g.beginPath(); g.arc(x + 18, 32, 7, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.textBaseline = 'middle'; g.fillText(text, x + 30, 33);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: canvasTex(c), depthWrite: false, depthTest: true, fog: false, sizeAttenuation: false }));
    s.scale.set(0.13, 0.0325, 1);
    return s;
  }

  function makeVehicle(id, kind, color) {
    const m = kind === 'bike' ? buildBike(color) : buildCar(color);
    m.g.rotation.order = 'YXZ';
    const root = new THREE.Group();
    root.add(m.g);
    const flames = m.flameZ.map((z) => {
      const geo = new THREE.ConeGeometry(2.6, 16, 8); geo.rotateZ(Math.PI / 2); geo.translate(-8, 0, 0);
      const f = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: '#7fd3ff', transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }));
      f.position.set(m.flameX, m.flameY, z);
      f.visible = false;
      m.g.add(f);
      return f;
    });
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2;
    shadow.scale.set(m.L * 1.4, m.W * 1.8, 1);
    scene.add(shadow);
    scene.add(root);
    return { id, kind, color, root, m, flames, shadow, label: null, labelText: '', lastA: null, lean: 0, honk: null };
  }

  function removeVehicle(v) {
    scene.remove(v.root); scene.remove(v.shadow);
    disposeGroup(v.root);
    v.shadow.geometry.dispose(); v.shadow.material.dispose();
  }

  // ---------- particles ----------
  const MAXP = 900;
  function makePoints(size, blending) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(MAXP * 3), 3));
    geo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(MAXP * 4), 4));
    geo.setDrawRange(0, 0);
    const mat = new THREE.PointsMaterial({ size, map: roundTex, vertexColors: true, transparent: true, depthWrite: false, blending });
    const p = new THREE.Points(geo, mat);
    p.frustumCulled = false;
    scene.add(p);
    return p;
  }
  const sparkPts = makePoints(7, THREE.AdditiveBlending);
  const smokePts = makePoints(18, THREE.NormalBlending);
  const colCache = new Map();
  function rgbOf(c) {
    let v = colCache.get(c);
    if (!v) {
      if (c[0] === '#') { const col = new THREE.Color(c); v = [col.r, col.g, col.b]; }
      else { const a = c.split(',').map(Number); v = [a[0] / 255, a[1] / 255, a[2] / 255]; }
      colCache.set(c, v);
    }
    return v;
  }
  function drawParticles(list) {
    let ns = 0, nm = 0;
    const sp = sparkPts.geometry.attributes, sm = smokePts.geometry.attributes;
    for (const p of list) {
      const k = p.life / p.max;
      const rgb = rgbOf(p.color);
      if (p.type === 'smoke') {
        if (nm >= MAXP) continue;
        sm.position.array.set([p.x, 4 + (1 - k) * 22, p.y], nm * 3);
        sm.color.array.set([rgb[0], rgb[1], rgb[2], 0.45 * k], nm * 4);
        nm++;
      } else {
        if (ns >= MAXP) continue;
        if (p.h3 == null) p.h3 = 6 + Math.random() * 10;
        sp.position.array.set([p.x, p.h3 * k + (p.type === 'chunk' ? 2 : 0), p.y], ns * 3);
        sp.color.array.set([rgb[0], rgb[1], rgb[2], Math.min(1, k * 2)], ns * 4);
        ns++;
      }
    }
    sp.position.needsUpdate = true; sp.color.needsUpdate = true; sparkPts.geometry.setDrawRange(0, ns);
    sm.position.needsUpdate = true; sm.color.needsUpdate = true; smokePts.geometry.setDrawRange(0, nm);
  }

  // ---------- frame ----------
  const angDiff = (a, b) => { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; };

  function render(st) {
    const { list, focusId, youId, dt, now, mode, particles, shake, F } = st;
    const seen = new Set();
    let focusObj = null, focusV = null;
    for (const v of list) {
      seen.add(v.id);
      const kind = H.kindOf(v.id), color = H.colorOf(v.id);
      let o = vehicles.get(v.id);
      if (o && (o.kind !== kind || o.color !== color)) { removeVehicle(o); o = null; }
      if (!o) { o = makeVehicle(v.id, kind, color); vehicles.set(v.id, o); }
      const air = v.f & F.AIR ? Math.sin(Math.PI * Math.min(1, v.air / 100)) : 0;
      const hop = air * (kind === 'bike' ? 24 : 15);
      o.root.position.set(v.x, hop, v.y);
      o.m.g.rotation.y = -v.a;
      // lean / roll from turn rate
      if (o.lastA == null) o.lastA = v.a;
      const rate = dt > 0 ? angDiff(o.lastA, v.a) / dt : 0;
      o.lastA = v.a;
      const spinning = v.f & F.SPIN;
      let targetLean = spinning ? 0 : (o.m.bike ? Math.max(-0.55, Math.min(0.55, rate * 0.22 * Math.min(1, v.spd / 200))) : Math.max(-0.08, Math.min(0.08, -rate * 0.04)));
      if (o.m.bike && (v.f & F.CRASHED)) targetLean = 1.35;
      o.lean += (targetLean - o.lean) * Math.min(1, dt * (v.f & F.CRASHED ? 6 : 8));
      o.m.g.rotation.x = o.lean;
      o.m.g.rotation.z = air * (kind === 'bike' ? 0.35 : 0.12) * (v.air < 50 ? 1 : -0.6);
      if (o.m.rider) o.m.rider.position.set(v.f & F.CRASHED ? -10 : 0, v.f & F.CRASHED ? -6 : 0, v.f & F.CRASHED ? 10 : 0);
      for (const w of o.m.wheels) w.rotation.z -= (v.spd * dt) / o.m.radius;
      const nitro = !!(v.f & F.NITRO);
      for (const f of o.flames) { f.visible = nitro; if (nitro) { const s = 0.7 + Math.random() * 0.6; f.scale.set(s, 1, 1); f.material.color.set(Math.random() < 0.5 ? '#7fd3ff' : '#c08bff'); } }
      const ghost = !!(v.f & F.GHOST);
      if (ghost !== !!o.ghost) {
        o.ghost = ghost;
        o.m.g.traverse((x) => {
          if (!x.material || Array.isArray(x.material) || x.material.blending === THREE.AdditiveBlending) return;
          x.material.transparent = ghost; x.material.opacity = ghost ? 0.45 : 1; x.material.needsUpdate = true;
        });
      }
      o.shadow.position.set(v.x, 0.5, v.y);
      o.shadow.rotation.z = -v.a;
      o.shadow.material.opacity = 1 - air * 0.6;
      // label
      const isYou = v.id === youId;
      const text = `${v.place}. ${H.nameOf(v.id)}`;
      if (!isYou) {
        if (o.labelText !== text) {
          if (o.label) { o.root.remove(o.label); o.label.material.map.dispose(); o.label.material.dispose(); }
          o.label = makeLabel(text, color); o.labelText = text;
          o.label.position.set(0, kind === 'bike' ? 42 : 34, 0);
          o.root.add(o.label);
        }
        const hk = st.honks.get(v.id);
        const big = hk && hk > now ? 1.35 : 1;
        o.label.scale.set(0.13 * big, 0.0325 * big, 1);
        const d = camera.position.distanceTo(o.root.position);
        o.label.visible = d > 45 && d < 1600;
      } else if (o.label) { o.root.remove(o.label); o.label = null; o.labelText = ''; }
      if (v.id === focusId) { focusObj = o; focusV = v; }
    }
    for (const [id, o] of vehicles) if (!seen.has(id)) { removeVehicle(o); vehicles.delete(id); }

    // hide own model in bonnet cam for bikes (rider would block the view)
    if (focusObj && focusObj.m.rider) focusObj.m.rider.visible = !(mode === 'hood' && focusV.id === youId);

    // camera
    if (focusV) {
      const crashed = focusV.f & (F.SPIN | F.CRASHED);
      if (!cam.init) { cam.h = focusV.a; }
      cam.h += angDiff(cam.h, focusV.a) * Math.min(1, dt * (crashed ? 1.2 : 5));
      const fx = Math.cos(cam.h), fz = Math.sin(cam.h);
      const hopY = focusObj.root.position.y;
      let px, py, pz, lx, ly, lz, fov;
      if (mode === 'hood') {
        const isBike = focusObj.m.bike;
        const ax = Math.cos(focusV.a), az = Math.sin(focusV.a);
        px = focusV.x + ax * (isBike ? 4 : 9); pz = focusV.y + az * (isBike ? 4 : 9); py = (isBike ? 25 : 15.5) + hopY;
        lx = focusV.x + ax * 300; lz = focusV.y + az * 300; ly = 8 + hopY * 0.5;
        fov = 70 + Math.min(10, focusV.spd / 70);
      } else {
        const bike = !!focusObj.m.bike;
        const back = (bike ? 54 : 70) + Math.min(14, focusV.spd / 45);
        px = focusV.x - fx * back; pz = focusV.y - fz * back; py = (bike ? 27 : 31) + hopY * 0.5;
        lx = focusV.x + fx * 80; lz = focusV.y + fz * 80; ly = (bike ? 14 : 12) + hopY * 0.4;
        fov = 60 + Math.min(9, focusV.spd / 70) + (focusV.f & F.NITRO ? 5 : 0);
      }
      if (!cam.init || mode !== cam.mode) { cam.pos.set(px, py, pz); cam.look.set(lx, ly, lz); cam.init = true; cam.mode = mode; }
      const kpos = mode === 'hood' ? 1 : Math.min(1, dt * 12);
      cam.pos.lerp(tmpV.set(px, py, pz), kpos);
      cam.look.lerp(tmpV.set(lx, ly, lz), mode === 'hood' ? 1 : Math.min(1, dt * 14));
      cam.fov += (fov - cam.fov) * Math.min(1, dt * 3);
      camera.position.copy(cam.pos);
      if (shake > 0.2) camera.position.add(tmpV.set((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake * 0.6, (Math.random() - 0.5) * shake));
      camera.lookAt(cam.look);
      if (Math.abs(camera.fov - cam.fov) > 0.05) { camera.fov = cam.fov; camera.updateProjectionMatrix(); }
    } else if (st.T) {
      // no vehicles yet: hover over the start line
      const p = st.T.pts[0], t = st.T.tan[0];
      camera.position.set(p[0] - t[0] * 160, 70, p[1] - t[1] * 160);
      camera.lookAt(p[0], 0, p[1]);
    }

    drawParticles(particles);
    renderer.render(scene, camera);
  }

  function resize(w, h, dpr) {
    renderer.setPixelRatio(dpr);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  function resetCamera() { cam.init = false; }

  return { ok: true, setTrack, render, resize, resetCamera };
}
