'use strict';
// Bilal's Speedway - multiplayer top-down car & bike racing. Zero dependencies.

const http = require('http');
const fs = require('fs');
const path = require('path');
const ws = require('./lib/ws');
const { Room, COLORS } = require('./lib/room');
const { trackList } = require('./lib/tracks');
const { Store } = require('./lib/store');
const ai = require('./lib/ai');

const PORT = Number(process.env.PORT || 3002);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const MAX_ROOMS = Number(process.env.MAX_ROOMS || 30);
const PUBLIC = path.join(__dirname, 'public');
const TICK_HZ = 60;

const log = (...a) => console.log(new Date().toISOString(), ...a);
const store = new Store(DATA_DIR, log);
const rooms = new Map();
const conns = new Set();
let pidSeq = 1;

// ---------------- static files ----------------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.ico': 'image/x-icon', '.json': 'application/json',
};

const server = http.createServer((req, res) => {
  const url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, rooms: rooms.size, players: conns.size }));
  }
  if (url === '/api/halloffame') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify(store.hallOfFame()));
  }
  let file = url === '/' ? '/index.html' : url;
  const full = path.normalize(path.join(PUBLIC, file));
  if (!full.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(full, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full)] || 'application/octet-stream',
      'Cache-Control': full.endsWith('.html') ? 'no-cache' : 'public, max-age=300',
    });
    res.end(buf);
  });
});

// ---------------- lobby ----------------
function roomCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  for (;;) {
    let c = '';
    for (let i = 0; i < 4; i++) c += A[Math.floor(Math.random() * A.length)];
    if (!rooms.has(c)) return c;
  }
}

let lobbyDirty = false;
function lobbyChanged() { lobbyDirty = true; }
function lobbyList() { return [...rooms.values()].map((r) => r.publicInfo()); }
function pushLobby() {
  if (!lobbyDirty) return;
  lobbyDirty = false;
  const msg = JSON.stringify({ t: 'lobby', rooms: lobbyList() });
  for (const c of conns) if (!c.room) c.sendRaw(msg);
}
setInterval(pushLobby, 500);

const hooks = {
  lobbyChanged,
  onRaceEnd(room, results) {
    let news = [];
    try { news = store.recordRace(results); } catch (e) { log('recordRace failed', e.message); }
    for (const n of news) if (n.type === 'lap') room.sysChat(`🏆 New track record by ${n.name}: ${(n.time / 1000).toFixed(2)}s`);
    room.setCommentary(ai.fallback(results));
    ai.commentary(results).then((txt) => { if (txt && room.results === results) room.setCommentary(txt); }).catch(() => {});
  },
};

function cleanProfile(p) {
  const name = String(p?.name || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 16) || 'Racer' + Math.floor(Math.random() * 900 + 100);
  const kind = p?.kind === 'bike' ? 'bike' : 'car';
  const color = /^#[0-9a-f]{6}$/i.test(p?.color || '') ? p.color : COLORS[Math.floor(Math.random() * 8)];
  return { name, kind, color };
}

function leaveRoom(c) {
  const r = c.room;
  if (!r) return;
  c.room = null;
  r.removeMember(c.pid);
  if (r.humans().length === 0) { rooms.delete(r.code); log('room closed', r.code); }
  lobbyChanged();
}

ws.attach(server, '/ws', (c) => {
  c.pid = pidSeq++;
  c.room = null;
  c.profile = null;
  conns.add(c);
  c.send({ t: 'welcome', id: c.pid, tracks: trackList(), colors: COLORS, rooms: lobbyList(), ai: ai.cfg.enabled });

  let msgCount = 0, msgWindow = Date.now();
  c.on('message', (m) => {
    // basic flood protection
    const now = Date.now();
    if (now - msgWindow > 1000) { msgWindow = now; msgCount = 0; }
    if (++msgCount > 120) return;
    try { handle(c, m); } catch (e) { log('handler error', e.stack || e.message); }
  });
  c.on('close', () => { conns.delete(c); leaveRoom(c); });
});

function handle(c, m) {
  const r = c.room;
  switch (m.t) {
    case 'i': if (r) r.input(c.pid, m.k | 0); break;
    case 'hello': c.profile = cleanProfile(m); c.send({ t: 'profile', profile: c.profile }); break;
    case 'profile':
      c.profile = cleanProfile({ ...c.profile, ...m });
      if (r) r.updateProfile(c.pid, c.profile);
      break;
    case 'create': {
      if (!c.profile) c.profile = cleanProfile({});
      if (rooms.size >= MAX_ROOMS) return c.send({ t: 'error', msg: 'Too many rooms open. Join an existing one.' });
      leaveRoom(c);
      const code = roomCode();
      const room = new Room(code, m, hooks);
      rooms.set(code, room);
      c.room = room;
      room.addHuman(c, c.profile);
      log('room created', code, 'by', c.profile.name);
      lobbyChanged();
      break;
    }
    case 'join': {
      if (!c.profile) c.profile = cleanProfile({});
      const room = rooms.get(String(m.code || '').toUpperCase());
      if (!room) return c.send({ t: 'error', msg: 'Room not found.' });
      if (room.humans().length >= 8) return c.send({ t: 'error', msg: 'Room is full (8 racers).' });
      leaveRoom(c);
      c.room = room;
      room.addHuman(c, c.profile);
      lobbyChanged();
      break;
    }
    case 'leave': leaveRoom(c); c.send({ t: 'left' }); c.send({ t: 'lobby', rooms: lobbyList() }); break;
    case 'settings': if (r) r.updateSettings(c.pid, m); break;
    case 'start': if (r) r.start(c.pid); break;
    case 'chat': if (r) r.chatMsg(c.pid, m.text); break;
    case 'honk': if (r) r.honk(c.pid); break;
    case 'respawn': if (r) r.playerRespawn(c.pid); break;
    case 'again': if (r && r.phase === 'results' && c.pid === r.hostId) r.backToLobby(); break;
    case 'ping': c.send({ t: 'pong', ct: m.ct, st: Date.now() }); break;
    default: break;
  }
}

// ---------------- game loop ----------------
const dt = 1 / TICK_HZ;
let acc = 0;
let last = process.hrtime.bigint();
setInterval(() => {
  const now = process.hrtime.bigint();
  acc += Number(now - last) / 1e9;
  last = now;
  if (acc > 0.25) acc = 0.25; // avoid spiral after a stall
  while (acc >= dt) {
    acc -= dt;
    for (const room of rooms.values()) {
      try { room.tick(dt); } catch (e) { log('tick error', room.code, e.stack || e.message); }
    }
  }
}, 1000 / TICK_HZ / 2);

// keepalive / dead connection cleanup
setInterval(() => {
  const now = Date.now();
  for (const c of conns) {
    if (now - c.lastSeen > 45000) c.close(1001);
    else c.ping();
  }
}, 15000);

server.listen(PORT, HOST, () => log(`Bilal's Speedway running on http://${HOST}:${PORT} (AI ${ai.cfg.enabled ? 'on' : 'off'})`));

function shutdown() { log('shutting down'); if (store.timer) store.flush(); process.exit(0); }
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
