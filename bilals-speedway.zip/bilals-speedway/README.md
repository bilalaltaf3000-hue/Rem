# Bilal's Speedway 🏁

Multiplayer 3D car & bike racing for the office network. Ram your colleagues, knock bikers off, jump speed bumps, hit boost pads, avoid oil.

- **Port:** 3002 · **Service:** `bilals-speedway` · **User:** `bpspeed`
- **Zero npm dependencies.** Node.js 20 only. three.js is bundled in `public/vendor/`, so it works fully offline.
- **AI (optional):** after each race, Qwen on port 8001 writes the commentary. If the AI is down, built-in commentary lines are used.

## Install (as root)

```bash
cd /data
python3 -m zipfile -e bilals-speedway.zip /data/
bash /data/bilals-speedway/deploy/install.sh
```

Open `http://<server-ip>:3002` in Chrome or Edge on any office PC.

The installer creates the system user, labels the Node binary `bin_t` for SELinux, writes `/etc/bilals-speedway.env`, installs and starts the systemd service, and opens 3002/tcp in firewalld. Running it again is safe (use it after updates). Your settings and records are kept.

## Update to a new version

```bash
systemctl stop bilals-speedway
cp -a /data/bilals-speedway/data /tmp/speedway-data-backup   # records
python3 -m zipfile -e bilals-speedway.zip /data/
bash /data/bilals-speedway/deploy/install.sh
```

## Controls

| Key | Action |
|---|---|
| ↑ / W | Accelerate |
| ↓ / S | Brake / reverse |
| ← → / A D | Steer |
| Space | Nitro (refills slowly) |
| Shift | Handbrake drift |
| C | Camera: chase → driver (bonnet) → top view |
| R | Respawn if stuck |
| H | Horn |
| Enter | Chat |
| M | Mute |

Phones and tablets get on-screen buttons.

## Gameplay

- **Car**: heavier, wins bumps, harder to spin.
- **Bike**: faster and nimbler, but gets knocked off when rammed hard (1.5 s wipeout).
- Hard rams spin rivals out. Bumping can be switched off per room.
- Speed bumps launch you into the air (bikes fly further). Boost pads give a free nitro burst. Oil makes you slide.
- Bots fill empty grid slots (Easy / Normal / Hard). Up to 8 racers per room.
- After the first finisher, everyone else has 25 seconds to cross the line.
- Results show awards (fastest lap, demolition king, crash magnet, speed demon) and commentary.
- Hall of Fame: weekly points and last week's champion, all-time wins, lap records per track, plus a Mayhem tab with most rams and top speed.

## Files

```
server.js          HTTP + WebSocket server, game loop (60 Hz physics, 30 Hz network)
lib/physics.js     vehicle handling, collisions, hazards, laps
lib/room.js        rooms, race lifecycle, bots
lib/tracks.js      track layouts (add your own here)
lib/store.js       records (data/records.json)
lib/ai.js          Qwen commentary + fallback
public/            browser client (index.html, game.js, render3d.js, vendor/three.module.min.js)
deploy/            install.sh, uninstall.sh
```

## Troubleshooting

- `journalctl -u bilals-speedway -f` shows the live log.
- If the service fails with `status=203/EXEC`, it's the SELinux label. Run `chcon -R -t bin_t /data/node-v20.18.0-linux-x64/bin` and restart.
- Check health with `curl http://127.0.0.1:3002/health`.
- If the 3D view is slow on old PCs, press **C** twice for the top view, which is very light.
- If the AI model name differs, set `AI_MODEL` in `/etc/bilals-speedway.env` to the name your Qwen server expects, then restart.
