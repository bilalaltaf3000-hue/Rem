#!/usr/bin/env bash
# Removes the service, env file and firewall rule. Leaves /data/bilals-speedway (and its records) in place.
set -euo pipefail
APP_NAME="bilals-speedway"
ENV_FILE="/etc/${APP_NAME}.env"
[ "$(id -u)" -eq 0 ] || { echo "Run as root"; exit 1; }
PORT="$(grep -E '^PORT=' "$ENV_FILE" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')"; PORT="${PORT:-3002}"
systemctl disable --now "$APP_NAME" 2>/dev/null || true
rm -f "/etc/systemd/system/${APP_NAME}.service"
systemctl daemon-reload
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --remove-port="${PORT}/tcp" >/dev/null 2>&1 || true
  firewall-cmd --reload >/dev/null
fi
echo "Removed service and firewall rule. Settings kept at $ENV_FILE, app files at /data/$APP_NAME."
