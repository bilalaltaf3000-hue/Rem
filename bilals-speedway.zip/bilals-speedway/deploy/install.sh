#!/usr/bin/env bash
# Bilal's Speedway installer - run as root:  bash /data/bilals-speedway/deploy/install.sh
# Sets up: system user, data dir, env file, SELinux label for Node, systemd service, firewalld port.
set -euo pipefail

APP_NAME="bilals-speedway"
APP_USER="bpspeed"
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_DIR="${NODE_DIR:-/data/node-v20.18.0-linux-x64}"
NODE_BIN="$NODE_DIR/bin/node"
ENV_FILE="/etc/${APP_NAME}.env"
UNIT_FILE="/etc/systemd/system/${APP_NAME}.service"
PORT_DEFAULT=3002

say()  { printf '\033[1;33m==>\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m OK\033[0m %s\n' "$*"; }
warn() { printf '\033[1;31m !!\033[0m %s\n' "$*"; }

[ "$(id -u)" -eq 0 ] || { warn "Please run as root (sudo bash $0)"; exit 1; }
[ -x "$NODE_BIN" ] || { warn "Node not found at $NODE_BIN (set NODE_DIR=... to override)"; exit 1; }
[ -f "$APP_DIR/server.js" ] || { warn "server.js not found in $APP_DIR"; exit 1; }
say "Installing $APP_NAME from $APP_DIR using $($NODE_BIN -v)"

# 1. system user
if ! id "$APP_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --home-dir "$APP_DIR" --shell /sbin/nologin "$APP_USER"
  ok "created system user $APP_USER"
else
  ok "user $APP_USER exists"
fi

# 2. files + permissions (code read-only for the service, data dir writable)
mkdir -p "$APP_DIR/data"
chown -R root:"$APP_USER" "$APP_DIR"
chmod -R u=rwX,g=rX,o= "$APP_DIR"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR/data"
chmod 750 "$APP_DIR/data"
ok "permissions set (data in $APP_DIR/data)"
if ! runuser -u "$APP_USER" -- test -r "$APP_DIR/server.js" 2>/dev/null; then
  warn "$APP_USER cannot read $APP_DIR (check that $(dirname "$APP_DIR") allows traverse: chmod o+x $(dirname "$APP_DIR"))"
fi
if ! runuser -u "$APP_USER" -- test -x "$NODE_BIN" 2>/dev/null; then
  warn "$APP_USER cannot execute $NODE_BIN (check permissions on $NODE_DIR)"
fi

# 3. env file (kept if it already exists)
if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
# Bilal's Speedway settings - restart after editing: systemctl restart $APP_NAME
PORT=$PORT_DEFAULT
HOST=0.0.0.0
DATA_DIR=$APP_DIR/data
MAX_ROOMS=30
# Local Qwen server for post-race commentary (game works fine without it)
AI_ENABLED=1
AI_URL=http://127.0.0.1:8001/v1/chat/completions
AI_MODEL=qwen2.5-14b-instruct
AI_TIMEOUT_MS=45000
EOF
  ok "wrote $ENV_FILE"
else
  ok "kept existing $ENV_FILE"
fi
chown root:"$APP_USER" "$ENV_FILE"
chmod 640 "$ENV_FILE"
PORT="$(grep -E '^PORT=' "$ENV_FILE" | tail -1 | cut -d= -f2 | tr -d '[:space:]')"
PORT="${PORT:-$PORT_DEFAULT}"

# 4. SELinux: tarball Node needs bin_t or systemd fails with 203/EXEC
if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
  if command -v semanage >/dev/null 2>&1; then
    semanage fcontext -a -t bin_t "$NODE_DIR/bin(/.*)?" 2>/dev/null || semanage fcontext -m -t bin_t "$NODE_DIR/bin(/.*)?" 2>/dev/null || true
    restorecon -R "$NODE_DIR/bin" || true
  fi
  # make sure it's labelled even if semanage is missing
  if ! ls -Z "$NODE_BIN" | grep -q bin_t; then chcon -R -t bin_t "$NODE_DIR/bin" || true; fi
  ls -Z "$NODE_BIN" | grep -q bin_t && ok "SELinux: node binary labelled bin_t" || warn "SELinux: could not label $NODE_BIN as bin_t"
else
  ok "SELinux disabled, skipping label"
fi

# 5. systemd service
cat > "$UNIT_FILE" <<EOF
[Unit]
Description=Bilal's Speedway (multiplayer racing game)
After=network.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$NODE_BIN $APP_DIR/server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
LimitNOFILE=8192
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable "$APP_NAME" >/dev/null 2>&1
systemctl restart "$APP_NAME"
ok "systemd service $APP_NAME enabled and (re)started"

# 6. firewall
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port="${PORT}/tcp" >/dev/null
  firewall-cmd --reload >/dev/null
  ok "firewalld: port $PORT/tcp open"
else
  warn "firewalld not running, skipped (open port $PORT manually if needed)"
fi

# 7. health check
sleep 2
if systemctl is-active --quiet "$APP_NAME"; then
  if command -v curl >/dev/null 2>&1 && curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null; then
    ok "health check passed"
  fi
  IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  echo
  printf '\033[1;32m🏁 Bilal'"'"'s Speedway is running!\033[0m\n'
  echo "   Open:  http://${IP:-$(hostname)}:${PORT}   (or http://$(hostname):${PORT})"
  echo "   Logs:  journalctl -u $APP_NAME -f"
  echo "   Settings: $ENV_FILE"
else
  warn "Service failed to start. Last log lines:"
  journalctl -u "$APP_NAME" -n 30 --no-pager || true
  exit 1
fi
