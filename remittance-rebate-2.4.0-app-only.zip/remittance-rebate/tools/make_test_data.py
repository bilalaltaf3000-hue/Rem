#!/usr/bin/env python3
"""Generate a complete SYNTHETIC input set for the Remittance Rebate
Calculator - every source and reference file, in the real layouts, with
no real customer data. Used by the self-test and for speed trials.

    python tools/make_test_data.py OUT_DIR [ROWS] [--month 2025-11]

A block of hand-built "designed" transactions is always included; what
each one must end up as is written to OUT_DIR/expected.json.
"""
import json
import os
import sys

import numpy as np
import pandas as pd

FIRST = ("MUHAMMAD AHMED ALI HASSAN HUSSAIN BILAL USMAN UMAR ZAIN FAISAL FAZAL "
         "IMRAN KAMRAN SALMAN ADNAN NOMAN RIZWAN IRFAN ASIF KASHIF TARIQ "
         "SHAHID ZAHID NAVEED WASEEM NADEEM SAJID MAJID KHALID RASHID BABAR "
         "AYESHA FATIMA ZAINAB MARYAM SANA HINA SADIA NADIA RABIA SAIMA "
         "AMNA BUSHRA FARAH IQRA KIRAN MEHWISH NIDA SHAZIA UZMA ZARA").split()
LAST = ("KHAN AHMED ALI HUSSAIN MALIK SHEIKH BUTT CHAUDHRY QURESHI SIDDIQUI "
        "ANSARI MIRZA BAIG RAJA RANA ABBASI AWAN BHATTI CHEEMA DAR GILL "
        "HASHMI JAMIL KAZMI LODHI MEMON NIAZI PASHA RIZVI SHAH TAHIR").split()
MID = ("", "", "", "IQBAL ", "ASLAM ", "AKRAM ", "ANWAR ", "YOUSAF ", "SALEEM ", "MEHMOOD ")
ENTITIES = [  # code, name, country, remarks
    ("CHASUS33", "JP MORGAN CHASE BANK", "UNITED STATES", "CLAIM"),
    ("WUEXUS44", "WESTERN UNION", "UNITED STATES", "CLAIM"),
    ("MGRMUS55", "MONEYGRAM INTERNATIONAL", "UNITED STATES", "CLAIM"),
    ("ARNBSARI", "AL RAJHI BANK", "SAUDI ARABIA", "CLAIM"),
    ("NCBKSAJE", "SAUDI NATIONAL BANK", "SAUDI ARABIA", "CLAIM"),
    ("EBILAEAD", "EMIRATES NBD", "UNITED ARAB EMIRATES", "CLAIM"),
    ("ADCBAEAA", "ABU DHABI COMMERCIAL BANK", "UNITED ARAB EMIRATES", "CLAIM"),
    ("HABBGB2L", "Habib Bank Ltd.  London", "UNITED KINGDOM", "CLAIM"),
    ("BARCGB22", "BARCLAYS BANK", "UNITED KINGDOM", "CLAIM"),
    ("QNBAQAQA", "QATAR NATIONAL BANK", "QATAR", "CLAIM"),
    ("NBOKKWKW", "NATIONAL BANK OF KUWAIT", "KUWAIT", "CLAIM"),
    ("BMUSOMRX", "BANK MUSCAT", "OMAN", "CLAIM"),
    ("LOCLPKKA", "LOCAL EXCHANGE CO", "PAKISTAN", "NO CLAIM"),
    ("XPRSAEAD", "XPRESS MONEY", "UNITED ARAB EMIRATES", "NO CLAIM"),
]
CC = {"UNITED STATES": "US", "SAUDI ARABIA": "SA", "UNITED ARAB EMIRATES": "AE",
      "UNITED KINGDOM": "GB", "QATAR": "QA", "KUWAIT": "KW", "OMAN": "OM",
      "PAKISTAN": "PK"}
REMI_COMM = ["ABC TRADING (PVT) LTD.", "Global Exports Co.", "M/S ZENITH TEXTILES",
             "Orient Software House (SMC-Private) Limited", "PAK GULF TRADERS"]
BENE_COMM = ["Karachi Steel Mills Ltd", "AL-NOOR ENTERPRISES", "City School (Pvt) Limited"]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out = args[0]
    n = int(args[1]) if len(args) > 1 else 3000
    month = "2025-11"
    if "--month" in sys.argv:
        month = sys.argv[sys.argv.index("--month") + 1]
    year, mon = int(month[:4]), int(month[5:7])
    days = pd.Period(month).days_in_month
    rng = np.random.default_rng(7)
    os.makedirs(out, exist_ok=True)
    for sub in ("ITRS", "RDA-HBL", "Commercial"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
    expected = {}

    # ---- relationship pool: who sends to whom -----------------------
    npair = max(50, int(n / 2.2))
    def names(k):
        f = rng.choice(FIRST, k); m = rng.choice(MID, k); l = rng.choice(LAST, k)
        return np.char.add(np.char.add(np.char.add(f, " "), m), l)
    p_rem = names(npair)
    p_ben = names(npair)
    p_remid = np.array(["%010d" % v for v in rng.integers(10**9, 9 * 10**9, npair)])
    p_acct = np.array(["%04d%010d" % (b, a) for b, a in
                       zip(rng.integers(1, 1800, npair), rng.integers(10**8, 10**10 - 1, npair))])
    p_cnic = np.array(["%d%012d" % (a, b) for a, b in
                       zip(rng.integers(1, 9, npair), rng.integers(0, 10**12 - 1, npair))])
    p_ent = rng.integers(0, len(ENTITIES), npair)
    p_mode = rng.choice(["AC", "AC", "AC", "OC", "IB", "CM"], npair,
                        p=[.3, .2, .16, .2, .13, .01])

    pair = rng.integers(0, npair, n)
    day = rng.integers(1, days + 1, n)
    amount = np.round(rng.lognormal(11.2, 1.0, n), 2)
    urn = np.array(["%d%013d" % (year, i) for i in rng.permutation(n) + 5 * 10**12])
    ent_code = np.array([e[0] for e in ENTITIES])[p_ent[pair]]
    ent_x = np.where(rng.random(n) < .5, np.char.add(ent_code, "XXX"), ent_code)
    mode = p_mode[pair]
    rem, ben, remid = p_rem[pair].astype(object), p_ben[pair].astype(object), p_remid[pair]
    acct, cnic = p_acct[pair], p_cnic[pair]
    # name noise the cleanser has to deal with
    r = rng.random(n)
    rem = np.where(r < .03, "1/" + rem, np.where(r < .05, rem + " .", rem))
    r = rng.random(n)
    ben = np.where(r < .02, ben + ",", np.where(r < .03, "/" + ben, ben))

    ch = rng.choice(["RH", "GRS", "FM", "RIMPIM"], n, p=[.35, .645, .0025, .0025])
    D = pd.DataFrame(dict(ch=ch, urn=urn, ent=ent_x, code=ent_code, mode=mode, rem=rem,
                          ben=ben, remid=remid, acct=acct, cnic=cnic, day=day,
                          amount=amount, pair=pair))
    D["iban"] = "PK36HABB00" + D["acct"]
    D["comments"] = ""
    D["cust"] = np.where(rng.random(n) < .03, "CORPORATE",
                         np.where(rng.random(n) < .05, "SOLE PROPRIETOR", "INDIVIDUAL"))
    D["rda"] = rng.choice(["", "other", "hbl"], n, p=[.93, .03, .04])
    r = rng.random(n)
    D.loc[r < .004, "comments"] = "TXN REFUNDED TO REMITTER"
    D["refund"] = (r >= .004) & (r < .008)
    oc = D["mode"].eq("OC")
    D["cnic_src"] = np.where(oc & (rng.random(n) < .15), "7122", "row")
    D.loc[D["mode"].eq("AC") & (rng.random(n) < .004), "acct"] = "12345"
    low = rng.random(n) < .05
    D.loc[low, "amount"] = np.round(rng.uniform(5000, 50000, int(low.sum())), 2)

    # ---- designed cases --------------------------------------------
    cases = []
    def case(tag, expect, **kw):
        row = dict(ch="RH", urn="%d9%012d" % (year, len(cases) + 1), ent="CHASUS33XXX",
                   code="CHASUS33", mode="AC", rem="%s TESTCASE %s" % (FIRST[len(cases)], LAST[len(cases) % len(LAST)]),
                   ben="%s TESTCASE %s" % (FIRST[-1 - len(cases)], LAST[-1 - len(cases) % len(LAST)]), remid="77%08d" % len(cases),
                   acct="0042%010d" % (5000 + len(cases)), cnic="42101%08d" % len(cases),
                   day=10, amount=150000.0, pair=-1, comments="", cust="INDIVIDUAL",
                   rda="", refund=False, cnic_src="row")
        row.update(kw)
        row["iban"] = "PK36HABB00" + row["acct"]
        cases.append(row)
        expected[row["urn"]] = dict(tag=tag, sheet=expect)
        return row["urn"]
    case("clean claim", "SBP Claim")
    case("no-claim entity", "No Claim", ent="LOCLPKKA", code="LOCLPKKA")
    case("mode CM", "CM", mode="CM")
    case("below 200", "Below US$200", amount=20000.0)
    case("bene commercial by cust_type", "Bene Comm", cust="CORPORATE")
    case("bene commercial by name (IB)", "Bene Comm", mode="IB", ben="KARACHI STEEL MILLS LIMITED")
    case("remitter commercial, punctuation differs", "Reme Comm", rem="ABC TRADING PVT LTD")
    case("remitter commercial, cleansing altered it", "Reme Comm", rem="1/GLOBAL EXPORTS CO .")
    case("UK pension", "HBL UK WORKER PENSION", ent="HABBGB2L", code="HABBGB2L",
         urn="G1%014d" % 77)
    case("UK pension paid by a listed commercial remitter", "HBL UK WORKER PENSION",
         ent="HABBGB2L", code="HABBGB2L", urn="G1%014d" % 78, rem="PAK GULF TRADERS")
    case("RDA other bank", "RDA", rda="other")
    case("RDA HBL", "RDA", rda="hbl")
    u = case("cancelled by refund file", "Cancelled", refund=True)
    case("cancelled by comment", "Cancelled", comments="cncl by remitter")
    # the URN from the UAT email: 16 digits, refund file damaged by Excel precision
    case("UAT email URN, refund ref lost last digit", "Cancelled",
         urn="2026126050980614", refund="damaged", amount=84155.0)
    case("ORRE non-digit URN", "ORRE", ent="ORRE12", code="ORRE12", urn="ORREREF77A")
    case("OC, CNIC from 7122", "SBP Claim", mode="OC", cnic_src="7122")
    case("OC, CNIC missing -> query file", "SBP Claim", mode="OC", cnic_src="none")
    case("AC, bad account length -> query file", "SBP Claim", acct="99887")
    for i in range(3):      # same people, same day, 3 times -> 1 stays
        case("daily repeat %d" % (i + 1), "SBP Claim" if i == 0 else "SPLIT",
             rem="DAILY REPEAT SENDER", ben="DAILY REPEAT RECEIVER", remid="8800000001",
             acct="00429999000011", cnic="4210188000001", day=12)
    for i in range(7):      # same people, 7 different days -> 5 stay
        case("monthly repeat %d" % (i + 1), "SBP Claim" if i < 5 else "MAX 5 SPLIT",
             rem="MONTHLY REPEAT SENDER", ben="MONTHLY REPEAT RECEIVER", remid="8800000002",
             acct="00429999000022", cnic="4210188000002", day=2 + i)
    case("near-match remitter (needs approval)", "SBP Claim", rem="ZENITH TEXTILES PVT LTD")
    # names the cleansing rules used to get wrong
    case("name: Abu Bakar", "SBP Claim", rem="Abu Bakar Siddiq")
    case("name: joint with &", "SBP Claim", ben="Bilal & Rabia")
    case("name: joined words", "SBP Claim", rem="Tahir MehmoodMuhammad Butt")
    case("name: emptied by the rules", "SBP Claim", ben="NO LAST NAME")
    # the same sender spelled two ways, same receiver, same day: only the
    # name-based key can see the repeat, once the spellings are merged
    for spelling in ("MUHAMMAD ASLAM TESTER", "MOHAMMAD ASLAM TESTER"):
        case("variant spelling " + spelling, "SBP Claim", rem=spelling,
             ben="SANA TESTCASE RIZVI", day=15)
    D = pd.concat([D, pd.DataFrame(cases)], ignore_index=True)

    D["date"] = pd.to_datetime(dict(year=year, month=mon, day=D["day"]))
    us = D["date"].dt.strftime("%m/%d/%Y") + " 10:15 AM"
    iso = D["date"].dt.strftime("%Y-%m-%d")
    row_cnic = np.where(D["cnic_src"].eq("row"), D["cnic"], "")
    row_cnic = np.where(rng.random(len(D)) < .3,
                        [c[:5] + "-" + c[5:12] + "-" + c[12:] if c else c for c in row_cnic],
                        row_cnic)

    # ---- RH (tab delimited, no header, month-first dates) -----------
    m = D["ch"].eq("RH"); R = D[m]
    rh = pd.DataFrame({
        0: R["ent"], 1: np.where(rng.random(len(R)) < .9, "HBL", "MCB"), 2: R["rem"],
        3: ["%d" % v for v in rng.integers(10**15, 9 * 10**15, len(R))], 4: R["iban"],
        5: us[m], 6: R["amount"].map("{:.2f}".format), 7: R["ben"],
        8: "0300" + R["remid"].str[:7], 9: R["acct"], 10: us[m], 11: range(1, len(R) + 1),
        12: R["mode"], 13: "PCD", 14: R["acct"].str[:4], 15: "", 16: R["urn"],
        17: R["remid"], 18: us[m], 19: us[m], 20: "USR01", 21: "0042",
        22: "FAMILY SUPPORT", 23: R["comments"], 24: "", 25: "", 26: "",
        27: "", 28: row_cnic[m.values], 29: "", 30: "", 31: "RH"})
    # the extract arrives in two parts
    cut = len(rh) // 2
    rh.iloc[:cut].to_csv(os.path.join(out, "rh.txt"), sep="\t", header=False, index=False)
    rh.iloc[cut:].to_csv(os.path.join(out, "rh_part2.txt"), sep="\t", header=False, index=False)

    def xl(df, path, sheet="Sheet1", startrow=0, **extra_sheets):
        with pd.ExcelWriter(path, engine="xlsxwriter") as w:
            df.to_excel(w, index=False, sheet_name=sheet, startrow=startrow)
            if startrow:
                w.sheets[sheet].write(0, 0, "HOLDTRANSACTIONS")
            for k, v in extra_sheets.items():
                v.to_excel(w, index=False, sheet_name=k.replace("_", " "))

    m = D["ch"].eq("GRS"); R = D[m]
    g = pd.DataFrame({
        "SWIFTID": R["ent"], "UNIQUEREFERENCENO": R["urn"], "BANKCODE": "HBL",
        "SENDERNAME": R["rem"], "RDID": ["%d" % v for v in rng.integers(10**15, 9 * 10**15, len(R))],
        "TOACCT": R["iban"], "Upload Date": iso[m], "REMITTANCEAMOUNT": R["amount"],
        "BENEFICIARYNAME": R["ben"], "BENEFICIARYMOBILENO": "0300" + R["remid"].str[:7],
        "Open Date": iso[m], "TRANSACTION_TYPE": R["mode"], "STATUS": "PAID",
        "MEMBERSHIP": R["remid"], "PAYMENT DATE": iso[m],
        "REMITTANCEPURPOSE": "FAMILY SUPPORT"})
    # GRS is split over two data sheets, plus a sheet that is not data
    cut = len(g) * 2 // 3
    with pd.ExcelWriter(os.path.join(out, "grs.xlsx"), engine="xlsxwriter") as w:
        g.iloc[:cut].to_excel(w, index=False, sheet_name="GRS 1")
        pd.DataFrame({"Summary": ["rows"], "Value": [len(g)]}).to_excel(w, index=False, sheet_name="Summary")
        g.iloc[cut:].to_excel(w, index=False, sheet_name="GRS 2")

    m = D["ch"].eq("FM"); R = D[m]
    xl(pd.DataFrame({
        "Remitting Entity": R["ent"], "Reference": R["urn"], "Naration line 2": R["rem"],
        "IBAN #": R["iban"], "Posting Date": iso[m], "CCY": "USD", "Real Amount": R["amount"],
        "A/c Short Name": R["ben"], "External #": R["acct"], "Value Date": iso[m],
        "Mode": R["mode"], "Branch Code": R["acct"].str[:4], "Naration line 1": R["remid"],
        "Transaction Description": "HOME REMITTANCE",
        "Naration line 3": np.where(R["mode"].eq("OC"), R["cnic"], "")}),
       os.path.join(out, "fm.xlsx"))

    m = D["ch"].eq("RIMPIM"); R = D[m]
    rp = pd.DataFrame({
        "orderinginstitution 52a": R["ent"], "external reference": R["urn"],
        "ordering customer 1": R["rem"], "payment ref": R["urn"].str[-10:], "iban": R["iban"],
        "lodded date": iso[m], "received curr": "USD", "net received amount": R["amount"],
        "net pay amount": R["amount"], "cust name": R["ben"],
        "external beneficiery account": R["iban"], "OPEN DATE-2": iso[m],
        "ordering customer ac": R["remid"], "value date": iso[m],
        "detail of payment 4": "FAMILY MAINTENANCE", "beneficiary cnic": R["cnic"]})
    # RIM/PIM: the second sheet was pasted without its heading row
    cut = max(1, len(rp) - 3)
    with pd.ExcelWriter(os.path.join(out, "rimpim.xlsx"), engine="xlsxwriter") as w:
        rp.iloc[:cut].to_excel(w, index=False, sheet_name="Sheet1")
        rp.iloc[cut:].to_excel(w, index=False, header=False, sheet_name="Sheet2")

    # ---- reference files -------------------------------------------
    xl(pd.DataFrame(ENTITIES, columns=["PFB_FNINCODE", "PFB_FNINDESC", "COUNTRY", "Remarks"]),
       os.path.join(out, "entity_list.xlsx"))

    cmap = {e[0]: CC[e[2]] for e in ENTITIES}
    I = D[D["code"].isin(cmap) & (rng.random(len(D)) < .97)]
    itrs = pd.DataFrame({"R.E": I["code"], "URN": I["urn"], "Country Code": I["code"].map(cmap)})
    half = I["day"].values <= 15
    is_rda = I["rda"].ne("").values
    mname = pd.Timestamp(year=year, month=mon, day=1).strftime("%b")
    with pd.ExcelWriter(os.path.join(out, "ITRS", "ITRS Data %s, %d.xlsx" % (mname, year)),
                        engine="xlsxwriter") as w:
        itrs[half & ~is_rda].to_excel(w, index=False, sheet_name="TOTAL 01-15")
        itrs[~half & ~is_rda].to_excel(w, index=False, sheet_name="TOTAL 16-31")
        itrs[is_rda].to_excel(w, index=False, sheet_name="RDA")

    F = D[D["refund"].astype(str).isin(["True", "damaged"])]
    ref = F["urn"].where(F["refund"].astype(str) != "damaged", F["urn"].str[:15] + "0")
    xl(pd.DataFrame({"Reference No.": ref, "Amount": F["amount"], "Remarks": "REFUND"}),
       os.path.join(out, "refunds.xlsx"), startrow=1)

    O = D[D["rda"].eq("other")]
    other = pd.DataFrame({"R.E": O["code"], "URN": O["urn"]})
    other.loc[len(other) + 10**6] = ["CHASUS33", "NOSUCHURN0001"]
    xl(other, os.path.join(out, "RDA-Other.xlsx"))
    H = D[D["rda"].eq("hbl")]
    xl(pd.DataFrame({"Sr": range(1, len(H) + 1),
                     "Transaction Reference Number": H["urn"].str[:8] + " " + H["urn"].str[8:]}),
       os.path.join(out, "RDA-HBL", "RDA HBL 1.xlsx"), startrow=1)

    S = D[D["cnic_src"].eq("7122")]
    xl(pd.DataFrame({"URN": S["urn"], "Nar 2 - CNIC": S["cnic"].str[:5] + "-" + S["cnic"].str[5:12]
                     + "-" + S["cnic"].str[12:]}), os.path.join(out, "7122.xlsx"))

    A = D[D["mode"].eq("AC") & D["acct"].str.len().eq(14)].drop_duplicates("acct")
    A = A[rng.random(len(A)) < .97]
    xl(pd.DataFrame({"ext_acct_num": A["acct"], "cnic": A["cnic"],
                     "acct_type": "SAVINGS", "cust_type": A["cust"]}),
       os.path.join(out, "DL1534.xlsx"))

    xl(pd.DataFrame({"Remitter Name": REMI_COMM}), os.path.join(out, "Commercial", "Commercial names.xlsx"),
       sheet="REME COM", BENE_COM=pd.DataFrame({"Beneficiary Name": BENE_COMM}))

    with open(os.path.join(out, "expected.json"), "w") as fh:
        json.dump(expected, fh, indent=1)
    with open(os.path.join(out, "counts.json"), "w") as fh:
        json.dump({"rows": int(len(D)), "amount": float(D["amount"].sum())}, fh)
    print("wrote %s: %d transactions (%s), %d designed cases"
          % (out, len(D), ", ".join("%s %d" % kv for kv in D["ch"].value_counts().items()),
             len(cases)))


if __name__ == "__main__":
    main()
