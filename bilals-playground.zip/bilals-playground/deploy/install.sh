#!/usr/bin/env bash
# Bilal's Playground - installer for RHEL (systemd + firewalld). Works fully offline.
# Usage (from inside the extracted folder):   sudo bash deploy/install.sh
set -euo pipefail

SERVICE=bilals-playground
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE=/etc/${SERVICE}.env
UNIT_FILE=/etc/systemd/system/${SERVICE}.service
PORT_DEFAULT=3000

green() { printf '\033[32m%s\033[0m\n' "$*"; }
yellow() { printf '\033[33m%s\033[0m\n' "$*"; }
red() { printf '\033[31m%s\033[0m\n' "$*"; }

if [ "$(id -u)" -ne 0 ]; then red "Please run with sudo:  sudo bash deploy/install.sh"; exit 1; fi

echo "== Bilal's Playground installer =="
echo "App folder: $APP_DIR"
case "$APP_DIR" in /data/*) ;; *) yellow "Note: app is not under /data (that's fine, it will run from $APP_DIR).";; esac
[ -f "$APP_DIR/server.js" ] || { red "server.js not found in $APP_DIR - run this from the extracted folder."; exit 1; }
[ -d "$APP_DIR/node_modules/socket.io" ] || { red "node_modules is missing - use the full zip, nothing can be downloaded on this VM."; exit 1; }

# ---------------------------------------------------------------- node
NODE_BIN="$(command -v node || true)"
if [ -z "$NODE_BIN" ] && [ -n "${SUDO_USER:-}" ]; then NODE_BIN="$(sudo -u "$SUDO_USER" bash -lc 'command -v node' 2>/dev/null || true)"; fi
[ -n "$NODE_BIN" ] || { red "Node.js not found in PATH. Install it or edit NODE_BIN at the top of this script."; exit 1; }
NODE_BIN="$(readlink -f "$NODE_BIN")"
NODE_MAJOR="$("$NODE_BIN" -p 'process.versions.node.split(".")[0]')"
echo "Node: $NODE_BIN (v$("$NODE_BIN" -v | tr -d v))"
if [ "$NODE_MAJOR" -lt 14 ]; then red "Node 14 or newer is required."; exit 1; fi

# ---------------------------------------------------------------- service user
SERVICE_USER=bpgame
if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /sbin/nologin "$SERVICE_USER" 2>/dev/null \
    && echo "Created system user $SERVICE_USER" \
    || { yellow "Could not create user $SERVICE_USER."; SERVICE_USER=""; }
fi

DATA_DIR="$APP_DIR/data"   # hall of fame lives here (kept when you update)
mkdir -p "$DATA_DIR"
if [ -n "$SERVICE_USER" ]; then
  chown -R root:"$SERVICE_USER" "$APP_DIR"
  chmod -R u=rwX,g=rX,o= "$APP_DIR"
  chown -R "$SERVICE_USER":"$SERVICE_USER" "$DATA_DIR"
  chmod 750 "$DATA_DIR"
  # the service user must be able to walk into the folder, write its data and run node
  if ! runuser -u "$SERVICE_USER" -- test -r "$APP_DIR/server.js" 2>/dev/null \
     || ! runuser -u "$SERVICE_USER" -- test -w "$DATA_DIR" 2>/dev/null \
     || ! runuser -u "$SERVICE_USER" -- "$NODE_BIN" -v >/dev/null 2>&1; then
    yellow "User $SERVICE_USER cannot read $APP_DIR, write $DATA_DIR or run $NODE_BIN (folder permissions on a parent like /data?)."
    SERVICE_USER=""
  fi
fi
if [ -z "$SERVICE_USER" ]; then
  SERVICE_USER="${SUDO_USER:-root}"
  yellow "Falling back to running the service as: $SERVICE_USER"
  chown -R "$SERVICE_USER": "$APP_DIR" 2>/dev/null || true
fi
echo "Service user: $SERVICE_USER"

PROTECT_HOME=true
case "$NODE_BIN$APP_DIR" in */home/*|/root/*) PROTECT_HOME=false;; esac

# ---------------------------------------------------------------- settings file (kept on re-install)
if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
# Bilal's Playground settings. After editing:  sudo systemctl restart ${SERVICE}
PORT=${PORT_DEFAULT}
HOST=0.0.0.0
# Your local AI (OpenAI-compatible API: vLLM, Ollama, llama.cpp server, LM Studio...)
AI_URL=http://127.0.0.1:8001/v1/chat/completions
# Leave empty to auto-detect from /v1/models, or set e.g. Qwen/Qwen2.5-14B-Instruct-AWQ
AI_MODEL=
# Only if your AI server needs a key
AI_API_KEY=
AI_TIMEOUT_MS=90000
# How many AI requests may run at once (set 1 if your AI server handles one at a time)
AI_CONCURRENCY=2
EOF
  chmod 640 "$ENV_FILE"
  chgrp "$SERVICE_USER" "$ENV_FILE" 2>/dev/null || true
  echo "Created settings file $ENV_FILE"
else
  echo "Keeping existing settings file $ENV_FILE"
fi
PORT="$(grep -E '^PORT=' "$ENV_FILE" | tail -1 | cut -d= -f2)"; PORT="${PORT:-$PORT_DEFAULT}"

# ---------------------------------------------------------------- systemd unit
cat > "$UNIT_FILE" <<EOF
[Unit]
Description=Bilal's Playground (office draw-and-guess game)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${APP_DIR}
EnvironmentFile=-${ENV_FILE}
Environment=NODE_ENV=production
ExecStart=${NODE_BIN} ${APP_DIR}/server.js
Restart=always
RestartSec=3
# light hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=${PROTECT_HOME}

[Install]
WantedBy=multi-user.target
EOF
echo "Wrote $UNIT_FILE"

# ---------------------------------------------------------------- SELinux (only relabel, no policy changes)
if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
  restorecon -R "$APP_DIR" >/dev/null 2>&1 || true
  # A Node.js extracted from a tarball (e.g. /data/node-v20...) is labelled default_t,
  # which systemd is not allowed to execute (status=203/EXEC). Label its bin folder as bin_t.
  NODE_DIR="$(dirname "$NODE_BIN")"
  case "$NODE_DIR" in /usr/bin|/bin|/usr/local/bin) ;; *)
    if ! ls -Z "$NODE_BIN" 2>/dev/null | grep -q ':bin_t:'; then
      if command -v semanage >/dev/null 2>&1; then
        semanage fcontext -a -t bin_t "${NODE_DIR}(/.*)?" 2>/dev/null || semanage fcontext -m -t bin_t "${NODE_DIR}(/.*)?" 2>/dev/null || true
        restorecon -R "$NODE_DIR" >/dev/null 2>&1 || true
      fi
      ls -Z "$NODE_BIN" 2>/dev/null | grep -q ':bin_t:' || chcon -R -t bin_t "$NODE_DIR" 2>/dev/null || true
      echo "SELinux: labelled $NODE_DIR as bin_t so systemd can run node"
    fi
  ;; esac
fi
# node's own folder must be readable/executable by the service user
NODE_ROOT="$(dirname "$(dirname "$NODE_BIN")")"
case "$NODE_ROOT" in /usr|/usr/local|/) ;; *) chmod -R o+rX "$NODE_ROOT" 2>/dev/null || true;; esac

# ---------------------------------------------------------------- firewall
if systemctl is-active --quiet firewalld; then
  if firewall-cmd --query-port="${PORT}/tcp" >/dev/null 2>&1; then
    echo "Firewall: port ${PORT}/tcp already open"
  else
    firewall-cmd --permanent --add-port="${PORT}/tcp" >/dev/null && firewall-cmd --reload >/dev/null \
      && echo "Firewall: opened port ${PORT}/tcp" || yellow "Could not open ${PORT}/tcp in firewalld - ask IT."
  fi
else
  yellow "firewalld is not running - if colleagues can't connect, check the VM/network firewall for port ${PORT}."
fi

# ---------------------------------------------------------------- start
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1
systemctl restart "$SERVICE"

ok=""
for i in 1 2 3 4 5 6 7 8 9 10; do
  sleep 1
  if curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then ok=1; break; fi
done

if [ -n "$ok" ]; then
  IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  green "Bilal's Playground is running!"
  green "Open in a browser:  http://${IP:-<vm-ip>}:${PORT}"
  echo "It starts automatically on boot and keeps running after you close PuTTY."
  echo "AI check:  curl -s http://127.0.0.1:${PORT}/health"
else
  red "The service did not respond. Last log lines:"
  journalctl -u "$SERVICE" -n 30 --no-pager || true
  exit 1
fi
