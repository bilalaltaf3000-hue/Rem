'use strict';
// Shared client for the local AI (OpenAI-compatible API: vLLM, Ollama, llama.cpp server, LM Studio...).
// Includes a small priority queue so hints, commentary and word lists never flood the model.

const http = require('http');
const https = require('https');

const AI_URL = process.env.AI_URL || 'http://127.0.0.1:8001/v1/chat/completions';
const AI_MODEL = process.env.AI_MODEL || ''; // empty = auto-detect from /v1/models
const AI_TIMEOUT_MS = parseInt(process.env.AI_TIMEOUT_MS || '90000', 10);
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_CONCURRENCY = Math.max(1, parseInt(process.env.AI_CONCURRENCY || '2', 10));

// lower number = more urgent
const PRIORITY = { hint: 0, words: 1, awards: 1, refill: 2, comment: 3 };

let detectedModel = null;
let lastStatus = { ok: null, at: null, detail: 'not used yet' };

// ---------------------------------------------------------------- HTTP helper
function requestJson(method, urlStr, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlStr); } catch (e) { return reject(new Error('Bad AI_URL: ' + urlStr)); }
    const lib = u.protocol === 'https:' ? https : http;
    const payload = body ? JSON.stringify(body) : null;
    const headers = { 'Accept': 'application/json' };
    if (payload) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(payload);
    }
    if (AI_API_KEY) headers['Authorization'] = 'Bearer ' + AI_API_KEY;
    const req = lib.request({ method, hostname: u.hostname, port: u.port, path: u.pathname + u.search, headers }, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { data += c; if (data.length > 2e6) req.destroy(new Error('Response too large')); });
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error('HTTP ' + res.statusCode + ': ' + data.slice(0, 200)));
        try { resolve(JSON.parse(data)); } catch (e) { reject(new Error('Invalid JSON from AI server')); }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error('AI request timed out after ' + timeoutMs + 'ms')));
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function getModel() {
  if (AI_MODEL) return AI_MODEL;
  if (detectedModel) return detectedModel;
  const modelsUrl = AI_URL.replace(/\/chat\/completions\/?$/, '/models');
  const res = await requestJson('GET', modelsUrl, null, 8000);
  const first = res && res.data && res.data[0] && res.data[0].id;
  if (!first) throw new Error('Could not detect model name from ' + modelsUrl + ' (set AI_MODEL)');
  detectedModel = first;
  return first;
}

// ---------------------------------------------------------------- queue
const queue = [];
let running = 0;

function pump() {
  while (running < AI_CONCURRENCY && queue.length) {
    queue.sort((a, b) => a.prio - b.prio || a.seq - b.seq);
    const job = queue.shift();
    running++;
    job.run().then(job.resolve, job.reject).then(() => { running--; pump(); });
  }
}
let seq = 0;

/**
 * Ask the model. Resolves with the reply text.
 * kind: one of PRIORITY's keys. Low-priority jobs are dropped when the model is busy.
 */
function chat(kind, system, user, opts) {
  opts = opts || {};
  const prio = PRIORITY[kind] == null ? 2 : PRIORITY[kind];
  if (prio >= 3 && (queue.length >= 2 || running >= AI_CONCURRENCY)) {
    return Promise.reject(new Error('AI busy, skipped ' + kind));
  }
  return new Promise((resolve, reject) => {
    const started = Date.now();
    const run = async () => {
      try {
        const model = await getModel();
        const res = await requestJson('POST', AI_URL, {
          model,
          messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
          temperature: opts.temperature == null ? 0.7 : opts.temperature,
          max_tokens: opts.maxTokens || 400
        }, opts.timeoutMs || AI_TIMEOUT_MS);
        const content = res && res.choices && res.choices[0] && res.choices[0].message && res.choices[0].message.content;
        if (!content) throw new Error('Empty reply from AI');
        lastStatus = { ok: true, at: new Date().toISOString(), detail: kind + ' ok, model ' + model + ', ' + (Date.now() - started) + 'ms' };
        return String(content);
      } catch (err) {
        lastStatus = { ok: false, at: new Date().toISOString(), detail: kind + ': ' + err.message };
        throw err;
      }
    };
    queue.push({ prio, seq: seq++, run, resolve, reject });
    pump();
  });
}

function extractJson(text) {
  if (!text) return null;
  const t = String(text).replace(/```(?:json)?/gi, '');
  const starts = [t.indexOf('{'), t.indexOf('[')].filter((i) => i !== -1);
  if (!starts.length) return null;
  const start = Math.min.apply(null, starts);
  const end = Math.max(t.lastIndexOf('}'), t.lastIndexOf(']'));
  if (end <= start) return null;
  try { return JSON.parse(t.slice(start, end + 1)); } catch (e) { return null; }
}

function setStatus(s) { lastStatus = s; }

module.exports = { chat, extractJson, getStatus: () => lastStatus, setStatus, AI_URL };
