/* Bilal's Playground - browser client */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var socket = io({ autoConnect: false, reconnectionDelayMax: 4000 });

  // ------------------------------------------------------------ storage helpers
  function store(kind, key, val) {
    try {
      var s = kind === 'local' ? window.localStorage : window.sessionStorage;
      if (val === undefined) return s.getItem(key);
      s.setItem(key, val);
    } catch (e) { return null; }
  }
  function uid() { return (Date.now().toString(36) + Math.random().toString(36).slice(2, 10)).slice(0, 20); }
  var clientId = store('session', 'bp-client') || uid();
  store('session', 'bp-client', clientId);

  // ------------------------------------------------------------ state
  var S = null;
  var joined = null;
  var clockOffset = 0;
  var strokes = [];
  var redoStack = [];
  var tool = { mode: 'pen', color: '#16181D', size: 10, custom: false };
  var drawing = null;
  var shapeStart = null;
  var pending = [];
  var lastPreviewKey = '';
  var galleryItems = [];
  var hofData = null;
  var hofTab = 'week';
  var currentScreen = 'home';

  var COLORS = ['#16181D', '#5A6070', '#B8BFCC', '#FFFFFF', '#D7263D', '#8E1B2B', '#FF7A1A', '#FFC93C', '#F6E27A',
    '#9BD65B', '#1F9D55', '#0E9F8A', '#7CC8F2', '#2F5BFF', '#1C2E7A', '#7A3FD1', '#E85D9E', '#8A4B2A', '#F2C9A0', '#C68B59'];

  var ICON = {
    like: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10v11H3V10h4Z"/><path d="M7 10l4-8c1.7 0 3 1.3 3 3v4h5.5a2 2 0 0 1 2 2.4l-1.6 8A2 2 0 0 1 18 21H7"/></svg>',
    laugh: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M7.5 13.5a4.5 4.5 0 0 0 9 0Z"/><path d="M8.5 9.5h.01M15.5 9.5h.01"/></svg>',
    medal: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="15" r="6"/><path d="M8.5 10.2 5 3h5l2 4 2-4h5l-3.5 7.2"/><path d="m12 12.5.9 1.8 2 .3-1.4 1.4.3 2-1.8-.9-1.8.9.3-2-1.4-1.4 2-.3Z"/></svg>',
    crown: '<svg viewBox="0 0 32 24" aria-hidden="true"><path d="M2 22 4 6l8 8 4-12 4 12 8-8 2 16Z" fill="#FFC93C" stroke="#16181D" stroke-width="2" stroke-linejoin="round"/></svg>'
  };

  // ------------------------------------------------------------ home / join
  var params = new URLSearchParams(location.search);
  $('nameInput').value = store('local', 'bp-name') || '';
  $('roomInput').value = (params.get('room') || store('local', 'bp-room') || 'OFFICE').toUpperCase();

  $('joinForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var name = $('nameInput').value.trim();
    var room = $('roomInput').value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '') || 'OFFICE';
    if (!name) { $('joinError').textContent = 'Please enter your name.'; return; }
    store('local', 'bp-name', name);
    store('local', 'bp-room', room);
    joined = { name: name, room: room };
    $('joinError').textContent = '';
    if (socket.connected) doJoin(); else socket.connect();
  });

  function doJoin() {
    if (!joined) return;
    socket.emit('join', { name: joined.name, room: joined.room, clientId: clientId }, function (res) {
      if (!res || !res.ok) {
        $('joinError').textContent = (res && res.error) || 'Could not join.';
        joined = null;
        socket.disconnect();
        showScreen('home');
        return;
      }
      history.replaceState(null, '', '/?room=' + encodeURIComponent(res.room));
    });
  }
  socket.on('connect', function () { $('connBanner').hidden = true; doJoin(); });
  socket.on('disconnect', function () { if (joined) $('connBanner').hidden = false; });

  // ------------------------------------------------------------ helpers
  function showScreen(id) {
    ['home', 'lobby', 'game', 'gallery', 'final'].forEach(function (s) { $(s).hidden = s !== id; });
    if (id !== currentScreen && (id === 'lobby' || id === 'final' || id === 'home')) fetchHof();
    currentScreen = id;
  }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function html(tag, cls, markup) { var n = el(tag, cls); n.innerHTML = markup; return n; }
  function avatar(p, small) {
    var a = el('div', 'avatar' + (small ? ' sm' : ''), (p.name || '?').charAt(0).toUpperCase());
    a.style.background = p.color || '#B8BFCC';
    a.style.color = isDark(p.color || '#B8BFCC') ? '#FFFFFF' : '#16181D';
    a.setAttribute('aria-hidden', 'true');
    return a;
  }
  function isDark(hex) {
    var r = parseInt(hex.substr(1, 2), 16), g = parseInt(hex.substr(3, 2), 16), b = parseInt(hex.substr(5, 2), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) < 150;
  }
  function me() { return S && S.players.filter(function (p) { return p.id === S.you; })[0]; }
  function amHost() { return S && S.hostId === S.you; }
  function amDrawer() { return S && S.drawerId === S.you; }
  function now() { return Date.now() + clockOffset; }
  function secsLeft(t) { return Math.max(0, Math.ceil((t - now()) / 1000)); }
  function fmt(n) { return Number(n || 0).toLocaleString(); }

  // ------------------------------------------------------------ incoming state
  socket.on('state', function (s) {
    var prev = S;
    S = s;
    clockOffset = s.serverNow - Date.now();
    if (prev && prev.state === 'drawing' && s.state === 'turnEnd' && prev.turnNo === s.turnNo) {
      var wasDrawer = prev.drawerId === s.you;
      setTimeout(function () { sendSnapshot(s.turnNo); }, wasDrawer ? 50 : 1500);
    }
    if (s.state === 'lobby' || s.state === 'loading') { renderLobby(); showScreen('lobby'); }
    else if (s.state === 'gallery') { renderGallery(); showScreen('gallery'); }
    else if (s.state === 'gameOver') { renderFinal(); showScreen('final'); }
    else { renderGame(prev); showScreen('game'); }
  });

  // ------------------------------------------------------------ lobby
  function renderLobby() {
    $('roomCode').textContent = S.code;
    $('playerCount').textContent = S.players.length + ' of 12';
    var tiles = $('lobbyPlayers');
    tiles.innerHTML = '';
    S.players.forEach(function (p) {
      var t = el('div', 'tile' + (p.id === S.you ? ' me' : ''));
      t.appendChild(avatar(p));
      t.appendChild(el('div', 'name', p.name));
      t.appendChild(el('div', 'tag', p.isHost ? 'Host' : (p.id === S.you ? 'You' : 'Ready')));
      tiles.appendChild(t);
    });
    if (S.players.length < 12) tiles.appendChild(el('div', 'tile empty', S.players.length < 2 ? 'Invite at least 1 more…' : 'Waiting for more…'));

    var host = amHost();
    var loading = S.state === 'loading';
    var values = { rounds: S.settings.rounds, drawTime: S.settings.drawTime, lang: S.settings.lang, commentator: S.settings.commentator ? 'on' : 'off' };
    document.querySelectorAll('#lobby .seg').forEach(function (seg) {
      var key = seg.getAttribute('data-setting');
      seg.querySelectorAll('button').forEach(function (b) {
        b.setAttribute('aria-pressed', String(String(values[key]) === b.getAttribute('data-value')));
        b.disabled = !host || loading;
      });
    });
    var ti = $('themeInput');
    if (document.activeElement !== ti || !host) ti.value = S.settings.theme;
    ti.disabled = !host || loading;
    $('previewBtn').hidden = !host;
    $('hostOnly').textContent = host ? 'You are the host' : 'Only the host can change these';
    $('startBtn').hidden = !host;
    $('waitHost').hidden = host;
    $('startBtn').disabled = loading || S.players.length < 2;
    $('startBtn').textContent = loading ? 'Getting words…' : 'Start game';
    $('lobbyNotice').hidden = !S.notice;
    $('lobbyNotice').textContent = S.notice || '';
    var key = S.settings.theme + '|' + S.settings.lang;
    if (lastPreviewKey && key !== lastPreviewKey) { $('previewWords').innerHTML = ''; $('previewNote').textContent = ''; lastPreviewKey = ''; }
  }

  document.querySelectorAll('#lobby .seg').forEach(function (seg) {
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b || !amHost()) return;
      var upd = {};
      upd[seg.getAttribute('data-setting')] = b.getAttribute('data-value');
      socket.emit('settings', upd);
    });
  });
  var themeTimer = null;
  $('themeInput').addEventListener('input', function () {
    clearTimeout(themeTimer);
    var v = this.value;
    themeTimer = setTimeout(function () { socket.emit('settings', { theme: v }); }, 400);
  });
  $('previewBtn').addEventListener('click', function () {
    clearTimeout(themeTimer);
    socket.emit('settings', { theme: $('themeInput').value });
    socket.emit('preview-words');
  });
  socket.on('preview', function (d) {
    var box = $('previewWords');
    box.innerHTML = '';
    if (d.loading) { $('previewNote').textContent = 'Asking the AI for words… (can take a few seconds)'; $('previewBtn').disabled = true; return; }
    $('previewBtn').disabled = false;
    (d.words || []).forEach(function (w) { box.appendChild(el('span', null, w)); });
    $('previewNote').textContent = d.source === 'ai' ? 'A sample of the fresh words from your AI.' : 'AI not reachable – showing built-in words.';
    lastPreviewKey = S ? S.settings.theme + '|' + S.settings.lang : '';
  });
  $('startBtn').addEventListener('click', function () { socket.emit('start'); });

  $('copyLink').addEventListener('click', function () {
    var link = location.origin + '/?room=' + encodeURIComponent(S ? S.code : '');
    var done = function () { $('copyLink').textContent = 'Copied!'; setTimeout(function () { $('copyLink').textContent = 'Copy invite link'; }, 1500); };
    var fallback = function () {
      var ta = document.createElement('textarea');
      ta.value = link; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      if (ok) done(); else { $('copyFallback').hidden = false; $('copyFallback').textContent = 'Share this link: ' + link; }
    };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(link).then(done, fallback);
    else fallback();
  });

  // ------------------------------------------------------------ game
  function renderGame(prev) {
    $('roundLabel').textContent = 'Round ' + Math.max(1, S.round) + ' of ' + S.settings.rounds;
    renderHint();
    renderGamePlayers();
    $('endGameBtn').hidden = !amHost();

    var drawerNow = amDrawer() && S.state === 'drawing';
    $('toolbar').hidden = !drawerNow;
    $('canvas').classList.toggle('can-draw', drawerNow);
    if (!drawerNow) clearPreview();

    var guessed = me() && me().guessed;
    var gi = $('guessInput');
    gi.placeholder = drawerNow || (guessed && S.state === 'drawing') ? 'Chat with players who guessed' : 'Type your guess…';

    renderWatchBar(guessed);
    renderAiHint();
    renderVote();
    renderOverlay();
    if (prev && prev.state !== 'drawing' && S.state === 'drawing' && drawerNow) beep(660, 0.08);
  }

  function renderWatchBar(guessed) {
    var wt = $('watchText');
    if (S.state === 'drawing') {
      wt.textContent = amDrawer() ? 'You are drawing. Reactions from the others show here.'
        : guessed ? 'You got it! Waiting for the others…' : S.drawerName + ' is drawing. Type your guesses in the chat!';
    } else if (S.state === 'choosing') {
      wt.textContent = amDrawer() ? 'Pick a word to start drawing' : S.drawerName + ' is picking a word…';
    } else {
      wt.textContent = 'Next turn coming up…';
    }
    $('watchBar').hidden = false;

    var r = S.reactions;
    $('reactBar').hidden = !r;
    if (r) {
      document.querySelectorAll('#reactBar .react').forEach(function (b) {
        var type = b.getAttribute('data-react');
        b.querySelector('[data-count]').textContent = r[type];
        b.setAttribute('aria-pressed', String(!!r.mine[type]));
        b.disabled = !r.canReact;
      });
    }
    updateHintAsk();
  }

  function updateHintAsk() {
    var h = S && S.aiHint;
    var btn = $('hintAskBtn');
    if (!h || !h.canAsk || S.state !== 'drawing') { btn.hidden = true; return; }
    btn.hidden = false;
    var wait = secsLeft(h.availableAt);
    btn.disabled = wait > 0;
    $('hintAskText').textContent = wait > 0 ? 'Hint vote in ' + wait + 's' : 'Ask for a hint';
  }
  $('hintAskBtn').addEventListener('click', function () { socket.emit('hint-ask'); });

  function renderAiHint() {
    var h = S.aiHint;
    var banner = $('aiHintBanner');
    if (!h || h.state !== 'given') { banner.hidden = true; return; }
    banner.hidden = false;
    banner.classList.toggle('pending', !h.text);
    $('aiHintText').textContent = h.text ? 'Hint: ' + h.text : 'The hint is on its way…';
  }

  function renderVote() {
    var v = S.aiHint && S.aiHint.vote;
    var panel = $('votePanel');
    if (!v) { panel.hidden = true; return; }
    panel.hidden = false;
    $('voteTitle').textContent = v.by + ' wants a hint';
    $('voteCounts').textContent = v.yes + ' yes · ' + v.no + ' no · ' + v.total + ' can vote. More than half must say yes.';
    $('voteYesBar').style.width = (v.total ? Math.min(100, Math.round(v.yes / v.total * 100)) : 0) + '%';
    $('voteButtons').hidden = !v.canVote;
    document.querySelectorAll('#voteButtons [data-vote]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(v.mine === b.getAttribute('data-vote')));
    });
    $('voteTimer').textContent = secsLeft(v.endsAt) + 's';
  }
  document.querySelectorAll('#voteButtons [data-vote]').forEach(function (b) {
    b.addEventListener('click', function () { socket.emit('hint-vote', b.getAttribute('data-vote')); });
  });

  function renderHint() {
    var h = $('hint');
    h.innerHTML = '';
    h.classList.remove('reveal');
    if (S.state === 'drawing' && S.hint) {
      var full = S.hint.indexOf('_') === -1;
      var letters = S.hint.filter(function (c) { return c !== ' '; }).length;
      var parts = S.hint.join('').split(' ').map(function (w) { return w.length; });
      $('hintLabel').textContent = amDrawer() ? 'Draw this · ' + S.difficulty : (full ? 'You guessed it!' : 'Guess the word · ' + (parts.length > 1 ? parts.join(' + ') : letters) + ' letters');
      if (full) h.classList.add('reveal');
      S.hint.forEach(function (c) { h.appendChild(c === ' ' ? el('span', 'gap') : el('span', null, c)); });
    } else if (S.state === 'choosing') {
      $('hintLabel').textContent = amDrawer() ? 'Your turn' : S.drawerName + ' is choosing';
      h.textContent = '…';
    } else if (S.state === 'turnEnd' && S.result) {
      $('hintLabel').textContent = 'The word was';
      h.classList.add('reveal');
      h.textContent = S.result.word;
    } else {
      $('hintLabel').innerHTML = '&nbsp;';
    }
  }

  function renderGamePlayers() {
    var list = $('gamePlayers');
    list.innerHTML = '';
    S.players.slice().sort(function (a, b) { return b.score - a.score; }).forEach(function (p) {
      var cls = 'gp';
      var status = 'Thinking…';
      if (p.isDrawer && (S.state === 'drawing' || S.state === 'choosing')) { cls += ' drawing'; status = S.state === 'choosing' ? 'Picking a word' : 'Drawing now'; }
      else if (p.guessed && S.state === 'drawing') { cls += ' guessed'; status = 'Guessed it'; }
      else if (S.state !== 'drawing') status = p.isHost ? 'Host' : ' ';
      var li = el('li', cls);
      li.appendChild(avatar(p, true));
      var who = el('div', 'who');
      who.appendChild(el('div', 'nm', p.name + (p.id === S.you ? ' (you)' : '')));
      var st = el('div', 'st', status);
      if (p.badges) {
        var bc = html('span', 'badge-count', ICON.medal + p.badges);
        bc.setAttribute('title', p.badges + ' badges this game');
        st.appendChild(document.createTextNode(' '));
        st.appendChild(bc);
      }
      who.appendChild(st);
      li.appendChild(who);
      li.appendChild(el('div', 'pts', String(p.score)));
      list.appendChild(li);
    });
  }

  function renderOverlay() {
    var ov = $('overlay'), card = $('overlayCard');
    card.innerHTML = '';
    if (S.state === 'choosing' && amDrawer() && S.choices) {
      var t = el('div');
      t.appendChild(el('h2', null, 'Your turn to draw!'));
      t.appendChild(el('p', 'muted', 'Pick one word. Harder words score more.'));
      card.appendChild(t);
      var grid = el('div', 'choices');
      S.choices.forEach(function (c, i) {
        var b = el('button', 'choice');
        b.type = 'button';
        var mult = { easy: '1×', medium: '1.5×', hard: '2×' }[c.difficulty];
        b.appendChild(el('span', 'diff ' + c.difficulty, c.difficulty + ' · ' + mult));
        b.appendChild(el('span', 'word', c.word));
        b.addEventListener('click', function () { socket.emit('choose', i); });
        grid.appendChild(b);
      });
      card.appendChild(grid);
      ov.hidden = false;
    } else if (S.state === 'choosing') {
      card.appendChild(el('div', 'spinner'));
      card.appendChild(el('h2', 'center', S.drawerName + ' is picking a word…'));
      ov.hidden = false;
    } else if (S.state === 'turnEnd' && S.result) {
      var r = S.result;
      var why = r.reason === 'all' ? 'Everyone guessed it!' : r.reason === 'left' ? 'The drawer left.' : r.reason === 'skip' ? 'Turn skipped.' : 'Time\'s up!';
      card.appendChild(el('p', 'eyebrow center', why + ' The word was'));
      card.appendChild(el('div', 'big-word', r.word));
      card.appendChild(el('p', 'muted center', r.guessedCount + ' of ' + r.possible + ' guessed it · drawn by ' + r.drawerName));
      var rows = el('div', 'result-rows');
      r.rows.forEach(function (row) {
        var d = el('div', 'result-row');
        d.appendChild(avatar(row, true));
        var nm = el('span', 'nm', row.name);
        if (row.badges && row.badges.length) { nm.appendChild(el('br')); nm.appendChild(el('span', 'row-badges', row.badges.join(', '))); }
        d.appendChild(nm);
        var cls = 'delta' + (row.delta > 0 ? (row.isDrawer ? ' drawer' : ' plus') : '');
        d.appendChild(el('span', cls, row.delta > 0 ? '+' + row.delta + (row.isDrawer ? ' drawer' : '') : '+0'));
        d.appendChild(el('span', 'pts strong', String(row.total)));
        rows.appendChild(d);
      });
      card.appendChild(rows);
      ov.hidden = false;
    } else {
      ov.hidden = true;
    }
  }

  // reactions
  document.querySelectorAll('#reactBar .react').forEach(function (b) {
    b.addEventListener('click', function () { socket.emit('react', b.getAttribute('data-react')); });
  });
  socket.on('react', function (d) {
    var box = $('floaters');
    if (!box || $('game').hidden) return;
    var f = el('div', 'floater');
    f.style.left = (8 + Math.random() * 80) + '%';
    f.appendChild(html('div', 'bubble ' + d.type, ICON[d.type] || ''));
    f.appendChild(el('span', 'who', d.name));
    box.appendChild(f);
    setTimeout(function () { f.remove(); }, 2300);
  });

  // badges
  var badgeQueue = [], badgeBusy = false;
  socket.on('badge', function (b) { badgeQueue.push(b); nextBadge(); });
  function nextBadge() {
    if (badgeBusy || !badgeQueue.length) return;
    var b = badgeQueue.shift();
    badgeBusy = true;
    var pop = $('badgePop');
    pop.innerHTML = '';
    pop.appendChild(html('div', 'medal', ICON.medal));
    var txt = el('div');
    txt.appendChild(el('strong', null, b.name + '  +' + b.points));
    txt.appendChild(el('span', null, b.player + ' · ' + b.desc));
    pop.appendChild(txt);
    pop.hidden = false;
    beep(880, 0.09); setTimeout(function () { beep(1175, 0.12); }, 110);
    setTimeout(function () { pop.hidden = true; badgeBusy = false; nextBadge(); }, 2600);
  }

  // timer tick
  setInterval(function () {
    if (!S) return;
    var active = S.endsAt && (S.state === 'drawing' || S.state === 'choosing' || S.state === 'turnEnd');
    if (!active) { $('timerText').textContent = '--'; $('timer').classList.remove('urgent'); }
    else {
      var left = secsLeft(S.endsAt);
      $('timerText').textContent = left + 's';
      $('timer').classList.toggle('urgent', S.state === 'drawing' && left <= 10);
    }
    if (S.state === 'drawing') {
      updateHintAsk();
      if (S.aiHint && S.aiHint.vote) $('voteTimer').textContent = secsLeft(S.aiHint.vote.endsAt) + 's';
    }
    if (S.state === 'gallery') $('galleryTimer').textContent = secsLeft(S.endsAt) + 's';
  }, 250);

  $('skipBtn').addEventListener('click', function () { if (confirm('Skip your turn?')) socket.emit('skip-turn'); });
  $('endGameBtn').addEventListener('click', function () { if (confirm('End the game for everyone and go back to the lobby?')) socket.emit('end-game'); });

  // ------------------------------------------------------------ chat
  $('guessForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = $('guessInput').value.trim();
    if (!v) return;
    socket.emit('guess', v);
    $('guessInput').value = '';
  });
  socket.on('msg', function (m) {
    var box = $('messages');
    var atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
    var d = el('div', 'm ' + (m.type === 'hint' ? 'hintmsg' : m.type));
    if (m.type === 'chat' || m.type === 'chat-secret' || m.type === 'ai') {
      d.appendChild(el('b', null, m.name + ': '));
      d.appendChild(document.createTextNode(m.text));
    } else {
      d.textContent = m.text;
    }
    box.appendChild(d);
    while (box.children.length > 200) box.removeChild(box.firstChild);
    if (atBottom) box.scrollTop = box.scrollHeight;
    if (m.type === 'correct') beep(880, 0.12);
    if (m.type === 'hint') beep(520, 0.15);
  });

  // ------------------------------------------------------------ gallery (end-of-game vote)
  socket.on('gallery', function (items) {
    galleryItems = items || [];
    if (S && S.state === 'gallery') renderGallery();
    if (S && S.state === 'gameOver') renderFinal();
  });

  function galleryCard(item, index, list, opts) {
    var c = el('div', 'gcard');
    var thumb = el('button', 'thumb');
    thumb.type = 'button';
    thumb.setAttribute('aria-label', 'View drawing of ' + item.word + ' by ' + item.drawerName);
    var img = el('img');
    img.src = item.image; img.alt = 'Drawing of ' + item.word + ' by ' + item.drawerName;
    thumb.appendChild(img);
    thumb.addEventListener('click', function () { openLightbox(list, index); });
    c.appendChild(thumb);
    var info = el('div', 'info');
    info.appendChild(el('div', 'gword', item.word));
    var by = el('div', 'gby');
    var dot = el('i'); dot.style.background = item.drawerColor || '#B8BFCC';
    by.appendChild(dot); by.appendChild(document.createTextNode('by ' + item.drawerName));
    info.appendChild(by);
    var re = el('div', 'greacts');
    re.appendChild(html('span', null, ICON.like + item.likes));
    re.appendChild(html('span', null, ICON.laugh + item.laughs));
    info.appendChild(re);
    if (opts && opts.vote) {
      var mine = item.drawerId === S.you;
      var voted = S.gallery && S.gallery.myVote === item.id;
      var b = el('button', 'btn ' + (voted ? 'btn-primary' : 'btn-ghost'), mine ? 'Your drawing' : voted ? 'Your vote' : 'Vote');
      b.type = 'button';
      b.disabled = mine || !(S.gallery && S.gallery.canVote);
      b.setAttribute('aria-pressed', String(!!voted));
      b.addEventListener('click', function () { socket.emit('gallery-vote', item.id); });
      info.appendChild(b);
      if (voted) c.classList.add('voted');
    }
    c.appendChild(info);
    return c;
  }

  function renderGallery() {
    var grid = $('galleryGrid');
    grid.innerHTML = '';
    galleryItems.forEach(function (it, i) { grid.appendChild(galleryCard(it, i, galleryItems, { vote: true })); });
    var g = S.gallery || { votes: 0, voters: 0 };
    $('galleryVotes').textContent = g.votes + ' of ' + g.voters + ' voted';
    $('gallerySkip').hidden = !amHost();
    $('galleryTimer').textContent = secsLeft(S.endsAt) + 's';
  }
  $('gallerySkip').addEventListener('click', function () { socket.emit('gallery-skip'); });

  // ------------------------------------------------------------ final
  function renderFinal() {
    var F = S.final || {};
    var f = F.ranking || [];
    $('winnerName').textContent = f[0] ? f[0].name : '–';
    var pod = $('podium');
    pod.innerHTML = '';
    var heights = [150, 110, 80];
    [1, 0, 2].forEach(function (i) {
      var p = f[i];
      if (!p) return;
      var d = el('div', 'pod' + (i === 0 ? ' first' : ''));
      if (i === 0) d.appendChild(html('span', null, ICON.crown.replace('<svg', '<svg class="crown"')));
      d.appendChild(avatar(p));
      d.appendChild(el('div', 'nm', p.name));
      var blk = el('div', 'block');
      blk.style.height = heights[i] + 'px';
      blk.appendChild(el('span', 'place', String(i + 1)));
      blk.appendChild(el('span', null, p.score + ' pts'));
      d.appendChild(blk);
      pod.appendChild(d);
    });

    // drawing of the game
    var w = F.winnerDrawing;
    var item = w && galleryItems.filter(function (x) { return x.id === w.id; })[0];
    $('dotgCard').hidden = !item;
    if (item) {
      $('dotgImg').src = item.image;
      $('dotgImg').alt = 'Drawing of ' + item.word + ' by ' + item.drawerName;
      $('dotgTitle').textContent = item.word;
      $('dotgSub').textContent = 'by ' + item.drawerName + ' · ' + w.votes + ' vote' + (w.votes === 1 ? '' : 's') + ' · +100 points';
    }

    // awards
    var aw = $('awards');
    aw.innerHTML = '';
    if (F.pending) {
      var wait = el('div', 'card awards-wait');
      wait.appendChild(el('div', 'spinner'));
      wait.appendChild(el('span', 'muted strong', 'The AI is writing the awards…'));
      aw.appendChild(wait);
    } else if (!F.awards || !F.awards.length) {
      aw.appendChild(el('p', 'muted', 'No awards this time. Play a longer game!'));
    } else {
      F.awards.forEach(function (a) {
        var p = f.filter(function (x) { return x.name === a.name; })[0] || { name: a.name };
        var c = el('div', 'card award');
        c.appendChild(el('div', 'atitle', a.title));
        var nm = el('div', 'aname');
        nm.appendChild(avatar(p, true));
        nm.appendChild(document.createTextNode(a.name));
        c.appendChild(nm);
        c.appendChild(el('p', 'aline', a.line));
        aw.appendChild(c);
      });
    }

    // best wrong guesses
    var fl = $('funnyList');
    fl.innerHTML = '';
    var funny = F.funniest || [];
    $('funnySection').hidden = !funny.length;
    funny.forEach(function (g) {
      var li = el('li');
      li.appendChild(el('q', null, g.text));
      li.appendChild(el('span', 'fsub', g.name + ' · the word was "' + g.word + '"'));
      fl.appendChild(li);
    });

    var list = $('finalList');
    list.innerHTML = '';
    f.forEach(function (p, i) {
      var li = el('li');
      li.appendChild(el('span', 'rk', String(i + 1)));
      li.appendChild(avatar(p, true));
      li.appendChild(el('span', 'nm', p.name));
      if (p.badges) li.appendChild(html('span', 'badge-count', ICON.medal + p.badges));
      li.appendChild(el('span', 'strong', p.score + ' pts'));
      list.appendChild(li);
    });
    $('viewGalleryBtn').hidden = !galleryItems.length;
    $('lobbyBtn').hidden = !amHost();
    $('finalWait').textContent = amHost() ? 'Play again with the same group?' : 'Waiting for the host…';
  }
  $('lobbyBtn').addEventListener('click', function () { socket.emit('back-to-lobby'); });
  $('viewGalleryBtn').addEventListener('click', function () {
    var grid = $('allGrid');
    grid.innerHTML = '';
    galleryItems.forEach(function (it, i) { grid.appendChild(galleryCard(it, i, galleryItems, null)); });
    openModal('allDrawings');
  });

  // ------------------------------------------------------------ modals
  var openModals = [];
  function openModal(id) {
    if (openModals.indexOf(id) === -1) openModals.push(id);
    $('modalScrim').hidden = false;
    $(id).hidden = false;
    openModals.forEach(function (m, i) { $(m).style.zIndex = 71 + i * 2; });
    $('modalScrim').style.zIndex = 70 + (openModals.length - 1) * 2;
    var f = $(id).querySelector('[data-close]');
    if (f) f.focus();
  }
  function closeModal() {
    var id = openModals.pop();
    if (id) $(id).hidden = true;
    if (!openModals.length) $('modalScrim').hidden = true;
    else $('modalScrim').style.zIndex = 70 + (openModals.length - 1) * 2;
  }
  $('modalScrim').addEventListener('click', closeModal);
  document.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', closeModal); });

  var lb = { list: [], i: 0 };
  function openLightbox(list, i) { lb.list = list; lb.i = i; showLightbox(); openModal('lightbox'); }
  function showLightbox() {
    var it = lb.list[lb.i];
    if (!it) return;
    $('lbTitle').textContent = it.word;
    $('lbSub').textContent = 'by ' + it.drawerName + ' · ' + (lb.i + 1) + ' of ' + lb.list.length;
    $('lbImg').src = it.image;
    $('lbImg').alt = 'Drawing of ' + it.word + ' by ' + it.drawerName;
    $('lbDownload').href = it.image;
    $('lbDownload').setAttribute('download', (it.word + '-by-' + it.drawerName).replace(/[^a-z0-9-]+/gi, '-').toLowerCase() + '.jpg');
    $('lbPrev').disabled = lb.i === 0;
    $('lbNext').disabled = lb.i >= lb.list.length - 1;
  }
  $('lbPrev').addEventListener('click', function () { if (lb.i > 0) { lb.i--; showLightbox(); } });
  $('lbNext').addEventListener('click', function () { if (lb.i < lb.list.length - 1) { lb.i++; showLightbox(); } });

  // ------------------------------------------------------------ hall of fame
  function fetchHof() {
    fetch('/api/hall-of-fame', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
      hofData = d;
      renderChamps();
      if (!$('hofModal').hidden) renderHof();
    }).catch(function () { /* offline: keep old banner */ });
  }
  function renderChamps() {
    var c = hofData && hofData.champion;
    var last = hofData && hofData.lastChampion;
    document.querySelectorAll('[data-champ]').forEach(function (box) {
      box.querySelector('.champ-name').textContent = c ? c.name : 'No winner yet this week';
      var sub = c ? c.wins + ' win' + (c.wins === 1 ? '' : 's') + ' · ' + fmt(c.points) + ' points' : 'Win a game to take the crown';
      if (last) sub += ' · Last week: ' + last.name;
      box.querySelector('.champ-sub').textContent = sub;
    });
  }
  function renderHof() {
    var rows = hofData ? hofData[hofTab] : [];
    var body = $('hofBody');
    body.innerHTML = '';
    document.querySelectorAll('[data-hof]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-hof') === hofTab)); });
    var c = hofData && hofData.champion, last = hofData && hofData.lastChampion;
    $('hofChamps').textContent = (hofData ? hofData.totalGames + (hofData.totalGames === 1 ? ' game' : ' games') + ' played in total. ' : '') +
      (c ? 'Champion of the week: ' + c.name + '. ' : '') + (last ? 'Last week: ' + last.name + '.' : '');
    if (!rows || !rows.length) {
      var tr = el('tr'); var td = el('td', null, hofTab === 'week' ? 'No games finished this week yet.' : 'No games finished yet.');
      td.colSpan = 8; td.style.textAlign = 'center'; tr.appendChild(td); body.appendChild(tr);
      return;
    }
    rows.forEach(function (r, i) {
      var tr = el('tr', i === 0 && r.wins ? 'top' : '');
      tr.appendChild(el('td', null, String(i + 1)));
      var name = el('td');
      var span = el('span', 'hof-name');
      if (i === 0 && r.wins) span.appendChild(html('span', null, ICON.crown));
      span.appendChild(document.createTextNode(r.name));
      name.appendChild(span);
      tr.appendChild(name);
      [r.wins, r.games, fmt(r.points), fmt(r.best), r.correct, r.badges].forEach(function (v) { tr.appendChild(el('td', null, String(v))); });
      body.appendChild(tr);
    });
  }
  document.querySelectorAll('[data-open-hof]').forEach(function (b) {
    b.addEventListener('click', function () { renderHof(); openModal('hofModal'); fetchHof(); });
  });
  document.querySelectorAll('[data-hof]').forEach(function (b) {
    b.addEventListener('click', function () { hofTab = b.getAttribute('data-hof'); renderHof(); });
  });

  // ------------------------------------------------------------ canvas (fixed 1000x750 so fills look the same for everyone)
  var canvas = $('canvas');
  var ctx = canvas.getContext('2d', { willReadFrequently: true });
  var pcanvas = $('preview');
  var pctx = pcanvas.getContext('2d');
  var W = 1000, H = 750;

  function redraw() {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, W, H);
    strokes.forEach(function (s) { drawOp(ctx, s, 0); });
  }
  function styleFor(c, s) {
    c.strokeStyle = s.c; c.fillStyle = s.c; c.lineWidth = s.w; c.lineCap = 'round'; c.lineJoin = 'round';
  }
  function drawOp(c, s, from) {
    var p = s.p;
    if (!p || !p.length) return;
    var k = s.k || 'pen';
    if (k === 'fill') { floodFill(p[0][0], p[0][1], s.c); return; }
    styleFor(c, s);
    if (k === 'line' || k === 'rect' || k === 'ellipse') {
      if (p.length < 2) return;
      var x0 = p[0][0], y0 = p[0][1], x1 = p[1][0], y1 = p[1][1];
      c.beginPath();
      if (k === 'line') { c.moveTo(x0, y0); c.lineTo(x1, y1); }
      else if (k === 'rect') { c.rect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0)); }
      else { c.ellipse((x0 + x1) / 2, (y0 + y1) / 2, Math.max(0.5, Math.abs(x1 - x0) / 2), Math.max(0.5, Math.abs(y1 - y0) / 2), 0, 0, Math.PI * 2); }
      c.stroke();
      return;
    }
    if (p.length === 1 && from === 0) {
      c.beginPath(); c.arc(p[0][0], p[0][1], s.w / 2, 0, Math.PI * 2); c.fill();
      return;
    }
    var start = Math.max(0, from - 1);
    c.beginPath();
    c.moveTo(p[start][0], p[start][1]);
    for (var i = start + 1; i < p.length; i++) c.lineTo(p[i][0], p[i][1]);
    c.stroke();
  }

  // scanline flood fill with a small tolerance (covers anti-aliased edges), plus a 1px spread
  function floodFill(sx, sy, hex) {
    sx = Math.max(0, Math.min(W - 1, Math.round(sx)));
    sy = Math.max(0, Math.min(H - 1, Math.round(sy)));
    var img = ctx.getImageData(0, 0, W, H), d = img.data;
    var fr = parseInt(hex.substr(1, 2), 16), fg = parseInt(hex.substr(3, 2), 16), fb = parseInt(hex.substr(5, 2), 16);
    var si = (sy * W + sx) * 4;
    var tr = d[si], tg = d[si + 1], tb = d[si + 2];
    if (Math.abs(tr - fr) < 8 && Math.abs(tg - fg) < 8 && Math.abs(tb - fb) < 8) return;
    var T = 70;
    var mask = new Uint8Array(W * H);
    var match = function (i) {
      if (mask[i]) return false;
      var o = i * 4;
      return Math.abs(d[o] - tr) <= T && Math.abs(d[o + 1] - tg) <= T && Math.abs(d[o + 2] - tb) <= T;
    };
    var stack = [sx, sy];
    while (stack.length) {
      var y = stack.pop(), x = stack.pop();
      var i = y * W + x;
      while (x > 0 && match(i - 1)) { x--; i--; }
      var up = false, down = false;
      while (x < W && match(i)) {
        mask[i] = 1;
        if (y > 0) { if (match(i - W)) { if (!up) { stack.push(x, y - 1); up = true; } } else up = false; }
        if (y < H - 1) { if (match(i + W)) { if (!down) { stack.push(x, y + 1); down = true; } } else down = false; }
        x++; i++;
      }
    }
    for (var p = 0; p < W * H; p++) {
      var paint = mask[p];
      if (!paint) {
        var px = p % W;
        paint = (px > 0 && mask[p - 1]) || (px < W - 1 && mask[p + 1]) || (p >= W && mask[p - W]) || (p < W * (H - 1) && mask[p + W]);
      }
      if (paint) { var o = p * 4; d[o] = fr; d[o + 1] = fg; d[o + 2] = fb; d[o + 3] = 255; }
    }
    ctx.putImageData(img, 0, 0);
  }

  function findStroke(id) {
    for (var i = strokes.length - 1; i >= 0; i--) if (strokes[i].id === id) return strokes[i];
    return null;
  }
  redraw();

  socket.on('canvas', function (d) { strokes = (d && d.strokes) || []; redoStack = []; redraw(); });
  socket.on('clear', function () { strokes = []; redoStack = []; redraw(); });
  socket.on('undo', function (d) { strokes = strokes.filter(function (s) { return s.id !== d.id; }); redraw(); });
  socket.on('draw', function (op) {
    if (op.t === 's') { var s = { id: op.id, k: op.k || 'pen', c: op.c, w: op.w, p: op.p.slice() }; strokes.push(s); drawOp(ctx, s, 0); }
    else if (op.t === 'a') { var st = findStroke(op.id); if (!st) return; var from = st.p.length; Array.prototype.push.apply(st.p, op.p); drawOp(ctx, st, from); }
  });

  function sendSnapshot(turnNo) {
    if (!strokes.length) return;
    try {
      var off = document.createElement('canvas');
      off.width = 480; off.height = 360;
      var o = off.getContext('2d');
      o.fillStyle = '#FFFFFF'; o.fillRect(0, 0, 480, 360);
      o.drawImage(canvas, 0, 0, 480, 360);
      socket.emit('snapshot', { turnNo: turnNo, image: off.toDataURL('image/jpeg', 0.82) });
    } catch (e) { /* ignore */ }
  }

  function toLogical(e) {
    var r = canvas.getBoundingClientRect();
    return [Math.round((e.clientX - r.left) / r.width * W), Math.round((e.clientY - r.top) / r.height * H)];
  }
  function canDraw() { return S && S.state === 'drawing' && amDrawer(); }
  function currentColor() { return tool.mode === 'eraser' ? '#FFFFFF' : tool.color; }
  function currentSize() { return tool.mode === 'eraser' ? Math.max(tool.size, 22) : tool.size; }

  function sendOp(op) {
    if ((op.k || 'pen') === 'pen' && op.p.length > 400) {
      socket.emit('draw', { t: 's', id: op.id, k: 'pen', c: op.c, w: op.w, p: op.p.slice(0, 400) });
      for (var i = 400; i < op.p.length; i += 400) socket.emit('draw', { t: 'a', id: op.id, p: op.p.slice(i, i + 400) });
    } else {
      socket.emit('draw', { t: 's', id: op.id, k: op.k || 'pen', c: op.c, w: op.w, p: op.p });
    }
  }
  function addOwnOp(op) { strokes.push(op); drawOp(ctx, op, 0); sendOp(op); }

  function clearPreview() { pctx.clearRect(0, 0, W, H); }
  function constrain(start, pt, e) {
    if (!e.shiftKey || tool.mode === 'line') return pt;
    var dx = pt[0] - start[0], dy = pt[1] - start[1];
    var m = Math.max(Math.abs(dx), Math.abs(dy));
    return [start[0] + (dx < 0 ? -m : m), start[1] + (dy < 0 ? -m : m)];
  }

  canvas.addEventListener('pointerdown', function (e) {
    if (!canDraw() || (e.button !== undefined && e.button > 0)) return;
    e.preventDefault();
    var pt = toLogical(e);
    if (tool.mode === 'fill') {
      redoStack = [];
      addOwnOp({ id: uid(), k: 'fill', c: tool.color, w: 10, p: [pt] });
      return;
    }
    canvas.setPointerCapture(e.pointerId);
    if (tool.mode === 'line' || tool.mode === 'rect' || tool.mode === 'ellipse') {
      shapeStart = { pt: pt, end: pt };
      return;
    }
    redoStack = [];
    drawing = { id: uid(), k: 'pen', c: currentColor(), w: currentSize(), p: [pt] };
    strokes.push(drawing);
    drawOp(ctx, drawing, 0);
    socket.emit('draw', { t: 's', id: drawing.id, k: 'pen', c: drawing.c, w: drawing.w, p: [pt] });
  });
  canvas.addEventListener('pointermove', function (e) {
    if (shapeStart) {
      shapeStart.end = constrain(shapeStart.pt, toLogical(e), e);
      clearPreview();
      drawOp(pctx, { k: tool.mode, c: tool.color, w: tool.size, p: [shapeStart.pt, shapeStart.end] }, 0);
      return;
    }
    if (!drawing) return;
    var evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    if (!evs.length) evs = [e];
    var from = drawing.p.length;
    evs.forEach(function (ev) {
      var pt = toLogical(ev);
      var last = drawing.p[drawing.p.length - 1];
      if (Math.abs(pt[0] - last[0]) + Math.abs(pt[1] - last[1]) < 2) return;
      drawing.p.push(pt);
      pending.push(pt);
    });
    if (drawing.p.length > from) drawOp(ctx, drawing, from);
  });
  function endStroke(e) {
    if (shapeStart) {
      var s = shapeStart; shapeStart = null;
      clearPreview();
      if (e && e.type === 'pointerup') s.end = constrain(s.pt, toLogical(e), e);
      if (canDraw() && Math.abs(s.end[0] - s.pt[0]) + Math.abs(s.end[1] - s.pt[1]) > 3) {
        redoStack = [];
        addOwnOp({ id: uid(), k: tool.mode, c: tool.color, w: tool.size, p: [s.pt, s.end] });
      }
      return;
    }
    if (!drawing) return;
    flush();
    drawing = null;
  }
  canvas.addEventListener('pointerup', endStroke);
  canvas.addEventListener('pointercancel', endStroke);
  canvas.addEventListener('lostpointercapture', function () { if (drawing) endStroke(); });

  function flush() {
    if (drawing && pending.length) { socket.emit('draw', { t: 'a', id: drawing.id, p: pending }); pending = []; }
  }
  setInterval(flush, 40);

  // toolbar
  var colorBox = $('colors');
  COLORS.forEach(function (c) {
    var b = el('button', 'swatch');
    b.type = 'button';
    b.style.background = c;
    b.setAttribute('aria-label', 'Colour ' + c);
    b.setAttribute('data-color', c);
    b.addEventListener('click', function () { tool.color = c; tool.custom = false; if (tool.mode === 'eraser') tool.mode = 'pen'; syncTools(); });
    colorBox.appendChild(b);
  });
  $('customColor').addEventListener('input', function () {
    tool.color = this.value.toUpperCase(); tool.custom = true;
    if (tool.mode === 'eraser') tool.mode = 'pen';
    syncTools();
  });
  document.querySelectorAll('[data-tool]').forEach(function (b) {
    b.addEventListener('click', function () { tool.mode = b.getAttribute('data-tool'); syncTools(); });
  });
  document.querySelectorAll('.tool.size').forEach(function (b) {
    b.addEventListener('click', function () { tool.size = parseInt(b.getAttribute('data-size'), 10); syncTools(); });
  });
  function undo() {
    if (!canDraw() || !strokes.length) return;
    redoStack.push(strokes.pop());
    redraw();
    socket.emit('undo');
  }
  function redo() {
    if (!canDraw() || !redoStack.length) return;
    var s = redoStack.pop();
    addOwnOp({ id: uid(), k: s.k, c: s.c, w: s.w, p: s.p.slice() });
  }
  $('undoBtn').addEventListener('click', undo);
  $('redoBtn').addEventListener('click', redo);
  $('clearBtn').addEventListener('click', function () { if (!canDraw()) return; strokes = []; redoStack = []; redraw(); socket.emit('clear'); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && openModals.length) { closeModal(); return; }
    var typing = /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '') && document.activeElement.type !== 'color';
    if (!canDraw() || typing) return;
    var k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z' && !e.shiftKey) { e.preventDefault(); undo(); return; }
    if ((e.ctrlKey || e.metaKey) && (k === 'y' || (k === 'z' && e.shiftKey))) { e.preventDefault(); redo(); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    var map = { p: 'pen', b: 'pen', e: 'eraser', f: 'fill', l: 'line', r: 'rect', c: 'ellipse' };
    if (map[k]) { tool.mode = map[k]; syncTools(); }
  });
  function syncTools() {
    colorBox.querySelectorAll('.swatch').forEach(function (b) { b.setAttribute('aria-pressed', String(!tool.custom && tool.mode !== 'eraser' && b.getAttribute('data-color') === tool.color)); });
    document.querySelector('.custom-color').classList.toggle('on', tool.custom && tool.mode !== 'eraser');
    document.querySelectorAll('[data-tool]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-tool') === tool.mode)); });
    document.querySelectorAll('.tool.size').forEach(function (b) { b.setAttribute('aria-pressed', String(parseInt(b.getAttribute('data-size'), 10) === tool.size)); });
  }
  syncTools();

  // ------------------------------------------------------------ tiny sounds (offline, no files)
  var audioCtx = null;
  function beep(freq, dur) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      var o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.frequency.value = freq; o.type = 'sine';
      g.gain.setValueAtTime(0.06, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(); o.stop(audioCtx.currentTime + dur);
    } catch (e) { /* sound is optional */ }
  }

  showScreen('home');
  fetchHof();
})();
