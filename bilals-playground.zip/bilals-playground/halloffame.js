'use strict';
// Hall of fame: every finished game is saved to data/hall-of-fame.json.
// Players are matched by name (case-insensitive), since the game has no accounts.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const FILE = path.join(DATA_DIR, 'hall-of-fame.json');
const MAX_GAMES = 5000;

let db = null;
let writable = true;

function load() {
  if (db) return db;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) { /* reported on save */ }
  try {
    db = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (!db || !Array.isArray(db.games)) db = { games: [] };
  } catch (e) {
    if (e.code !== 'ENOENT') {
      try { fs.copyFileSync(FILE, FILE + '.corrupt-' + Date.now()); } catch (x) { /* ignore */ }
      console.error('[halloffame] could not read ' + FILE + ': ' + e.message);
    }
    db = { games: [] };
  }
  return db;
}

function save() {
  try {
    const tmp = FILE + '.' + process.pid + '.' + crypto.randomBytes(3).toString('hex') + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(load()));
    fs.renameSync(tmp, FILE);
    writable = true;
  } catch (e) {
    if (writable) console.error('[halloffame] cannot save to ' + FILE + ': ' + e.message + ' (run the installer again to fix permissions)');
    writable = false;
  }
}

/** players: [{ name, score, correct, drawnGuessed, badges }] sorted by score desc */
function recordGame(players, rounds) {
  if (!players || players.length < 2) return;
  const g = {
    at: new Date().toISOString(),
    rounds,
    players: players.map((p, i) => ({
      name: p.name, score: p.score, rank: i + 1,
      correct: p.correct || 0, drawnGuessed: p.drawnGuessed || 0, badges: p.badges || 0
    }))
  };
  const d = load();
  d.games.push(g);
  if (d.games.length > MAX_GAMES) d.games.splice(0, d.games.length - MAX_GAMES);
  save();
}

function weekStart(offsetWeeks) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7) + 7 * (offsetWeeks || 0)); // Monday
  return d;
}

function aggregate(from, to) {
  const map = new Map();
  load().games.forEach((g) => {
    const t = new Date(g.at);
    if ((from && t < from) || (to && t >= to)) return;
    g.players.forEach((p) => {
      const key = p.name.toLowerCase();
      let s = map.get(key);
      if (!s) { s = { name: p.name, games: 0, wins: 0, points: 0, correct: 0, drawnGuessed: 0, badges: 0, best: 0 }; map.set(key, s); }
      s.name = p.name; // latest spelling
      s.games++;
      if (p.rank === 1) s.wins++;
      s.points += p.score;
      s.correct += p.correct;
      s.drawnGuessed += p.drawnGuessed;
      s.badges += p.badges;
      s.best = Math.max(s.best, p.score);
    });
  });
  return Array.from(map.values()).sort((a, b) => b.wins - a.wins || b.points - a.points || b.games - a.games);
}

function summary() {
  const thisWeek = weekStart(0);
  const lastWeek = weekStart(-1);
  const week = aggregate(thisWeek, null);
  const prev = aggregate(lastWeek, thisWeek);
  const pickChamp = (list) => (list.length && list[0].wins > 0 ? { name: list[0].name, wins: list[0].wins, points: list[0].points } : null);
  return {
    weekStart: thisWeek.toISOString(),
    champion: pickChamp(week),
    lastChampion: pickChamp(prev),
    week: week.slice(0, 50),
    allTime: aggregate(null, null).slice(0, 50),
    totalGames: load().games.length
  };
}

module.exports = { recordGame, summary, DATA_DIR };
