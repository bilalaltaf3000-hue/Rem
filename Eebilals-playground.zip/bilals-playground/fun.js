'use strict';
// AI-powered fun for Bilal's Playground: hints, commentator lines, end-of-game awards.
// Every function has a non-AI fallback so the game never waits on (or breaks because of) the model.

const ai = require('./ai');

const SYSTEM_JSON = 'You are a helpful assistant that only answers with valid JSON.';

function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z]/g, ''); }
function oneLine(s, max) { return String(s || '').replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').replace(/^["'\s]+|["'\s]+$/g, '').trim().slice(0, max); }

// ---------------------------------------------------------------- hints
/** True when a hint would give the answer away. */
function leaks(hint, word) {
  const h = norm(hint);
  const w = norm(word);
  if (!h || !w) return true;
  if (h.indexOf(w) !== -1) return true;
  // any word of the answer that is 4+ letters long
  return String(word).toLowerCase().split(/\s+/).some((part) => {
    const p = norm(part);
    return p.length >= 4 && h.indexOf(p) !== -1;
  });
}

function fallbackHint(word, theme) {
  const letters = norm(word).length;
  const words = String(word).trim().split(/\s+/).length;
  const shape = words > 1 ? words + ' words, ' + letters + ' letters in total' : letters + ' letters';
  return 'It fits the theme "' + theme + '" and has ' + shape + '. Look closely at the drawing!';
}

/**
 * Generates one hint per word in a single AI call. Resolves to { word: hint }.
 * Words whose hint is missing or leaks the answer get a safe fallback hint.
 */
async function makeHints(words, theme, lang) {
  const out = {};
  try {
    const text = await ai.chat('hint', SYSTEM_JSON, [
      'Write one hint for each word below, for a Pictionary-style guessing game played by office colleagues in Pakistan.',
      'The game theme is "' + theme + '".',
      'Each hint: one short, fun, riddle-style sentence of at most 14 words that helps people guess the word.',
      'NEVER use the word itself, any part of it, a translation, a spelling, or its first letter. Do not say how many letters it has.',
      lang === 'urdu' || lang === 'mix' ? 'Some words are Roman Urdu; write the hints in simple English.' : '',
      'Words: ' + JSON.stringify(words),
      'Return ONLY JSON mapping each word to its hint, like {"apple": "Keeps the doctor away if you eat one daily"}.'
    ].filter(Boolean).join('\n'), { temperature: 0.7, maxTokens: 400, timeoutMs: 45000 });
    const parsed = ai.extractJson(text) || {};
    const lower = {};
    Object.keys(parsed).forEach((k) => { lower[String(k).toLowerCase().trim()] = parsed[k]; });
    words.forEach((w) => {
      const h = oneLine(lower[w], 140);
      if (h && !leaks(h, w)) out[w] = { text: h, source: 'ai' };
    });
  } catch (err) {
    console.warn('[fun] hint generation failed: ' + err.message);
  }
  words.forEach((w) => { if (!out[w]) out[w] = { text: fallbackHint(w, theme), source: 'builtin' }; });
  return out;
}

// ---------------------------------------------------------------- commentator
/**
 * One friendly line about the turn that just ended. Resolves to a string, or null to stay quiet.
 * facts: { word, drawer, guessed: [{name, seconds}], nobody, wrong: [{name, text}], likes, dislikes, reason }
 */
async function commentOnTurn(facts, lang) {
  const summary = [
    'Word: "' + facts.word + '". Drawn by ' + facts.drawer + '.',
    facts.guessed.length
      ? 'Guessed by: ' + facts.guessed.map((g) => g.name + ' in ' + g.seconds + 's').join(', ') + '.'
      : 'Nobody guessed it.',
    facts.missed && facts.missed.length ? 'Did not guess: ' + facts.missed.join(', ') + '.' : '',
    facts.wrong.length ? 'Some wrong guesses: ' + facts.wrong.slice(0, 6).map((g) => g.name + ' said "' + g.text + '"').join('; ') + '.' : '',
    facts.likes || facts.dislikes ? 'The drawing got ' + facts.likes + ' likes and ' + facts.dislikes + ' dislikes.' : '',
    facts.hintUsed ? 'Players voted for a hint this turn.' : '',
    facts.reason === 'skip' ? 'The drawer skipped the turn.' : ''
  ].filter(Boolean).join(' ');
  const text = await ai.chat('comment', 'You are a cheerful, kind game-show commentator for a drawing game played by office colleagues in Pakistan.', [
    'Write ONE short, funny comment (max 22 words) about this turn, like a sports commentator.',
    'Be kind and playful. Tease gently about guesses, never about people themselves. No insults, nothing about appearance, religion or politics.',
    lang === 'urdu' ? 'You may sprinkle in a little Roman Urdu.' : lang === 'mix' ? 'You may mix English with a little Roman Urdu.' : 'Write in English.',
    'Mention at least one player by name. Do not use emojis or hashtags. Reply with the comment only.',
    'What happened: ' + summary
  ].join('\n'), { temperature: 0.9, maxTokens: 80, timeoutMs: 30000 });
  const line = oneLine(text, 180);
  return line.length >= 8 ? line : null;
}

// ---------------------------------------------------------------- awards + funniest wrong guesses
const AWARD_DEFAULTS = {
  mindReader: { title: 'Mind Reader', line: 'Most correct guesses. Are you reading the drawer\'s thoughts?' },
  speedDemon: { title: 'Speed Demon', line: 'Fastest guess of the game. Blink and you missed it.' },
  bestArtist: { title: 'Picasso of the Office', line: 'Their drawings were guessed the most.' },
  creative: { title: 'Most Creative Guesser', line: 'Most wrong guesses, and every one of them with confidence.' },
  soClose: { title: 'So Close', line: 'Most "very close" guesses. Nearly there, every time.' },
  crowdFav: { title: 'Crowd Favourite', line: 'Their drawings got the most likes.' },
  badgeHunter: { title: 'Badge Collector', line: 'Earned the most badges this game.' }
};

function pickFunnyFallback(wrong) {
  const uniq = [];
  const seen = new Set();
  wrong.forEach((g, i) => {
    const k = norm(g.text);
    if (k.length < 3 || seen.has(k)) return;
    seen.add(k);
    uniq.push(i);
  });
  // longer, more "creative" guesses first
  uniq.sort((a, b) => wrong[b].text.length - wrong[a].text.length);
  return uniq.slice(0, 5);
}

/**
 * awards: [{ key, name, stat }] chosen by the game (facts are always correct);
 * the AI only writes a funny title and line for each, and picks the 5 funniest wrong guesses.
 * Resolves to { awards: [{key, name, stat, title, line}], funniest: [{name, text, word}] }
 */
async function endOfGame(awards, wrong, lang, highlights) {
  highlights = highlights || [];
  let captions = {};
  let titles = {};
  let funnyIdx = null;
  // one entry per distinct guess text, most recent kept
  const seenText = new Set();
  const sample = wrong.slice().reverse().filter((g) => {
    const k = norm(g.text);
    if (k.length < 2 || seenText.has(k)) return false;
    seenText.add(k);
    return true;
  }).slice(0, 80).reverse();
  try {
    const text = await ai.chat('awards', SYSTEM_JSON, [
      'A drawing-and-guessing game between office colleagues in Pakistan just ended.',
      '1) For each award below, write a funny, kind award title (max 5 words) and a one-line reason (max 18 words) that mentions the stat.',
      'Keep it playful and respectful. No insults, nothing about appearance, religion or politics. No emojis.',
      lang === 'english' ? '' : 'You may use a little Roman Urdu.',
      'Awards: ' + JSON.stringify(awards.map((a) => ({ key: a.key, player: a.name, stat: a.stat }))),
      '2) From this numbered list of wrong guesses (with the real answer), pick the 5 funniest by number.',
      sample.length ? sample.map((g, i) => i + ': ' + g.name + ' guessed "' + g.text + '" (answer: ' + g.word + ')').join('\n') : '(no wrong guesses)',
      highlights.length ? '3) For each drawing below, write a funny, kind, museum-style caption (max 12 words), as if it hangs in a gallery. You may mention the word, the artist, and what people wrongly guessed.' : '',
      highlights.length ? 'Drawings: ' + JSON.stringify(highlights.map((h) => ({ key: h.key, award: h.key, word: h.word, artist: h.drawer, fact: h.stat, wrongGuesses: h.wrongGuesses }))) : '',
      'Return ONLY JSON in this shape:',
      '{"awards": {"<key>": {"title": "...", "line": "..."}}, "funniest": [numbers]' + (highlights.length ? ', "captions": {"<drawing key>": "..."}' : '') + '}'
    ].filter(Boolean).join('\n'), { temperature: 0.8, maxTokens: 1000, timeoutMs: 75000 });
    const parsed = ai.extractJson(text) || {};
    titles = parsed.awards && typeof parsed.awards === 'object' ? parsed.awards : {};
    if (Array.isArray(parsed.funniest)) {
      funnyIdx = parsed.funniest.map((n) => parseInt(n, 10)).filter((n) => n >= 0 && n < sample.length)
        .filter((n, i, a) => a.indexOf(n) === i).slice(0, 5);
    }
    if (parsed.captions && typeof parsed.captions === 'object') {
      highlights.forEach((h) => { const c = oneLine(parsed.captions[h.key], 120); if (c) captions[h.key] = c; });
    }
  } catch (err) {
    console.warn('[fun] awards generation failed: ' + err.message);
  }
  const outAwards = awards.map((a) => {
    const t = titles[a.key] || {};
    const d = AWARD_DEFAULTS[a.key] || { title: a.key, line: '' };
    return {
      key: a.key, name: a.name, stat: a.stat,
      title: oneLine(t.title, 40) || d.title,
      line: oneLine(t.line, 140) || d.line + ' (' + a.stat + ')'
    };
  });
  const idx = funnyIdx && funnyIdx.length ? funnyIdx : pickFunnyFallback(sample);
  const funniest = idx.map((i) => ({ name: sample[i].name, text: sample[i].text, word: sample[i].word }));
  return { awards: outAwards, funniest, captions };
}

module.exports = { makeHints, fallbackHint, leaks, commentOnTurn, endOfGame, AWARD_DEFAULTS };
