'use strict';
// Hall of fame: every finished game is saved to data/hall-of-fame.json.
// Players are matched by name (case-insensitive), since the game has no accounts.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const FILE = path.join(DATA_DIR, 'hall-of-fame.json');
const MAX_GAMES = 5000;
const DRAW_DIR = path.join(DATA_DIR, 'drawings');
const MAX_FAMOUS = 120; // drawing images kept on disk (about 40 KB each)

let db = null;
let writable = true;

function load() {
  if (db) return db;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) { /* reported on save */ }
  try {
    db = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (!db || !Array.isArray(db.games)) db = { games: [] };
    if (!Array.isArray(db.famous)) db.famous = [];
  } catch (e) {
    if (e.code !== 'ENOENT') {
      try { fs.copyFileSync(FILE, FILE + '.corrupt-' + Date.now()); } catch (x) { /* ignore */ }
      console.error('[halloffame] could not read ' + FILE + ': ' + e.message);
    }
    db = { games: [], famous: [] };
  }
  return db;
}

function save() {
  try {
    const tmp = FILE + '.' + process.pid + '.' + crypto.randomBytes(3).toString('hex') + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(load()));
    fs.renameSync(tmp, FILE);
    writable = true;
  } catch (e) {
    if (writable) console.error('[halloffame] cannot save to ' + FILE + ': ' + e.message + ' (run the installer again to fix permissions)');
    writable = false;
  }
}

/**
 * players: [{ name, score, correct, drawnGuessed, badges, likes, dislikes, dotg }] sorted by score desc
 * drawings: [{ label, word, drawer, stat, caption, likes, dislikes, image (data URL) }] - the game's famous drawings
 * Returns the saved drawing records (so captions written later can be attached).
 */
function recordGame(players, rounds, drawings) {
  if (!players || players.length < 2) return [];
  const at = new Date().toISOString();
  const g = {
    at,
    rounds,
    players: players.map((p, i) => ({
      name: p.name, score: p.score, rank: i + 1,
      correct: p.correct || 0, drawnGuessed: p.drawnGuessed || 0, badges: p.badges || 0,
      likes: p.likes || 0, dislikes: p.dislikes || 0, dotg: p.dotg || 0
    }))
  };
  const d = load();
  d.games.push(g);
  if (d.games.length > MAX_GAMES) d.games.splice(0, d.games.length - MAX_GAMES);
  const saved = [];
  (drawings || []).forEach((dr) => {
    const m = /^data:image\/(jpeg|webp|png);base64,(.+)$/.exec(dr.image || '');
    if (!m) return;
    const id = Date.now().toString(36) + '-' + crypto.randomBytes(4).toString('hex');
    const file = id + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
    try {
      fs.mkdirSync(DRAW_DIR, { recursive: true });
      fs.writeFileSync(path.join(DRAW_DIR, file), Buffer.from(m[2], 'base64'));
    } catch (e) {
      console.error('[halloffame] cannot save drawing: ' + e.message);
      return;
    }
    const rec = { id, file, at, labels: dr.labels, word: dr.word, drawer: dr.drawer, stat: dr.stat || '', caption: dr.caption || '', likes: dr.likes || 0, dislikes: dr.dislikes || 0 };
    d.famous.push(rec);
    saved.push(rec);
  });
  while (d.famous.length > MAX_FAMOUS) {
    const old = d.famous.shift();
    try { fs.unlinkSync(path.join(DRAW_DIR, old.file)); } catch (e) { /* already gone */ }
  }
  save();
  return saved;
}

/** Attach captions the AI finished after the game was saved. */
function setCaptions(records, byLabel) {
  let changed = false;
  records.forEach((r) => {
    const c = r.labels.map((l) => byLabel[l]).filter(Boolean)[0];
    if (c && !r.caption) { r.caption = c; changed = true; }
  });
  if (changed) save();
}

/** Path of a saved drawing image, or null. */
function drawingFile(id) {
  if (!/^[a-z0-9]+-[0-9a-f]{8}$/.test(id)) return null;
  const rec = load().famous.find((f) => f.id === id);
  return rec ? path.join(DRAW_DIR, rec.file) : null;
}

function weekStart(offsetWeeks) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7) + 7 * (offsetWeeks || 0)); // Monday
  return d;
}

function aggregate(from, to) {
  const map = new Map();
  load().games.forEach((g) => {
    const t = new Date(g.at);
    if ((from && t < from) || (to && t >= to)) return;
    g.players.forEach((p) => {
      const key = p.name.toLowerCase();
      let s = map.get(key);
      if (!s) { s = { name: p.name, games: 0, wins: 0, points: 0, correct: 0, drawnGuessed: 0, badges: 0, best: 0, likes: 0, dislikes: 0, dotg: 0 }; map.set(key, s); }
      s.name = p.name; // latest spelling
      s.games++;
      if (p.rank === 1) s.wins++;
      s.points += p.score;
      s.correct += p.correct;
      s.drawnGuessed += p.drawnGuessed;
      s.badges += p.badges;
      s.best = Math.max(s.best, p.score);
      s.likes += p.likes || 0;
      s.dislikes += p.dislikes || 0;
      s.dotg += p.dotg || 0;
    });
  });
  return Array.from(map.values()).sort((a, b) => b.wins - a.wins || b.points - a.points || b.games - a.games);
}

function summary() {
  const thisWeek = weekStart(0);
  const lastWeek = weekStart(-1);
  const week = aggregate(thisWeek, null);
  const prev = aggregate(lastWeek, thisWeek);
  const pickChamp = (list) => (list.length && list[0].wins > 0 ? { name: list[0].name, wins: list[0].wins, points: list[0].points } : null);
  return {
    weekStart: thisWeek.toISOString(),
    champion: pickChamp(week),
    lastChampion: pickChamp(prev),
    week: week.slice(0, 50),
    allTime: aggregate(null, null).slice(0, 50),
    totalGames: load().games.length,
    famous: load().famous.slice().reverse().map((f) => ({
      id: f.id, url: '/hof/drawings/' + f.id, at: f.at, labels: f.labels, word: f.word, drawer: f.drawer,
      stat: f.stat, caption: f.caption, likes: f.likes, dislikes: f.dislikes, thisWeek: new Date(f.at) >= thisWeek
    }))
  };
}

module.exports = { recordGame, setCaptions, drawingFile, summary, DATA_DIR };
