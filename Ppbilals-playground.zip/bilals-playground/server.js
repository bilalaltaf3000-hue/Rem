'use strict';
// Bilal's Playground - an offline draw-and-guess game for the office LAN.
// Node.js + Socket.io. No internet needed. The local AI (port 8001) writes the words, hints,
// commentary and end-of-game awards; every AI feature has a built-in fallback.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Server } = require('socket.io');
const words = require('./words');
const fun = require('./fun');
const ai = require('./ai');
const hof = require('./halloffame');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = path.join(__dirname, 'public');

const MAX_PLAYERS = 12;
const CHOOSE_SECONDS = 15;
const TURN_END_SECONDS = 7;
const RECONNECT_GRACE_MS = 30000;
const EMPTY_ROOM_TTL_MS = 10 * 60 * 1000;
const MAX_STROKES = 3000;
const MAX_POINTS_PER_STROKE = 4000;
const MAX_IMAGE_CHARS = 600000;

const HINT_AT_MS = 10000;           // the AI hint appears automatically with 10 seconds left
const HINT_WAIT_MS = 4000;         // max wait for the AI hint before using the built-in one
const ROUND_INTRO_MS = 2500;       // "Round 2" announcement

const COLORS_ALLOWED = /^#[0-9a-fA-F]{6}$/;
const SIZES_ALLOWED = [4, 10, 22, 40];
const KINDS = ['pen', 'line', 'rect', 'ellipse', 'fill'];
const AVATAR_COLORS = ['#FF7A1A', '#2F5BFF', '#FFC93C', '#7A3FD1', '#D7263D', '#0E9F8A', '#8A4B2A', '#E85D9E', '#4B8BBE', '#6B8E23', '#C2410C', '#334155'];
const DIFF_MULT = { easy: 1, medium: 1.5, hard: 2 };

const BADGES = {
  firstBlood: { name: 'First Blood', points: 30, desc: 'first to guess the word' },
  sniper: { name: 'Sniper', points: 25, desc: 'guessed within 10 seconds' },
  buzzer: { name: 'Buzzer Beater', points: 15, desc: 'guessed in the last 5 seconds' },
  hatTrick: { name: 'Hat-trick', points: 50, desc: 'guessed 3 drawings in a row' },
  masterpiece: { name: 'Masterpiece', points: 50, desc: 'everyone guessed their drawing' },
  crowdPleaser: { name: 'Crowd Pleaser', points: 20, desc: 'drawing got lots of likes' },
  drawingOfGame: { name: 'Drawing of the Game', points: 100, desc: 'won the drawing vote' }
};

function log() {
  console.log.apply(console, ['[' + new Date().toISOString() + ']'].concat([].slice.call(arguments)));
}

// ---------------------------------------------------------------- static files + small API
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8'
};

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer((req, res) => {
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400); return res.end(); }

  if (urlPath === '/health') {
    return sendJson(res, 200, { ok: true, rooms: rooms.size, players: countPlayers(), ai: ai.getStatus(), aiUrl: ai.AI_URL });
  }
  if (urlPath === '/api/hall-of-fame') return sendJson(res, 200, hof.summary());
  if (urlPath.indexOf('/hof/drawings/') === 0) {
    const file = hof.drawingFile(urlPath.slice('/hof/drawings/'.length));
    if (!file) { res.writeHead(404); return res.end(); }
    return fs.readFile(file, (err, buf) => {
      if (err) { res.writeHead(404); return res.end(); }
      const ext = path.extname(file).slice(1);
      res.writeHead(200, { 'Content-Type': 'image/' + (ext === 'jpg' ? 'jpeg' : ext), 'Cache-Control': 'public, max-age=86400', 'Content-Length': buf.length, 'X-Content-Type-Options': 'nosniff' });
      res.end(buf);
    });
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, urlPath));
  if (filePath.indexOf(PUBLIC_DIR + path.sep) !== 0) { res.writeHead(403); return res.end(); }

  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.woff2' ? 'public, max-age=604800' : 'no-cache',
      'X-Content-Type-Options': 'nosniff'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
});

const io = new Server(server, { maxHttpBufferSize: 1e6, pingInterval: 20000, pingTimeout: 20000 });

// ---------------------------------------------------------------- helpers
const rooms = new Map();

function countPlayers() {
  let n = 0;
  rooms.forEach((r) => { r.players.forEach((p) => { if (p.connected) n++; }); });
  return n;
}
function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z]/g, ''); }
function levenshtein(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 99;
  const dp = [];
  for (let i = 0; i <= a.length; i++) dp[i] = [i];
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
  }
  return dp[a.length][b.length];
}
function cleanName(n) { return String(n || '').replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 16); }
function cleanRoomCode(c) { return String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8); }
function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; }
  return a;
}
function connectedPlayers(room) {
  const list = [];
  room.order.forEach((id) => { const p = room.players.get(id); if (p && p.connected) list.push(p); });
  return list;
}
function freshStats() {
  return { correct: 0, wrong: 0, close: 0, fastest: null, drawnGuessed: 0, reactionsGot: 0, badges: {}, badgeCount: 0, streak: 0 };
}

function getRoom(code) {
  let room = rooms.get(code);
  if (!room) {
    room = {
      code,
      hostId: null,
      players: new Map(),
      order: [],
      settings: { rounds: 3, drawTime: 80, theme: 'Office life + Pakistani food', lang: 'english', commentator: true, hints: true },
      state: 'lobby',
      round: 0,
      turnNo: 0,
      drawerQueue: [],
      drawerId: null,
      choices: null,
      word: null,
      difficulty: null,
      endsAt: 0,
      timers: [],
      strokes: [],
      revealed: [],
      turnScores: {},
      guessedOrder: [],
      turn: null,
      usedWords: new Set(),
      pack: null,
      packKey: null,
      packPromise: null,
      refilling: false,
      hintCache: new Map(),
      lastResult: null,
      gallery: [],
      galleryVotes: new Map(),
      wrongGuesses: [],
      endData: null,
      finalRanking: null,
      notice: '',
      emptySince: null
    };
    rooms.set(code, room);
    log('room created', code);
  }
  return room;
}

function clearTimers(room) {
  room.timers.forEach((t) => { clearTimeout(t); clearInterval(t); });
  room.timers = [];
}

function hintFor(room, forDrawer) {
  if (!room.word) return null;
  return room.word.split('').map((ch, i) => {
    if (ch === ' ') return ' ';
    if (forDrawer || room.revealed.indexOf(i) !== -1) return ch;
    return '_';
  });
}

// ---------------------------------------------------------------- state broadcast
function publicPlayers(room) {
  return connectedPlayers(room).map((p) => ({
    id: p.id, name: p.name, score: p.score, color: p.color,
    guessed: room.guessedOrder.indexOf(p.id) !== -1,
    isHost: p.id === room.hostId, isDrawer: p.id === room.drawerId,
    badges: p.g ? p.g.badgeCount : 0
  }));
}

function hintInfoFor(room) {
  const t = room.turn;
  if (!t || room.state !== 'drawing' || t.hint.state !== 'given') return null;
  return { state: 'given', text: t.hint.text };
}

function snapshotFor(room, playerId) {
  const isDrawer = playerId === room.drawerId;
  const drawer = room.players.get(room.drawerId);
  const t = room.turn;
  const snap = {
    code: room.code,
    you: playerId,
    hostId: room.hostId,
    state: room.state,
    settings: room.settings,
    round: room.round,
    turnNo: room.turnNo,
    players: publicPlayers(room),
    drawerId: room.drawerId,
    drawerName: drawer ? drawer.name : '',
    choices: isDrawer && room.state === 'choosing' ? room.choices : null,
    hint: room.state === 'drawing' ? hintFor(room, isDrawer || room.guessedOrder.indexOf(playerId) !== -1) : null,
    difficulty: room.state === 'drawing' ? room.difficulty : null,
    endsAt: room.endsAt,
    serverNow: Date.now(),
    result: room.state === 'turnEnd' ? room.lastResult : null,
    aiHint: hintInfoFor(room),
    reactions: null,
    gallery: null,
    final: room.state === 'gameOver' ? room.endData : null,
    notice: room.notice
  };
  if (t && (room.state === 'drawing' || room.state === 'turnEnd')) {
    snap.reactions = {
      like: t.reactions.like.size, dislike: t.reactions.dislike.size,
      mine: { like: t.reactions.like.has(playerId), dislike: t.reactions.dislike.has(playerId) },
      canReact: !isDrawer
    };
  }
  if (room.state === 'gallery') {
    const voters = galleryVoters(room);
    snap.gallery = {
      votes: room.galleryVotes.size, voters: voters.length,
      myVote: room.galleryVotes.get(playerId) || null,
      canVote: voters.some((p) => p.id === playerId)
    };
  }
  return snap;
}

function broadcastState(room) {
  room.players.forEach((p) => {
    if (p.connected && p.socketId) io.to(p.socketId).emit('state', snapshotFor(room, p.id));
  });
}

function sysMsg(room, text, kind) {
  io.to(room.code).emit('msg', { type: kind || 'system', text });
}

// ---------------------------------------------------------------- badges
function giveBadge(room, player, key) {
  const b = BADGES[key];
  if (!b || !player) return;
  player.score += b.points;
  player.g.badges[key] = (player.g.badges[key] || 0) + 1;
  player.g.badgeCount++;
  if (room.turnScores) room.turnScores[player.id] = (room.turnScores[player.id] || 0) + b.points;
  if (room.turn) room.turn.badges.push({ id: player.id, key });
  // badges are silent during the game; they show on the results page and in the hall of fame
}

// ---------------------------------------------------------------- word packs
function packKeyOf(room) { return room.settings.theme.toLowerCase().trim() + '|' + room.settings.lang; }

function ensurePack(room) {
  const key = packKeyOf(room);
  if (room.pack && room.packKey === key) return Promise.resolve(room.pack);
  if (room.packPromise && room.packPromiseKey === key) return room.packPromise;
  room.packPromiseKey = key;
  room.packPromise = words.generatePack(room.settings.theme, room.settings.lang).then((pack) => {
    if (packKeyOf(room) === key) { room.pack = pack; room.packKey = key; room.usedWords = new Set(); room.hintCache = new Map(); }
    room.packPromise = null;
    return pack;
  });
  return room.packPromise;
}

function pickFrom(room, list) {
  const fresh = list.filter((w) => !room.usedWords.has(w));
  const pool = fresh.length ? fresh : list;
  return pool[Math.floor(Math.random() * pool.length)];
}

function maybeRefill(room) {
  const pack = room.pack;
  if (!pack || pack.source !== 'ai' || room.refilling) return;
  const low = ['easy', 'medium', 'hard'].some((k) => pack[k].filter((w) => !room.usedWords.has(w)).length < 6);
  if (!low) return;
  room.refilling = true;
  words.refillPack(pack, room.settings.theme, room.settings.lang, room.usedWords)
    .catch((err) => log('refill failed:', err.message))
    .then(() => { room.refilling = false; });
}

function makeChoices(room) {
  const pack = room.pack || words.fallbackPack(room.settings.lang);
  const out = [];
  ['easy', 'medium', 'hard'].forEach((d) => {
    let w = pickFrom(room, pack[d]);
    let guard = 0;
    while (out.some((c) => c.word === w) && guard++ < 10) w = pickFrom(room, pack[d]);
    out.push({ word: w, difficulty: d });
  });
  maybeRefill(room);
  return out;
}

// ---------------------------------------------------------------- AI hints (prepared before anyone asks)
function prefetchHints(room, list) {
  const need = list.filter((w) => !room.hintCache.has(w));
  if (!need.length) return;
  const batch = fun.makeHints(need, room.settings.theme, room.settings.lang);
  need.forEach((w) => {
    const entry = { promise: batch.then((map) => { entry.value = map[w]; return map[w]; }), value: null };
    room.hintCache.set(w, entry);
  });
}

function getHint(room, word) {
  if (!room.hintCache.has(word)) prefetchHints(room, [word]);
  const entry = room.hintCache.get(word);
  if (entry.value) return Promise.resolve(entry.value);
  const fallback = { text: fun.fallbackHint(word, room.settings.theme), source: 'builtin' };
  return Promise.race([entry.promise, new Promise((resolve) => setTimeout(() => resolve(fallback), HINT_WAIT_MS))]);
}

function showAutoHint(room, turnNo) {
  const t = room.turn;
  if (!t || room.state !== 'drawing' || room.turnNo !== turnNo || t.hint.state !== 'none' || !room.settings.hints) return;
  t.hint.state = 'given';
  t.hint.text = null;
  getHint(room, room.word).then((h) => {
    if (room.turnNo !== turnNo || room.state !== 'drawing') return;
    t.hint.text = h.text;
    io.to(room.code).emit('msg', { type: 'hint', text: 'Hint: ' + h.text });
    broadcastState(room);
  });
}

function roundIntro(room) {
  clearTimers(room);
  room.state = 'roundStart';
  room.drawerId = null;
  room.turn = null;
  room.strokes = [];
  room.endsAt = Date.now() + ROUND_INTRO_MS;
  io.to(room.code).emit('clear');
  sysMsg(room, 'Round ' + room.round + ' of ' + room.settings.rounds, 'round');
  broadcastState(room);
  room.timers.push(setTimeout(() => { if (room.state === 'roundStart') nextTurn(room); }, ROUND_INTRO_MS));
}

// ---------------------------------------------------------------- game flow
function startGame(room) {
  if (connectedPlayers(room).length < 2) { room.notice = 'Need at least 2 players to start.'; broadcastState(room); return; }
  room.state = 'loading';
  room.notice = 'Getting fresh words from the AI…';
  broadcastState(room);
  ensurePack(room).then((pack) => {
    if (room.state !== 'loading') return;
    connectedPlayers(room).forEach((p) => { p.score = 0; p.g = freshStats(); });
    room.round = 1;
    room.turnNo = 0;
    room.gallery = [];
    room.galleryVotes = new Map();
    room.wrongGuesses = [];
    room.endData = null;
    room.notice = pack.source === 'ai' ? '' : 'AI not reachable – using built-in words.';
    room.drawerQueue = connectedPlayers(room).map((p) => p.id);
    sysMsg(room, 'Game started! ' + room.settings.rounds + ' rounds, ' + room.settings.drawTime + 's per drawing.');
    roundIntro(room);
  });
}

function nextTurn(room) {
  clearTimers(room);
  if (connectedPlayers(room).length < 2) return backToLobby(room, 'Not enough players left – back to the lobby.');

  let nextId = null;
  while (room.drawerQueue.length) {
    const id = room.drawerQueue.shift();
    const p = room.players.get(id);
    if (p && p.connected) { nextId = id; break; }
  }
  if (!nextId) {
    room.round++;
    if (room.round > room.settings.rounds) return endGame(room);
    room.drawerQueue = connectedPlayers(room).map((p) => p.id);
    return roundIntro(room);
  }

  room.turnNo++;
  room.drawerId = nextId;
  room.state = 'choosing';
  room.choices = makeChoices(room);
  prefetchHints(room, room.choices.map((c) => c.word));
  room.word = null;
  room.difficulty = null;
  room.strokes = [];
  room.revealed = [];
  room.turnScores = {};
  room.guessedOrder = [];
  room.turn = null;
  room.endsAt = Date.now() + CHOOSE_SECONDS * 1000;
  io.to(room.code).emit('clear');
  broadcastState(room);
  room.timers.push(setTimeout(() => {
    if (room.state === 'choosing') chooseWord(room, Math.floor(Math.random() * room.choices.length));
  }, CHOOSE_SECONDS * 1000));
}

function chooseWord(room, index) {
  if (room.state !== 'choosing' || !room.choices) return;
  const c = room.choices[index] || room.choices[0];
  clearTimers(room);
  room.word = c.word;
  room.difficulty = c.difficulty;
  room.usedWords.add(c.word);
  room.state = 'drawing';
  room.choices = null;
  const drawMs = room.settings.drawTime * 1000;
  room.endsAt = Date.now() + drawMs;
  room.turn = {
    no: room.turnNo,
    startedAt: Date.now(),
    drawerId: room.drawerId,
    guessers: connectedPlayers(room).filter((p) => p.id !== room.drawerId).map((p) => p.id),
    guessTimes: {},
    reactions: { like: new Set(), dislike: new Set() },
    wrong: [],
    badges: [],
    hint: { state: 'none', text: null }
  };
  getHint(room, room.word); // make sure the hint for this word is ready before it's needed
  if (room.settings.hints) {
    const turnNo = room.turnNo;
    room.timers.push(setTimeout(() => showAutoHint(room, turnNo), Math.max(0, drawMs - HINT_AT_MS)));
  }

  const letterIdx = [];
  room.word.split('').forEach((ch, i) => { if (ch !== ' ') letterIdx.push(i); });
  const toReveal = shuffle(letterIdx).slice(0, Math.floor(letterIdx.length * 0.4));
  toReveal.forEach((idx, k) => {
    const at = drawMs * (0.35 + 0.55 * (k + 1) / (toReveal.length + 1));
    room.timers.push(setTimeout(() => {
      if (room.state !== 'drawing') return;
      room.revealed.push(idx);
      broadcastState(room);
    }, at));
  });
  room.timers.push(setTimeout(() => endTurn(room, 'time'), drawMs));
  broadcastState(room);
}

function endTurn(room, reason) {
  if (room.state !== 'drawing' && room.state !== 'choosing') return;
  clearTimers(room);
  const drawer = room.players.get(room.drawerId);
  const word = room.word || (room.choices && room.choices[0] && room.choices[0].word) || '';
  const t = room.turn;

  if (t && drawer && room.word) {
    const mult = DIFF_MULT[room.difficulty] || 1;
    if (room.guessedOrder.length) {
      const gain = Math.min(Math.round(50 * mult * room.guessedOrder.length), Math.round(250 * mult));
      drawer.score += gain;
      room.turnScores[drawer.id] = (room.turnScores[drawer.id] || 0) + gain;
      drawer.g.drawnGuessed += room.guessedOrder.length;
    }
    const likeCount = t.reactions.like.size; // only likes earn points; dislikes cost nothing
    if (likeCount) {
      const bonus = Math.min(likeCount, 10) * 5;
      drawer.score += bonus;
      room.turnScores[drawer.id] = (room.turnScores[drawer.id] || 0) + bonus;
    }
    const stillHere = t.guessers.filter((id) => { const p = room.players.get(id); return p && p.connected; });
    if (stillHere.length >= 2 && stillHere.every((id) => room.guessedOrder.indexOf(id) !== -1)) giveBadge(room, drawer, 'masterpiece');
    if (likeCount >= Math.max(2, Math.ceil(stillHere.length / 2))) giveBadge(room, drawer, 'crowdPleaser');
    // guessers who missed lose their hat-trick streak
    stillHere.forEach((id) => { if (room.guessedOrder.indexOf(id) === -1) { const p = room.players.get(id); if (p && p.g) p.g.streak = 0; } });

    if (room.strokes.length) {
      const times = Object.keys(t.guessTimes).map((k) => t.guessTimes[k]);
      const seenWrong = new Set();
      const wrongSample = [];
      t.wrong.forEach((w) => { const k = norm(w.text); if (k && !seenWrong.has(k) && wrongSample.length < 6) { seenWrong.add(k); wrongSample.push(w.text); } });
      room.gallery.push({
        id: 'd' + room.turnNo, turnNo: room.turnNo, word, drawerId: drawer.id, drawerName: drawer.name, drawerColor: drawer.color,
        image: null, imageFromDrawer: false, likes: 0, dislikes: 0,
        guessed: room.guessedOrder.length, possible: stillHere.length,
        fastest: times.length ? Math.min.apply(null, times) : null,
        wrongCount: t.wrong.length, wrongSample, hintUsed: t.hint.state === 'given', tags: []
      });
    }
    if (room.settings.commentator) commentate(room, t, word, drawer.name, reason);
  }

  const rows = connectedPlayers(room).map((p) => ({
    id: p.id, name: p.name, color: p.color, delta: room.turnScores[p.id] || 0, total: p.score,
    isDrawer: p.id === room.drawerId, guessed: room.guessedOrder.indexOf(p.id) !== -1,
    badges: []
  })).sort((a, b) => b.delta - a.delta || b.total - a.total);

  room.lastResult = {
    word, reason, drawerName: drawer ? drawer.name : '',
    guessedCount: room.guessedOrder.length,
    possible: Math.max(0, connectedPlayers(room).length - 1),
    rows
  };
  room.state = 'turnEnd';
  room.endsAt = Date.now() + TURN_END_SECONDS * 1000;
  room.word = null;
  broadcastState(room);
  room.timers.push(setTimeout(() => {
    // keep final reaction counts for the gallery
    const g = room.gallery.find((e) => t && e.turnNo === t.no);
    if (g && t) { g.likes = t.reactions.like.size; g.dislikes = t.reactions.dislike.size; }
    nextTurn(room);
  }, TURN_END_SECONDS * 1000));
}

function commentate(room, t, word, drawerName, reason) {
  const nameOf = (id) => { const p = room.players.get(id); return p ? p.name : '?'; };
  const facts = {
    word, drawer: drawerName, reason,
    guessed: room.guessedOrder.map((id) => ({ name: nameOf(id), seconds: t.guessTimes[id] })),
    missed: t.guessers.filter((id) => room.guessedOrder.indexOf(id) === -1).map(nameOf),
    wrong: t.wrong.slice(-8),
    likes: t.reactions.like.size,
    dislikes: t.reactions.dislike.size,
    hintUsed: t.hint.state === 'given'
  };
  const code = room.code;
  fun.commentOnTurn(facts, room.settings.lang).then((line) => {
    if (line && rooms.get(code) === room && room.settings.commentator) {
      io.to(code).emit('msg', { type: 'ai', name: 'Commentator', text: line });
    }
  }).catch(() => { /* commentator stays quiet when the AI is busy */ });
}

// ---------------------------------------------------------------- end of game
function galleryVoters(room) {
  return connectedPlayers(room).filter((p) => room.gallery.some((e) => e.image && e.drawerId !== p.id));
}

function endGame(room) {
  clearTimers(room);
  room.drawerId = null;
  room.turn = null;
  computeHighlights(room);
  prepareEndData(room);
  const shown = room.gallery.filter((e) => e.image);
  if (shown.length >= 1 && connectedPlayers(room).length >= 2) {
    room.state = 'gallery';
    room.galleryVotes = new Map();
    const secs = Math.min(90, 30 + 2 * shown.length);
    room.endsAt = Date.now() + secs * 1000;
    sendGallery(room);
    broadcastState(room);
    sysMsg(room, 'Game over! Vote for the drawing of the game.');
    room.timers.push(setTimeout(() => finishGallery(room), secs * 1000));
  } else {
    finishGame(room, null);
  }
}

function sendGallery(room, socketId) {
  const payload = room.gallery.filter((e) => e.image).map((e) => ({
    id: e.id, word: e.word, drawerId: e.drawerId, drawerName: e.drawerName, drawerColor: e.drawerColor,
    image: e.image, likes: e.likes, dislikes: e.dislikes,
    guessed: e.guessed, possible: e.possible, fastest: e.fastest, wrongCount: e.wrongCount,
    wrongSample: e.wrongSample, hintUsed: e.hintUsed, tags: e.tags
  }));
  if (socketId) io.to(socketId).emit('gallery', payload);
  else io.to(room.code).emit('gallery', payload);
}

const HIGHLIGHT_LABELS = {
  mostLiked: 'Most liked',
  mostDisliked: 'Most disliked',
  quickest: 'Quickest guess',
  mystery: 'Total mystery',
  confusing: 'Most confusing'
};

// Fun "awards for drawings", picked from facts (the AI only writes captions for them)
function computeHighlights(room) {
  const list = room.gallery.filter((e) => e.image);
  const pick = (score, min) => {
    let best = null, bestV = null;
    list.forEach((e) => { const v = score(e); if (v == null || v < min) return; if (bestV == null || v > bestV) { best = e; bestV = v; } });
    return best ? { e: best, v: bestV } : null;
  };
  const out = [];
  const add = (key, r, stat) => { if (r) out.push({ key, label: HIGHLIGHT_LABELS[key], entryId: r.e.id, word: r.e.word, drawerName: r.e.drawerName, stat: stat(r.v, r.e), caption: null }); };
  add('mostLiked', pick((e) => e.likes, 1), (v) => v + ' like' + (v === 1 ? '' : 's'));
  add('mostDisliked', pick((e) => e.dislikes, 1), (v) => v + ' dislike' + (v === 1 ? '' : 's'));
  add('quickest', pick((e) => (e.fastest == null ? null : 1000 - e.fastest), 1), (v, e) => 'guessed in ' + e.fastest + ' second' + (e.fastest === 1 ? '' : 's'));
  add('mystery', pick((e) => (e.possible ? (1 - e.guessed / e.possible) * 100 + e.wrongCount : null), 50.5),
    (v, e) => (e.guessed ? 'only ' + e.guessed + ' of ' + e.possible + ' guessed it' : 'nobody guessed it'));
  add('confusing', pick((e) => e.wrongCount, 3), (v) => v + ' wrong guesses');
  list.forEach((e) => { e.tags = out.filter((h) => h.entryId === e.id).map((h) => h.label); });
  room.highlights = out;
}

function finishGallery(room) {
  if (room.state !== 'gallery') return;
  clearTimers(room);
  const tally = new Map();
  room.galleryVotes.forEach((entryId) => tally.set(entryId, (tally.get(entryId) || 0) + 1));
  let best = null;
  room.gallery.forEach((e) => {
    const v = tally.get(e.id) || 0;
    if (!v) return;
    if (!best || v > best.votes || (v === best.votes && e.likes - e.dislikes > best.e.likes - best.e.dislikes)) best = { e, votes: v };
  });
  let winner = null;
  if (best) {
    const p = room.players.get(best.e.drawerId);
    if (p && p.connected) giveBadge(room, p, 'drawingOfGame');
    winner = { id: best.e.id, word: best.e.word, drawerName: best.e.drawerName, votes: best.votes };
  }
  finishGame(room, winner);
}

function prepareEndData(room) {
  const ps = connectedPlayers(room).filter((p) => p.g);
  const top = (fn, min) => {
    let bestP = null, bestV = null;
    ps.forEach((p) => { const v = fn(p); if (v == null || v < (min || 1)) return; if (bestV == null || v > bestV) { bestP = p; bestV = v; } });
    return bestP ? { p: bestP, v: bestV } : null;
  };
  const awards = [];
  const add = (key, r, statText) => { if (r) awards.push({ key, name: r.p.name, stat: statText(r.v) }); };
  add('mindReader', top((p) => p.g.correct), (v) => v + ' correct guesses');
  const fastest = ps.filter((p) => p.g.fastest != null).sort((a, b) => a.g.fastest - b.g.fastest)[0];
  if (fastest) awards.push({ key: 'speedDemon', name: fastest.name, stat: 'guessed in ' + fastest.g.fastest + ' seconds' });
  add('bestArtist', top((p) => p.g.drawnGuessed), (v) => v + ' people guessed their drawings');
  add('creative', top((p) => p.g.wrong, 3), (v) => v + ' wrong guesses');
  add('soClose', top((p) => p.g.close, 2), (v) => v + ' "very close" guesses');
  add('crowdFav', top((p) => p.g.reactionsGot, 2), (v) => v + ' likes on their drawings');
  add('badgeHunter', top((p) => p.g.badgeCount, 2), (v) => v + ' badges');

  const highlights = (room.highlights || []).map((h) => {
    const e = room.gallery.find((x) => x.id === h.entryId);
    return { key: h.key, label: h.label, word: h.word, drawer: h.drawerName, stat: h.stat, wrongGuesses: e ? e.wrongSample.slice(0, 4) : [] };
  });
  room.endData = { ranking: null, awards: null, funniest: null, pending: true, winnerDrawing: null, highlights: room.highlights || [] };
  const code = room.code;
  const data = room.endData;
  fun.endOfGame(awards, room.wrongGuesses, room.settings.lang, highlights).then((res) => {
    data.awards = res.awards;
    data.funniest = res.funniest;
    data.highlights.forEach((h) => { if (res.captions[h.key]) h.caption = res.captions[h.key]; });
    if (data.hofRecords && data.hofRecords.length) {
      const byLabel = {};
      data.highlights.forEach((h) => { if (h.caption) byLabel[h.label] = h.caption; });
      hof.setCaptions(data.hofRecords, byLabel);
    }
    data.pending = false;
    if (rooms.get(code) === room && room.endData === data && room.state === 'gameOver') broadcastState(room);
  });
}

function finishGame(room, winnerDrawing) {
  clearTimers(room);
  room.state = 'gameOver';
  room.endsAt = 0;
  const ranking = connectedPlayers(room)
    .map((p) => {
      const mine = room.gallery.filter((e) => e.drawerId === p.id);
      return {
        id: p.id, name: p.name, color: p.color, score: p.score, badges: p.g ? p.g.badgeCount : 0,
        correct: p.g ? p.g.correct : 0, drawnGuessed: p.g ? p.g.drawnGuessed : 0,
        likes: mine.reduce((n, e) => n + e.likes, 0), dislikes: mine.reduce((n, e) => n + e.dislikes, 0),
        dotg: winnerDrawing && mine.some((e) => e.id === winnerDrawing.id) ? 1 : 0
      };
    })
    .sort((a, b) => b.score - a.score);
  room.finalRanking = ranking;
  if (!room.endData) room.endData = { awards: [], funniest: [], pending: false };
  room.endData.ranking = ranking;
  room.endData.winnerDrawing = winnerDrawing;
  // famous drawings for the hall of fame: the drawing of the game + every highlight
  const famous = new Map();
  const addFamous = (entryId, label, stat, caption) => {
    const e = room.gallery.find((x) => x.id === entryId && x.image);
    if (!e) return;
    const f = famous.get(entryId) || { labels: [], word: e.word, drawer: e.drawerName, stat: '', caption: '', likes: e.likes, dislikes: e.dislikes, image: e.image };
    f.labels.push(label);
    if (!f.stat) f.stat = stat;
    if (!f.caption && caption) f.caption = caption;
    famous.set(entryId, f);
  };
  if (winnerDrawing) addFamous(winnerDrawing.id, 'Drawing of the game', winnerDrawing.votes + ' vote' + (winnerDrawing.votes === 1 ? '' : 's'), '');
  (room.highlights || []).forEach((h) => addFamous(h.entryId, h.label, h.stat, h.caption));
  const saved = hof.recordGame(ranking, room.settings.rounds, Array.from(famous.values()));
  Object.defineProperty(room.endData, 'hofRecords', { value: saved, writable: true, enumerable: false }); // server-only
  broadcastState(room);
  const w = ranking[0];
  if (w) sysMsg(room, w.name + ' wins with ' + w.score + ' points!');
}

function backToLobby(room, notice) {
  clearTimers(room);
  room.state = 'lobby';
  room.round = 0;
  room.drawerId = null;
  room.word = null;
  room.choices = null;
  room.strokes = [];
  room.guessedOrder = [];
  room.turn = null;
  room.gallery = [];
  room.galleryVotes = new Map();
  room.endData = null;
  room.notice = notice || '';
  connectedPlayers(room).forEach((p) => { p.score = 0; });
  io.to(room.code).emit('clear');
  broadcastState(room);
}

// ---------------------------------------------------------------- guesses
function handleGuess(room, player, text) {
  const isDrawing = room.state === 'drawing';
  const isDrawer = player.id === room.drawerId;
  const alreadyGuessed = room.guessedOrder.indexOf(player.id) !== -1;

  if (isDrawing && !isDrawer && !alreadyGuessed) {
    const g = norm(text);
    const w = norm(room.word);
    const t = room.turn;
    if (g && g === w) {
      const now = Date.now();
      const leftMs = Math.max(0, room.endsAt - now);
      const timeLeft = leftMs / (room.settings.drawTime * 1000);
      const mult = DIFF_MULT[room.difficulty] || 1;
      const gain = Math.round((100 + 200 * timeLeft) * mult);
      const seconds = Math.max(1, Math.round((now - t.startedAt) / 1000));
      player.score += gain;
      room.turnScores[player.id] = gain;
      room.guessedOrder.push(player.id);
      t.guessTimes[player.id] = seconds;
      player.g.correct++;
      if (player.g.fastest == null || seconds < player.g.fastest) player.g.fastest = seconds;
      sysMsg(room, player.name + ' guessed the word!', 'correct');
      if (room.guessedOrder.length === 1) giveBadge(room, player, 'firstBlood');
      if (seconds <= 10) giveBadge(room, player, 'sniper');
      if (leftMs <= 5000) giveBadge(room, player, 'buzzer');
      player.g.streak++;
      if (player.g.streak >= 3) { giveBadge(room, player, 'hatTrick'); player.g.streak = 0; }
      broadcastState(room);
      const guessers = connectedPlayers(room).filter((p) => p.id !== room.drawerId);
      if (guessers.every((p) => room.guessedOrder.indexOf(p.id) !== -1)) {
        room.timers.push(setTimeout(() => endTurn(room, 'all'), 800));
      }
      return;
    }
    // wrong guess: remember it for the commentator and the "best wrong guesses"
    if (g) {
      const entry = { name: player.name, text: text.slice(0, 60), word: room.word };
      t.wrong.push(entry);
      if (room.wrongGuesses.length < 400) room.wrongGuesses.push(entry);
      player.g.wrong++;
    }
    if (g && w.length >= 3 && levenshtein(g, w) <= (w.length <= 5 ? 1 : 2)) {
      player.g.close++;
      io.to(player.socketId).emit('msg', { type: 'close', text: '"' + text + '" is very close!' });
      io.to(room.code).emit('msg', { type: 'chat', name: player.name, color: player.color, text });
      return;
    }
  }

  if (isDrawing && (isDrawer || alreadyGuessed)) {
    if (room.word && norm(text).indexOf(norm(room.word)) !== -1) {
      io.to(player.socketId).emit('msg', { type: 'system', text: 'Shh! Don\'t give away the word.' });
      return;
    }
    const msg = { type: 'chat-secret', name: player.name, color: player.color, text };
    connectedPlayers(room).forEach((p) => {
      if (p.id === room.drawerId || room.guessedOrder.indexOf(p.id) !== -1) io.to(p.socketId).emit('msg', msg);
    });
    return;
  }

  io.to(room.code).emit('msg', { type: 'chat', name: player.name, color: player.color, text });
}

// ---------------------------------------------------------------- sockets
io.on('connection', (socket) => {
  let room = null;
  let player = null;
  let msgTimes = [];
  let reactTimes = [];

  socket.on('join', (data, ack) => {
    const reply = typeof ack === 'function' ? ack : function () {};
    if (room) return reply({ ok: false, error: 'Already joined' });
    data = data || {};
    const name = cleanName(data.name);
    const code = cleanRoomCode(data.room) || 'OFFICE';
    const clientId = String(data.clientId || '').replace(/[^a-zA-Z0-9-]/g, '').slice(0, 40) || crypto.randomUUID();
    if (!name) return reply({ ok: false, error: 'Please enter your name.' });

    const r = getRoom(code);
    let p = r.players.get(clientId);
    if (!p) {
      if (connectedPlayers(r).length >= MAX_PLAYERS) return reply({ ok: false, error: 'Room is full (max ' + MAX_PLAYERS + ').' });
      const taken = connectedPlayers(r).some((x) => x.name.toLowerCase() === name.toLowerCase());
      if (taken) return reply({ ok: false, error: 'Someone in this room is already called "' + name + '".' });
      const usedColors = connectedPlayers(r).map((x) => x.color);
      const color = AVATAR_COLORS.find((c) => usedColors.indexOf(c) === -1) || AVATAR_COLORS[r.order.length % AVATAR_COLORS.length];
      p = { id: clientId, name, score: 0, color, connected: true, socketId: socket.id, leaveTimer: null, g: freshStats() };
      r.players.set(clientId, p);
      r.order.push(clientId);
      sysMsg(r, name + ' joined.', 'join');
    } else {
      if (p.leaveTimer) { clearTimeout(p.leaveTimer); p.leaveTimer = null; }
      const wasConnected = p.connected;
      if (wasConnected && p.socketId && p.socketId !== socket.id) {
        const old = io.sockets.sockets.get(p.socketId);
        if (old) old.disconnect(true);
      }
      p.connected = true;
      p.socketId = socket.id;
      p.name = name;
      if (!p.g) p.g = freshStats();
      if (!wasConnected) sysMsg(r, name + ' is back.', 'join');
    }
    if (!r.hostId || !r.players.get(r.hostId) || !r.players.get(r.hostId).connected) r.hostId = p.id;
    r.emptySince = null;

    room = r; player = p;
    socket.join(r.code);
    reply({ ok: true, room: r.code, clientId });
    log('join', r.code, name);
    socket.emit('canvas', { strokes: r.strokes });
    if (r.state === 'gallery' || r.state === 'gameOver') sendGallery(r, socket.id);
    broadcastState(r);
  });

  function isHost() { return room && player && room.hostId === player.id; }
  function isDrawerNow() { return room && player && room.state === 'drawing' && room.drawerId === player.id; }

  socket.on('settings', (s) => {
    if (!isHost() || room.state !== 'lobby' || !s) return;
    const st = room.settings;
    if ([2, 3, 5].indexOf(+s.rounds) !== -1) st.rounds = +s.rounds;
    if ([60, 80, 120].indexOf(+s.drawTime) !== -1) st.drawTime = +s.drawTime;
    if (typeof s.theme === 'string') st.theme = s.theme.replace(/[\u0000-\u001f<>]/g, '').slice(0, 60);
    if (['english', 'urdu', 'mix'].indexOf(s.lang) !== -1) st.lang = s.lang;
    if (s.commentator === 'on' || s.commentator === 'off') st.commentator = s.commentator === 'on';
    if (s.hints === 'on' || s.hints === 'off') st.hints = s.hints === 'on';
    room.notice = '';
    broadcastState(room);
  });

  socket.on('preview-words', () => {
    if (!isHost() || room.state !== 'lobby') return;
    io.to(room.code).emit('preview', { loading: true });
    const r = room;
    ensurePack(r).then((pack) => {
      const sample = shuffle(pack.easy.slice(0, 20)).slice(0, 3)
        .concat(shuffle(pack.medium.slice(0, 20)).slice(0, 3))
        .concat(shuffle(pack.hard.slice(0, 20)).slice(0, 2));
      io.to(r.code).emit('preview', { loading: false, words: sample, source: pack.source });
    });
  });

  socket.on('start', () => {
    if (!isHost() || room.state !== 'lobby') return;
    startGame(room);
  });

  socket.on('choose', (i) => {
    if (!room || !player || room.state !== 'choosing' || room.drawerId !== player.id) return;
    const idx = parseInt(i, 10);
    if (!(idx >= 0 && idx < 3)) return;
    chooseWord(room, idx);
  });

  socket.on('draw', (op) => {
    if (!isDrawerNow() || !op || typeof op !== 'object') return;
    const pts = Array.isArray(op.p) ? op.p : [];
    const clean = [];
    for (let i = 0; i < pts.length && i < 400; i++) {
      const x = +(pts[i] && pts[i][0]), y = +(pts[i] && pts[i][1]);
      if (isFinite(x) && isFinite(y)) clean.push([Math.max(0, Math.min(1000, Math.round(x))), Math.max(0, Math.min(750, Math.round(y)))]);
    }
    const id = String(op.id || '').slice(0, 24);
    if (!id || !clean.length) return;
    if (op.t === 's') {
      if (room.strokes.length >= MAX_STROKES) return;
      const kind = KINDS.indexOf(op.k) !== -1 ? op.k : 'pen';
      if ((kind === 'line' || kind === 'rect' || kind === 'ellipse') && clean.length !== 2) return;
      if (kind === 'fill' && clean.length !== 1) return;
      const color = COLORS_ALLOWED.test(op.c) ? op.c : '#16181D';
      const size = SIZES_ALLOWED.indexOf(+op.w) !== -1 ? +op.w : 10;
      const stroke = { id, k: kind, c: color, w: size, p: kind === 'pen' ? clean : clean.slice(0, 2) };
      room.strokes.push(stroke);
      socket.to(room.code).emit('draw', { t: 's', id, k: kind, c: color, w: size, p: stroke.p });
    } else if (op.t === 'a') {
      const s = room.strokes.length && room.strokes[room.strokes.length - 1];
      if (!s || s.id !== id || s.k !== 'pen' || s.p.length + clean.length > MAX_POINTS_PER_STROKE) return;
      Array.prototype.push.apply(s.p, clean);
      socket.to(room.code).emit('draw', { t: 'a', id, p: clean });
    }
  });

  socket.on('undo', () => {
    if (!isDrawerNow() || !room.strokes.length) return;
    const s = room.strokes.pop();
    socket.to(room.code).emit('undo', { id: s.id });
  });

  socket.on('clear', () => {
    if (!isDrawerNow()) return;
    room.strokes = [];
    socket.to(room.code).emit('clear');
  });

  socket.on('guess', (text) => {
    if (!room || !player) return;
    text = String(text || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 100);
    if (!text) return;
    const now = Date.now();
    msgTimes = msgTimes.filter((t) => now - t < 4000);
    if (msgTimes.length >= 6) return socket.emit('msg', { type: 'system', text: 'Slow down a little!' });
    msgTimes.push(now);
    handleGuess(room, player, text);
  });

  // ---- reactions
  socket.on('react', (type) => {
    if (!room || !player || !room.turn || (room.state !== 'drawing' && room.state !== 'turnEnd')) return;
    if (type !== 'like' && type !== 'dislike') return;
    if (player.id === room.turn.drawerId) return;
    const now = Date.now();
    reactTimes = reactTimes.filter((x) => now - x < 3000);
    if (reactTimes.length >= 6) return;
    reactTimes.push(now);
    const R = room.turn.reactions;
    const set = R[type];
    const other = R[type === 'like' ? 'dislike' : 'like'];
    const drawer = room.players.get(room.turn.drawerId);
    const countLikes = () => { if (drawer && drawer.g) drawer.g.reactionsGot = Math.max(0, drawer.g.reactionsGot + (R.like.has(player.id) ? 1 : 0) - before); };
    const before = R.like.has(player.id) ? 1 : 0;
    if (set.has(player.id)) set.delete(player.id);
    else {
      set.add(player.id);
      other.delete(player.id); // like and dislike are exclusive
      io.to(room.code).emit('react', { type, name: player.name });
    }
    countLikes();
    const g = room.gallery.find((e) => e.turnNo === room.turn.no);
    if (g) { g.likes = R.like.size; g.dislikes = R.dislike.size; }
    broadcastState(room);
  });

  // ---- drawing snapshot for the gallery (sent by clients when a turn ends)
  socket.on('snapshot', (d) => {
    if (!room || !player || !d || typeof d.image !== 'string') return;
    if (d.image.length > MAX_IMAGE_CHARS || !/^data:image\/(jpeg|webp|png);base64,[A-Za-z0-9+/=]+$/.test(d.image)) return;
    const e = room.gallery.find((x) => x.turnNo === +d.turnNo);
    if (!e) return;
    const fromDrawer = player.id === e.drawerId;
    if (e.image && (e.imageFromDrawer || !fromDrawer)) return;
    e.image = d.image;
    e.imageFromDrawer = fromDrawer;
  });

  // ---- gallery vote
  socket.on('gallery-vote', (entryId) => {
    if (!room || !player || room.state !== 'gallery') return;
    const e = room.gallery.find((x) => x.id === entryId && x.image);
    if (!e || e.drawerId === player.id) return;
    room.galleryVotes.set(player.id, e.id);
    const voters = galleryVoters(room);
    if (voters.every((p) => room.galleryVotes.has(p.id))) { broadcastState(room); room.timers.push(setTimeout(() => finishGallery(room), 1200)); return; }
    broadcastState(room);
  });

  socket.on('gallery-skip', () => {
    if (!isHost() || room.state !== 'gallery') return;
    finishGallery(room);
  });

  socket.on('skip-turn', () => {
    if (!room || !player || room.drawerId !== player.id) return;
    if (room.state === 'drawing' || room.state === 'choosing') { sysMsg(room, player.name + ' skipped their turn.'); endTurn(room, 'skip'); }
  });

  socket.on('end-game', () => {
    if (!isHost() || room.state === 'lobby') return;
    backToLobby(room, 'The host ended the game.');
  });

  socket.on('back-to-lobby', () => {
    if (!isHost() || room.state !== 'gameOver') return;
    backToLobby(room, '');
  });

  socket.on('disconnect', () => {
    if (!room || !player || player.socketId !== socket.id) return;
    const r = room, p = player;
    p.connected = false;
    log('leave', r.code, p.name);
    sysMsg(r, p.name + ' left.', 'leave');

    if (r.hostId === p.id) {
      const next = connectedPlayers(r)[0];
      r.hostId = next ? next.id : null;
      if (next) sysMsg(r, next.name + ' is now the host.');
    }
    if (r.drawerId === p.id && (r.state === 'drawing' || r.state === 'choosing')) {
      sysMsg(r, 'The drawer left – skipping turn.');
      endTurn(r, 'left');
    } else if (r.state === 'drawing') {
      const guessers = connectedPlayers(r).filter((x) => x.id !== r.drawerId);
      if (guessers.length && guessers.every((x) => r.guessedOrder.indexOf(x.id) !== -1)) endTurn(r, 'all');
    } else if (r.state === 'gallery') {
      const voters = galleryVoters(r);
      if (voters.length && voters.every((x) => r.galleryVotes.has(x.id))) finishGallery(r);
    }
    if (r.state !== 'lobby' && r.state !== 'gameOver' && r.state !== 'gallery' && connectedPlayers(r).length < 2) {
      backToLobby(r, 'Not enough players left – back to the lobby.');
    }
    broadcastState(r);

    p.leaveTimer = setTimeout(() => {
      if (p.connected) return;
      r.players.delete(p.id);
      r.order = r.order.filter((id) => id !== p.id);
      if (!connectedPlayers(r).length) r.emptySince = Date.now();
    }, RECONNECT_GRACE_MS);
    if (!connectedPlayers(r).length) r.emptySince = Date.now();
  });
});

// clean up empty rooms
setInterval(() => {
  const now = Date.now();
  rooms.forEach((r, code) => {
    if (!connectedPlayers(r).length && r.emptySince && now - r.emptySince > EMPTY_ROOM_TTL_MS) {
      clearTimers(r);
      rooms.delete(code);
      log('room removed', code);
    }
  });
}, 60000).unref();

server.listen(PORT, HOST, () => {
  log("Bilal's Playground running on http://" + HOST + ':' + PORT + '  (AI: ' + ai.AI_URL + ', data: ' + hof.DATA_DIR + ')');
});

function shutdown(sig) {
  log('received ' + sig + ', shutting down');
  io.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
