# Bilal's Playground

An office draw-and-guess game that runs entirely on your own VM.
No internet needed: the dependencies and fonts are already inside this folder.
Your local AI (port 8001) is used **only** to generate the word lists. If the AI
is down or slow, the game automatically falls back to a built-in word list.

- Game: `http://<VM-IP>:3000`
- Runs as a **systemd service**, so it keeps running after PuTTY disconnects and starts again after a reboot.
- Installs to: `/data/bilals-playground`

---

## 1. Requirements (already on your VM)

- RHEL 8/9 with systemd
- Node.js 14 or newer (`node -v`)
- `sudo` rights
- Your AI server on `http://127.0.0.1:8001` with an OpenAI-compatible API
  (vLLM, Ollama, llama.cpp server, LM Studio, etc.)

---

## 2. Copy the zip to the VM

From your Windows PC, use **WinSCP** (or `scp` in PowerShell) to upload
`bilals-playground.zip` to `/tmp` on the VM:

```powershell
scp bilals-playground.zip youruser@VM-IP:/tmp/
```

---

## 3. Install (about 1 minute)

Log in with PuTTY and run these commands. The PuTTY 15-minute timeout doesn't
matter: once installed, the game runs under systemd.

```bash
# 1. Create /data if needed and extract the zip there
sudo mkdir -p /data
sudo python3 -m zipfile -e /tmp/bilals-playground.zip /data/
#   (or, if unzip is installed:  sudo unzip -o /tmp/bilals-playground.zip -d /data/)

# 2. Run the installer
sudo bash /data/bilals-playground/deploy/install.sh
```

The installer:

1. Checks Node.js.
2. Creates a locked-down system user `bpgame` to run the game.
3. Writes the settings file `/etc/bilals-playground.env`.
4. Creates and starts the systemd service `bilals-playground`.
5. Opens port **3000/tcp** in firewalld.
6. Prints the link to share, e.g. `http://10.0.0.25:3000`.

---

## 4. Check the AI connection

```bash
curl -s http://127.0.0.1:3000/health
```

After someone clicks **Preview words** or starts a game, `"ai": {"ok": true, ...}`
means words are coming from your AI. If it says `"ok": false`, the `detail`
field explains why.

Common fixes, made in `/etc/bilals-playground.env`:

| Problem | Fix |
|---|---|
| Your AI's URL is different | Set `AI_URL=http://127.0.0.1:8001/v1/chat/completions` (adjust the path) |
| "Could not detect model name" | Set `AI_MODEL=` to the exact model name your server uses (`curl -s http://127.0.0.1:8001/v1/models`) |
| AI needs an API key | Set `AI_API_KEY=...` |
| AI is slow on first call | Raise `AI_TIMEOUT_MS=90000` |

After any edit:

```bash
sudo systemctl restart bilals-playground
```

---

## 5. Everyday commands

```bash
sudo systemctl status bilals-playground      # is it running?
sudo systemctl restart bilals-playground     # restart
sudo systemctl stop bilals-playground        # stop for now
sudo systemctl start bilals-playground       # start again
sudo journalctl -u bilals-playground -f      # live logs (Ctrl+C to exit)
sudo journalctl -u bilals-playground -n 100  # last 100 log lines
```

To turn it off permanently: `sudo bash /data/bilals-playground/deploy/uninstall.sh`

### Updating to a new version

Extract the new zip over the old folder, then run the installer again. Your settings file
(`/etc/bilals-playground.env`) and the hall of fame (`/data/bilals-playground/data/`) are kept.

```bash
sudo python3 -m zipfile -e /tmp/bilals-playground.zip /data/
sudo bash /data/bilals-playground/deploy/install.sh
```

---

## 6. Troubleshooting

**Colleagues can't open the page, but `curl http://127.0.0.1:3000/health` works on the VM**

- Check firewalld: `sudo firewall-cmd --list-ports` should show `3000/tcp`.
- There may also be a network firewall between the office LAN and the VM. Ask IT to allow TCP 3000 to this VM.

**Service won't start**

- Run `sudo journalctl -u bilals-playground -n 50 --no-pager` and read the last lines.
- If you see `EADDRINUSE`, something else already uses port 3000. Change `PORT=` in `/etc/bilals-playground.env`, then run the installer again (it opens the new port).
- SELinux denials: `sudo ausearch -m avc -ts recent`. The installer only relabels files; it never changes SELinux policy.

**"Permission denied" on /data**

The installer checks that the `bpgame` user can read the folder. If it can't
(for example, because `/data` is locked down), it falls back to running as your
own user and tells you so.

---

## 7. How to play

1. Everyone opens `http://<VM-IP>:3000`, enters a name and the **same room code** (default `OFFICE`). You can also use **Copy invite link** in the lobby.
2. The first person in the room is the **host**. The host picks the rounds, draw time, a **theme** for the AI word pack (e.g. "Country + City + Fruits"), the language (English, Roman Urdu or Mix), and whether the **AI commentator** and **AI hints** are on.
3. **Preview words** shows a sample from the AI before you start.
4. Each round starts with a short **"Round 1"** announcement, then every player draws once. The drawer picks one of three words: easy (1×), medium (1.5×) or hard (2×).
5. Everyone else types guesses in the chat. Spelling, capitals and spaces are forgiven ("Doodh Patti" = "doodhpatti"), and near-misses show **"very close!"** privately.
6. Letters are revealed slowly. Faster correct guesses score more, and the drawer earns a bonus for each person who guesses.
7. Players who already guessed (and the drawer) can chat privately so they don't spoil the word.

Up to 12 players per room. You can run several rooms at once with different room codes.

### Drawing tools

Everything fits in one slim row under the canvas: the current colour, 20 colours and a custom
colour picker, a **brush size** button (opens a small list of 4 sizes), then pen, eraser,
**fill bucket**, **straight line**, **rectangle** and **circle**. **Undo** (Ctrl+Z) and **redo** (Ctrl+Y).
Hold **Shift** while drawing a rectangle or circle to get a perfect square or circle.
Keyboard shortcuts for the drawer: `P` pen, `E` eraser, `F` fill, `L` line, `R` rectangle, `C` circle.

### AI hint (last 10 seconds)

- With **10 seconds left** in a drawing, an AI-written hint appears automatically under the word and in the chat.
- The AI writes the hints **while the drawer is still choosing the word**, so the hint is ready instantly.
- Hints never contain the word. If the AI's hint gives the answer away, or the AI is unavailable, a safe built-in hint is used instead.
- The host can switch AI hints **On / Off** in the lobby. The letter reveals (`_ H _ _`) always stay on.

### Badges (bonus points)

Badges are earned quietly in the background: there are no pop-ups or chat messages during the game.
They add their bonus points and show up on the results page (badge counts, Badge Collector award)
and in the hall of fame.

| Badge | How to earn it | Bonus |
|---|---|---|
| First Blood | First correct guess of a drawing | +30 |
| Sniper | Correct within 10 seconds | +25 |
| Buzzer Beater | Correct in the last 5 seconds | +15 |
| Hat-trick | 3 drawings guessed in a row | +50 |
| Masterpiece | Everyone guessed your drawing (2+ guessers) | +50 |
| Crowd Pleaser | Your drawing got lots of likes | +20 |
| Drawing of the Game | Won the end-of-game vote | +100 |

### Reactions

Guessers can tap **like** or **dislike** (the thumbs in the top-right corner of the canvas; one or the other, tap again to undo).
Reactions float up over the canvas. The drawer gets +5 points per like (up to +50 per drawing);
dislikes are just for fun and never take points away. Likes also count towards Crowd Pleaser and
the Crowd Favourite award, and like/dislike counts show in the end-of-game gallery.

### AI commentator

After each drawing, the AI posts one friendly, funny line in the chat about what happened.
It is skipped quietly when the AI is busy, and the host can turn it off in the lobby.

### End of the game

1. **Vote for the drawing of the game:** all drawings appear at once as a grid (not a slow slideshow). Tap one to see it bigger, then vote; you can't vote for your own. The vote ends as soon as everyone has voted, or after 30–90 seconds depending on the number of drawings, and the host can press **Skip to results**. The winner gets +100.
2. **Results:** the podium, the drawing of the game, **gallery highlights**, **AI awards** with funny titles (Mind Reader, Speed Demon, Best Artist, Most Creative Guesser…), the **best wrong guesses** picked by the AI, and each player's likes, dislikes and badges. The AI starts writing these while you vote, so they're usually ready instantly.
3. **View all drawings** opens every drawing of the game, with what people wrongly guessed for it and a **Download** button.

**Gallery highlights** are awards for drawings, picked from what actually happened, each with an AI-written museum-style caption:

| Highlight | Picked by |
|---|---|
| Most liked | most likes |
| Most disliked | most dislikes |
| Quickest guess | guessed fastest |
| Total mystery | nobody (or fewest people) guessed it |
| Most confusing | most wrong guesses |

They also appear as ribbons on the drawings in the voting grid, along with "People thought: …" (the wrong guesses for that drawing).

### Hall of fame and weekly champion

Every finished game is saved on the VM. The home screen and lobby show the **Champion of the week**
(most wins since Monday, then most points) and last week's champion. **Hall of fame** has three tabs:

- **This week** and **All time:** wins, games, points, best game, correct guesses, badges, likes and dislikes received, and Drawing of the Game wins.
- **Famous drawings:** a wall of every game's Drawing of the Game and gallery highlights, with their captions, newest first. This week's most liked drawing is marked **Drawing of the week**. The last 120 drawings are kept (about 5 MB) and older ones are removed automatically.

- Players are matched by **name**, so ask everyone to use the same name each time.
- Games ended early by the host are not saved.
- Backup: `sudo tar czf ~/hof-backup.tgz -C /data/bilals-playground data`
- Reset: `sudo systemctl stop bilals-playground && sudo rm -rf /data/bilals-playground/data/hall-of-fame.json /data/bilals-playground/data/drawings && sudo systemctl start bilals-playground`

### How the AI is used

The AI on port 8001 writes the word lists (and **refills them automatically** when a difficulty
runs low, without repeating words), the hints, the commentator lines, and the award titles and
funniest-guess picks. Requests go through a small queue, at most 2 at a time; set
`AI_CONCURRENCY=1` in `/etc/bilals-playground.env` if your AI server handles only one request
at a time. Every AI feature has a built-in fallback, so the game never stops because of the AI.

---

## 8. What's inside

```
bilals-playground/
├── server.js           game server (rooms, turns, scoring, hint vote, badges, gallery)
├── words.js            AI word lists, automatic refills, built-in fallback words
├── fun.js              AI hints, commentator, awards and funniest guesses
├── ai.js               connection to your AI server, with a small request queue
├── halloffame.js       saves finished games, weekly champion
├── data/               hall-of-fame.json + drawings/ (created by the installer)
├── public/             the web page (HTML, CSS, JS, offline fonts)
├── node_modules/       socket.io (pure JavaScript, already installed)
├── deploy/install.sh   installer: systemd + firewalld + SELinux label
└── deploy/uninstall.sh removes the service
```

Fonts: Baloo 2 and Inter, both under the SIL Open Font License (see `public/fonts/`).
